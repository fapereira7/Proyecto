-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-07-2016 a las 03:25:33
-- Versión del servidor: 10.1.13-MariaDB
-- Versión de PHP: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `julio_florez_actualizado`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarActa` (IN `idactax` BIGINT, IN `fechaactax` DATE, IN `fk_idtipoactax` BIGINT)  begin
Update acta set fechaacta = fechaactax where idacta = idactax;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarAcudiente` (IN `idacudientex` BIGINT, IN `identificacionacudientex` BIGINT, IN `nombreacudientex` VARCHAR(50), IN `direccionacudientex` VARCHAR(50), IN `telefonofijoacudientex` BIGINT, IN `telefonocelularacudientex` BIGINT, IN `correoacudientex` VARCHAR(50), IN `fk_idestadox` BIGINT, IN `fk_idtipodocumentox` BIGINT, IN `fk_idtiposangrex` BIGINT)  begin
Update acudiente set identificacionacudiente = identificacionacudientex where idacudiente = idacudientex;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarAsistencia` (IN `idasistenciax` BIGINT, IN `fechaasistenciax` DATETIME, IN `fk_idestadox` BIGINT)  begin
Update asistencia set fechaasistencia = fechaasistenciax where idasistencia = idasistenciax;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarEspecialidad` (IN `idespecialidadx` BIGINT, IN `nombreespecialidadx` VARCHAR(50), IN `fk_idtipoespecialidad` BIGINT, IN `fk_idestado` BIGINT)  begin
Update especialidad set nombreespecialidad = nombreespecialidadx where idespecialidad = idespecialidadx;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarEspecialidad_Asistencia` (IN `idespecialidadasistenciax` BIGINT, IN `descripcion_EAx` VARCHAR(50), IN `fk_idespecialidadx` BIGINT, IN `fk_idasistenciax` BIGINT)  begin
Update especialidad_asistencia set descripcion_EA = descripcion_EAx where idespecialidadasistencia = idespecialidadasistenciax;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarEstado` (IN `idestadox` BIGINT, IN `nombreestadox` VARCHAR(50), IN `fk_idtipoestadox` BIGINT)  begin
Update estado set nombreestado = nombreestadox where idestado = idestadox;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarEstudiante` (IN `idestudiantex` BIGINT, IN `identificacionestudiantex` BIGINT, IN `nombreestudiantex` VARCHAR(50), IN `direccionestudiantex` VARCHAR(50), IN `telefonofijoestudiantex` BIGINT, IN `telefonocelularestudiantex` BIGINT, IN `correoestudiantex` VARCHAR(50), IN `fk_idasistenciax` BIGINT, IN `fk_idestadox` BIGINT, IN `fk_idtipodocumentox` BIGINT, IN `fk_idtiposangrex` BIGINT, IN `fk_idgradox` BIGINT, IN `fk_idespecialidadx` BIGINT)  begin
Update estudiante set identificacionestudiante = identificacionestudiantex where idestudiante = idestudiantex;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarGrado` (IN `idgradox` BIGINT, IN `nombregradox` VARCHAR(50), IN `fk_iddocentex` BIGINT)  begin
Update grado set nombregrado = nombregradox where idgrado = idgradox;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarTipoActa` (IN `id_tipoactax` BIGINT, IN `nombretipoactax` VARCHAR(50))  begin
Update tipoacta set nombretipoacta = nombretipoactax where id_tipoacta = id_tipoactax;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarTipoDocente` (IN `id_tipodocentex` BIGINT, IN `nombretipodocentex` VARCHAR(50))  begin
Update tipodocente set nombretipodocente = nombretipodocentex where id_tipodocente = id_tipodocentex;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarTipoDocumento` (IN `idtipodocumentox` BIGINT, IN `nombretipodocumentox` VARCHAR(50))  begin
Update tipodocumento set nombretipodocumento = nombretipodocumentox where idtipodocumento = idtipodocumentox;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarTipoEspecialidad` (IN `idtipoespecialidadx` BIGINT, IN `nombretipoespecialidadx` VARCHAR(50))  begin
Update tipoespecialidad set nombretipoespecialidad = nombretipoespecialidadx where idtipoespecialidad = idtipoespecialidadx;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarTipoEstado` (IN `idtipoestadox` BIGINT, IN `nombretipoestadox` VARCHAR(50))  begin
Update tipoestado set nombretipoestado = nombretipoestadox where idtipoestado = idtipoestadox;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarTipoSangre` (IN `id_tipodesangrex` BIGINT, IN `nombretipodesangrex` VARCHAR(50))  begin
Update tipodesangre set nombretipodesangre = nombretipodesangrex where id_tipodesangre = id_tipodesangrex;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarTipoUsuario` (IN `idtipousuariox` BIGINT, IN `nombretipousuariox` VARCHAR(50))  begin
Update tipousuario set nombretipousuario = nombretipousuariox where idtipousuario = idtipousuariox;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarUsuario` (IN `idusuariox` BIGINT, IN `nombreusuariox` VARCHAR(50), IN `contraseñausuariox` VARCHAR(50), IN `fk_idtipousuariox` BIGINT, IN `fk_idestadox` BIGINT)  begin
Update usuario set nombreusuario = nombreusuariox where idusuario = idusuariox;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualzarDetalle_da` (IN `iddetalledax` BIGINT, IN `descripciondetalledax` VARCHAR(50), IN `fk_idacta` BIGINT, IN `fk_iddocentex` BIGINT)  begin
Update detalle_da set descripciondetalleda = descripciondetalledax where iddetalleda = iddetalledax;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActuliazarDocente` (IN `id_docentex` BIGINT, IN `identificaciondocentex` BIGINT, IN `nombredocentex` VARCHAR(50), IN `direcciondocentex` VARCHAR(50), IN `telefonofijodocentex` BIGINT, IN `telefonocelulardocentex` BIGINT, IN `correodocentex` VARCHAR(50), IN `fk_idtiposangrex` BIGINT, IN `fk_idtipodocumentox` BIGINT, IN `fk_idestadox` BIGINT, IN `fk_idtipodocente` BIGINT)  begin
Update docente set identificaciondocente = identificaciondocentex where id_docente = id_docentex;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarActa` ()  begin
select * from acta;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarAcudiente` ()  begin
select * from acudiente;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarAsistencia` ()  begin
select * from asistencia;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarDetalle_da` ()  begin
select * from detalle_da;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarDocente` ()  begin
select * from docente;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarEspecialidad_Asistencia` ()  begin
select * from especialidad_asistencia;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarEstado` ()  begin
select * from estado;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarEstudiante` ()  begin
select * from estudiante;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarGrado` ()  begin
select * from grado;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarTipoActa` ()  begin
select * from tipoacta;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarTipoDocente` ()  begin
select * from tipodocente;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarTipoDocumento` ()  begin
select * from tipodocumento;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarTipoEspecialidad` ()  begin
select * from tipoespecialidad;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarTipoEstado` ()  begin
select * from tipoestado;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarTipoSangre` ()  begin
select * from tipodesangre;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarTipoUsuario` ()  begin
select * from tipousuario;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BuscarUsuario` ()  begin
select * from usuario;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarActa` (IN `idactax` BIGINT)  begin
Delete From acta where idacta = idactax;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarAcudiente` (IN `idacudientex` BIGINT)  begin
Delete From acudiente where idacudiente = idacudientex;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarAsistencia` (IN `idasistenciax` BIGINT)  begin
Delete From asistencia where idasistencia = idasistenciax;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarDetalle_da` (IN `iddetalledax` BIGINT)  begin
Delete From detalle_da where iddetalleda = iddetalledax;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarDocente` (IN `idacudientex` BIGINT)  begin
Delete From docente where id_docente = id_docentex;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarEspecialidad` (IN `idespecialidadx` BIGINT)  begin
Delete From especialidad where idespecialidad = idespecialidadx;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarEspecialidad_Asistencia` (IN `idespecialidadasistenciax` BIGINT)  begin
Delete From especialidad_asistencia where idespecialidadasistencia = idespecialidadasistenciax;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarEstado` (IN `idestado` BIGINT)  begin
Delete From estado where idestado = idestadox;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarEstudiante` (IN `idestudiantex` BIGINT)  begin
Delete From estudiante where idestudiante = idestudiantex;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarGrado` (IN `idgradox` BIGINT)  begin
Delete From grado where idgrado = idgradox;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarTipoActa` (IN `id_tipoactax` BIGINT)  begin
Delete From tipoacta where id_tipoacta = id_tipoactax;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarTipoDocente` (IN `id_tipodocentex` BIGINT)  begin
Delete From tipodocente where id_tipodocente = id_tipodocentex;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarTipoDocumento` (IN `idtipodocumentox` BIGINT)  begin
Delete From tipodocumento where idtipodocumento = idtipodocumentox;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarTipoEspecialidad` (IN `idtipoespecialidadx` BIGINT)  begin
Delete From tipoespecialidad where idtipoespecialidad = idtipoespecialidadx;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarTipoEstado` (IN `idtipoestadox` BIGINT)  begin
Delete From tipoestado where idtipoestado = idtipoestadox;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarTipoSangre` (IN `id_tipodesangrex` BIGINT)  begin
Delete From tipodesangre where id_tipodesangre = id_tipodesangrex;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarTipoUsuario` (IN `idtipousuariox` BIGINT)  begin
Delete From tipoestado where idtipousuario = idtipousuariox;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarUsuario` (IN `idusuariox` BIGINT)  begin
Delete From usuario where idusuario = idusuariox;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertAcudiente` (IN `idacudientex` BIGINT, IN `identificacionacudientex` BIGINT, IN `nombreacudientex` VARCHAR(50), IN `direccionacudientex` VARCHAR(50), IN `telefonofijoacudientex` BIGINT, IN `telefonocelularacudientex` BIGINT, IN `correoacudientex` VARCHAR(50), IN `fk_idestadox` BIGINT, IN `fk_idtipodocumentox` BIGINT, IN `fk_idtiposangrex` BIGINT)  begin
insert into acudiente values ( idacudientex , identificacionacudientex, nombreacudientex, direccionacudientex, telefonofijoacudientex, telefonocelularacudientex, correoacudientex, fk_idestadox, fk_idtipodocumentox, fk_idtiposangrex );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarActa` (IN `idactax` BIGINT, IN `fechaactax` DATE, `fk_idtipoactax` BIGINT)  begin
insert into acta values ( idactax, fechaactax, fk_idtipoactax );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarAsistencia` (IN `idasistenciax` BIGINT, IN `fechaasistenciax` DATETIME, IN `fk_idestadox` BIGINT)  begin
insert into asistencia values ( idasistenciax , fechaasistenciax, fk_idestadox );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarEspecialidad` (IN `idespecialidadx` BIGINT, IN `nombreespecialidadx` VARCHAR(50), IN `fk_idtipoespecialidadx` BIGINT, IN `fk_idestado` BIGINT)  begin
insert into especialidad values ( idespecialidadx, nombreespecialidadx, fk_idtipoespecialidad, fk_idestado );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarEspecialidad_Asistencia` (IN `idespecialidadasistenciax` BIGINT, IN `descripcion_EAx` VARCHAR(500), IN `fk_idespecialidadx` BIGINT, IN `fk_idasistenciax` BIGINT)  begin
insert into especialidad_asistencia values ( idespecialidadasistenciax, descripcion_EAx, fk_idespecialidadx, fk_idasistenciax );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarEstado` (IN `idestadox` BIGINT, IN `nombreestadox` VARCHAR(50), IN `fk_idtipoestadox` BIGINT)  begin
insert into estado values ( idestadox , nombreestadox, fk_idtipoestadox );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarGrado` (IN `idgradox` BIGINT, IN `nombregradox` VARCHAR(50), IN `fk_iddocentex` BIGINT)  begin
insert into grado values ( idgradox , nombregradox, fk_iddocentex );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarTipoActa` (IN `id_tipoactax` BIGINT, IN `nombretipoactax` VARCHAR(50))  begin
insert into tipoacta values ( id_tipoactax , nombretipoactax );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarTipoDocente` (IN `id_tipodocentex` BIGINT, IN `nombretipodocentex` VARCHAR(50))  begin
insert into tipodocente values ( id_tipodocentex , nombretipodocentex );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarTipoDocumento` (IN `idtipodocumentox` BIGINT, IN `nombretipodocumentox` VARCHAR(50))  begin
insert into tipodocumento values ( idtipodocumentox , nombretipodocumentox );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarTipoEspecialidad` (IN `idtipoespecialidadx` BIGINT, IN `nombretipoespecialidadx` VARCHAR(50))  begin
insert into tipoespecialidad values ( idtipoespecialidadx , nombretipoespecialidadx );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarTipoEstado` (IN `idtipoestadox` BIGINT, IN `nombretipoestadox` VARCHAR(50))  begin
insert into tipoestado values ( idtipoestadox , nombretipoestadox );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarTipoSangre` (IN `id_tipodesangrex` BIGINT, IN `nombretipodesangrex` VARCHAR(50))  begin
insert into tipodesangre values ( id_tipodesangrex , nombretipodesangrex );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarTipoUsuario` (IN `idtipousuariox` BIGINT, IN `nombretipousuariox` VARCHAR(50))  begin
insert into tipoestado values ( idtipousuariox , nombretipousuariox );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarUsuario` (IN `idusuariox` BIGINT, IN `nombreusuariox` VARCHAR(50), IN `contraseñausuario` VARCHAR(50), IN `fk_idtipousuariox` BIGINT, IN `fk_idestadox` BIGINT)  begin
insert into usuario values ( idusuariox , nombreusuariox, contraseñausuariox, fk_idtipousuariox, fk_idestadox );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertDetalle_da` (IN `iddetalledax` BIGINT, IN `descripciondetalledax` VARCHAR(50), IN `fk_idacta` BIGINT, IN `fk_iddocente` BIGINT)  begin
insert into detalle_da values ( iddetalledax , descripciondetalledax, fk_idactax, fk_iddocentex );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertDocente` (IN `id_docentex` BIGINT, IN `identificaciondocentex` BIGINT, IN `nombredocentex` VARCHAR(50), IN `direcciondocentex` VARCHAR(50), IN `telefonofijodocentex` BIGINT, IN `telefonocelulardocentex` BIGINT, IN `correodocentex` VARCHAR(50), IN `fk_idtiposangrex` BIGINT, IN `fk_idtipodocumentox` BIGINT, IN `fk_idestadox` BIGINT, IN `fk_idtipodocente` BIGINT)  begin
insert into docente values ( id_docentex , identificaciondocentex, nombredocentex, direcciondocentex, telefonofijodocentex, telefonocelulardocentex, correodocentex, fk_idtiposangrex, fk_idtipodocumentox, fk_idestadox, fk_idtipodocentex );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertEstudiante` (IN `idestudiantex` BIGINT, IN `identificacionestudiantex` BIGINT, IN `nombreestudiantex` VARCHAR(50), IN `direccionestudiantex` VARCHAR(50), IN `telefonofijoestudiantex` BIGINT, IN `telefonocelularestudiantex` BIGINT, IN `correoestudiantex` VARCHAR(50), IN `fk_idasistenciax` BIGINT, IN `fk_idestadox` BIGINT, IN `fk_idtipodocumentox` BIGINT, IN `fk_idtiposangrex` BIGINT, IN `fk_idgradox` BIGINT, IN `fk_idespecialidadx` BIGINT)  begin
insert into estudiante values ( idestudiantex , identificacionestudiantex, nombreestudiantex, direccionestudiantex, telefonofijoestudiantex, telefonocelularestudiantex, correoestudiantex, fk_idasistenciax, fk_idestadox, fk_idtipodocumentox, fk_idtiposangrex, fk_idgradox, fk_idespecialidad );
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `acta`
--

CREATE TABLE `acta` (
  `idacta` bigint(20) NOT NULL,
  `fechaacta` date DEFAULT NULL,
  `fk_idtipoacta` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `acta`
--

INSERT INTO `acta` (`idacta`, `fechaacta`, `fk_idtipoacta`) VALUES
(1, '2015-09-15', 2),
(2, '2016-06-09', 5),
(3, '2014-09-17', 7),
(4, '2017-04-12', 3),
(5, '2016-06-22', 1),
(6, '2015-05-27', 4);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `acta_tipo`
--
CREATE TABLE `acta_tipo` (
`Codigo_Acta` bigint(20)
,`FechaActa` date
,`Nombre_Tipo_Acta` varchar(500)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `acudiente`
--

CREATE TABLE `acudiente` (
  `idacudiente` bigint(20) NOT NULL,
  `identificacionacudiente` bigint(50) DEFAULT NULL,
  `nombreacudiente` varchar(100) DEFAULT NULL,
  `direccionacudiente` varchar(50) DEFAULT NULL,
  `telefonofijoacudiente` bigint(20) DEFAULT NULL,
  `telefonocelularacudiente` bigint(20) DEFAULT NULL,
  `correoacudiente` varchar(100) DEFAULT NULL,
  `fk_idtipodocumento` bigint(50) NOT NULL,
  `fk_idtiposangre` bigint(50) NOT NULL,
  `fk_idestado` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `acudiente`
--

INSERT INTO `acudiente` (`idacudiente`, `identificacionacudiente`, `nombreacudiente`, `direccionacudiente`, `telefonofijoacudiente`, `telefonocelularacudiente`, `correoacudiente`, `fk_idtipodocumento`, `fk_idtiposangre`, `fk_idestado`) VALUES
(1, 1032214497, 'Marlon Moreno', 'Calle 35 # 48-98', 2016497, 3124497646, 'Marlon147@hotmail.com', 1, 2, 1),
(2, 1031478965, 'Yulian Rodriguez ', 'calle 79 # 89-47', 4587965, 318654789, 'Yulian78965@gmail.com', 1, 3, 2),
(3, 214125125, 'Michael Gomez ', 'Calle 79 # 14 ', 4569874, 32036141481, 'MiGomez@gmail.com', 1, 1, 2),
(4, 9756451231, 'Juan Molina', 'Calle falsa 170', 3059784, 31048974812, 'Juancho796@hotmail.com', 1, 2, 1),
(5, 10325698745, 'David Martinez ', 'Cra 23 # 46', 2036874, 31145649874, 'David999@hotmail.com', 1, 2, 1);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `acudiente_principal`
--
CREATE TABLE `acudiente_principal` (
`Codigo_Acudiente` bigint(20)
,`Identificacion_Acudiente` bigint(50)
,`Nombre_Acudiente` varchar(100)
,`Direccion_Acudiente` varchar(50)
,`Telefono_Fijo` bigint(20)
,`Movil_Acudiente` bigint(20)
,`Correo_Acudiente` varchar(100)
,`Tipo_Documento` varchar(50)
,`Tipo_Sangre` varchar(100)
,`EStado_Acudiente` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asistencia`
--

CREATE TABLE `asistencia` (
  `idasistencia` bigint(20) NOT NULL,
  `fechaasistencia` date DEFAULT NULL,
  `fk_idestado` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `asistencia`
--

INSERT INTO `asistencia` (`idasistencia`, `fechaasistencia`, `fk_idestado`) VALUES
(1, '2016-04-19', 3),
(2, '2015-11-11', 4),
(3, '2016-06-21', 3),
(4, '2015-11-19', 4),
(5, '2014-01-24', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asistencia_estudiante`
--

CREATE TABLE `asistencia_estudiante` (
  `idasistenciaestudiante` bigint(20) NOT NULL,
  `fk_idasistencia` bigint(50) NOT NULL,
  `fk_idestudiante` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `asistencia_estudiante`
--

INSERT INTO `asistencia_estudiante` (`idasistenciaestudiante`, `fk_idasistencia`, `fk_idestudiante`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 1),
(4, 4, 2),
(5, 5, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asistente`
--

CREATE TABLE `asistente` (
  `idasistente` bigint(20) NOT NULL,
  `identificacionasistente` bigint(50) DEFAULT NULL,
  `nombreasistente` varchar(100) DEFAULT NULL,
  `direccionasistente` varchar(50) DEFAULT NULL,
  `telefonofijoasistente` bigint(20) DEFAULT NULL,
  `telefonocelularasistente` bigint(20) DEFAULT NULL,
  `correoasistente` varchar(100) DEFAULT NULL,
  `fk_idtipodocumento` bigint(50) NOT NULL,
  `fk_idestado` bigint(50) NOT NULL,
  `fk_idtiposangre` bigint(50) NOT NULL,
  `fk_idusuario` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `asistente`
--

INSERT INTO `asistente` (`idasistente`, `identificacionasistente`, `nombreasistente`, `direccionasistente`, `telefonofijoasistente`, `telefonocelularasistente`, `correoasistente`, `fk_idtipodocumento`, `fk_idestado`, `fk_idtiposangre`, `fk_idusuario`) VALUES
(1, 1022547896, 'Lina Torres', 'Cra 12 # 45-21 ', 7986541, 31925456698, 'Linita97@gmail.com', 1, 1, 4, 2),
(2, 79312546, 'Gabriel Garcia', 'Cra 19 # 79-14', 5986321, 3214896544, 'Gabri798@yahoo.com', 1, 2, 1, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asistente_asistencia`
--

CREATE TABLE `asistente_asistencia` (
  `idasistenteasistencia` bigint(50) NOT NULL,
  `Descripcion_AA` varchar(300) NOT NULL,
  `fk_idasistente` bigint(50) NOT NULL,
  `fk_idasistencia` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `asistente_asistencia`
--

INSERT INTO `asistente_asistencia` (`idasistenteasistencia`, `Descripcion_AA`, `fk_idasistente`, `fk_idasistencia`) VALUES
(1, 'Faltaron 3 alumnos', 1, 2),
(2, 'Faltaron 2 alumnos ', 1, 5),
(3, 'Asistieron todos', 2, 3),
(4, 'Falto 1 alumno', 1, 4),
(5, 'Faltaron 5 alumnos ', 2, 1);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `asistente_asistencia_datos`
--
CREATE TABLE `asistente_asistencia_datos` (
`IdAsistente_A` bigint(50)
,`Nombre_Asis` varchar(100)
,`Identificacion_Asis` bigint(50)
,`Correo_Asis` varchar(100)
,`Movil_Asistente` bigint(20)
,`Fecha_Asistencia` date
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `asis_estudiante`
--
CREATE TABLE `asis_estudiante` (
`Id_Estu` bigint(20)
,`Nombre_Estudiante` varchar(100)
,`Fecha_asis` date
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_da`
--

CREATE TABLE `detalle_da` (
  `iddetalleda` bigint(20) NOT NULL,
  `descripciondetalleda` varchar(500) DEFAULT NULL,
  `fk_iddocente` bigint(50) NOT NULL,
  `fk_idacta` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `detalle_da`
--

INSERT INTO `detalle_da` (`iddetalleda`, `descripciondetalleda`, `fk_iddocente`, `fk_idacta`) VALUES
(1, 'Observación al estudiante por mal porte del uniforme', 3, 2),
(2, 'Se reporto la llamada realizada para el alumno', 1, 1);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `detalle_docenteacta`
--
CREATE TABLE `detalle_docenteacta` (
`Codigo_Docen` bigint(20)
,`Nombre_Docente` varchar(100)
,`Fecha_Acta` date
,`Descripcion_Acta` varchar(500)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_ea`
--

CREATE TABLE `detalle_ea` (
  `iddetalleea` bigint(20) NOT NULL,
  `descripciondetalleea` varchar(500) DEFAULT NULL,
  `fk_idacta` bigint(50) NOT NULL,
  `fk_idestudiante` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `detalle_ea`
--

INSERT INTO `detalle_ea` (`iddetalleea`, `descripciondetalleea`, `fk_idacta`, `fk_idestudiante`) VALUES
(1, 'Recibi el acta', 4, 1),
(2, 'Mi padre recibio la llamada ', 6, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `docente`
--

CREATE TABLE `docente` (
  `id_docente` bigint(20) NOT NULL,
  `identificaciondocente` bigint(50) DEFAULT NULL,
  `nombredocente` varchar(100) DEFAULT NULL,
  `direcciondocente` varchar(100) DEFAULT NULL,
  `telefonofijodocente` bigint(20) DEFAULT NULL,
  `telefonocelulardocente` bigint(20) DEFAULT NULL,
  `correodocente` varchar(100) DEFAULT NULL,
  `fk_idtipodocente` bigint(50) NOT NULL,
  `fk_idtipodocumento` bigint(50) NOT NULL,
  `fk_idestado` bigint(50) NOT NULL,
  `fk_idtiposangre` bigint(50) NOT NULL,
  `fk_idusuario` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `docente`
--

INSERT INTO `docente` (`id_docente`, `identificaciondocente`, `nombredocente`, `direcciondocente`, `telefonofijodocente`, `telefonocelulardocente`, `correodocente`, `fk_idtipodocente`, `fk_idtipodocumento`, `fk_idestado`, `fk_idtiposangre`, `fk_idusuario`) VALUES
(1, 22231, 'Jason Rodriguez', 'calle Falsa #7 -9', 6544556, 7654563432, 'JasonSoy@gmail.com', 2, 1, 1, 1, 3),
(2, 45654522, 'Ivan Cañon', 'cll 56 -67', 8767687, 2311233234, 'Ivan1149@hotmail.com', 1, 1, 1, 2, 1),
(3, 789987741, 'Jhonatan Hernandez', 'Av 87 No98', 7687667, 9876543456, 'JotanHer@hotmail.com', 2, 1, 2, 3, 4),
(4, 5642156, 'Sara Bernal', 'Avenida 1ra de mayo cra 5', 2344334, 3123455434, 'Storres@gmail.com', 2, 1, 2, 4, 5),
(5, 569874112, 'Maria Gonzales ', 'Calle 78 # 47', 21146123, 31421485459, 'Mariafer1854@hotmail.com', 3, 1, 1, 2, 6);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `docenteprincipal`
--
CREATE TABLE `docenteprincipal` (
`Codigo_Docente` bigint(20)
,`Identificacion` bigint(50)
,`Nombre_Docente` varchar(100)
,`Direccion_Docente` varchar(100)
,`Telefono` bigint(20)
,`Movil` bigint(20)
,`Correo` varchar(100)
,`Tipo_Documento` varchar(50)
,`Tipo_Sangre` varchar(100)
,`Tipo_Docente` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `docente_especialidad`
--

CREATE TABLE `docente_especialidad` (
  `iddocenteespecialidad` bigint(20) NOT NULL,
  `descripcion_de` varchar(500) DEFAULT NULL,
  `fk_iddocente` bigint(50) NOT NULL,
  `fk_idespecialidad` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `docente_especialidad`
--

INSERT INTO `docente_especialidad` (`iddocenteespecialidad`, `descripcion_de`, `fk_iddocente`, `fk_idespecialidad`) VALUES
(1, 'Media fortalecida, programación de software con vinculo con el SENA', 2, 1),
(2, 'Media fortalecida, manejo ambiental con vinculo con el SENA', 4, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `docente_grado`
--

CREATE TABLE `docente_grado` (
  `iddocentegrado` bigint(20) NOT NULL,
  `fk_iddocente` bigint(50) NOT NULL,
  `fk_idgrado` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `docente_grado`
--

INSERT INTO `docente_grado` (`iddocentegrado`, `fk_iddocente`, `fk_idgrado`) VALUES
(1, 2, 3),
(2, 3, 1),
(3, 1, 4),
(4, 4, 5),
(5, 5, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `especialidad`
--

CREATE TABLE `especialidad` (
  `idespecialidad` bigint(20) NOT NULL,
  `nombreespecialidad` varchar(500) DEFAULT NULL,
  `fk_idtipoespecialidad` bigint(50) NOT NULL,
  `fk_idestado` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `especialidad`
--

INSERT INTO `especialidad` (`idespecialidad`, `nombreespecialidad`, `fk_idtipoespecialidad`, `fk_idestado`) VALUES
(1, 'Programación de software ', 1, 1),
(2, 'Diseño integral multimedia', 1, 2),
(3, 'Manejo Ambiental', 1, 1),
(4, 'Administración de empresas', 2, 2),
(5, 'Administración turística y hotelera', 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `especialidad_asistencia`
--

CREATE TABLE `especialidad_asistencia` (
  `idespecialidadasistencia` bigint(20) NOT NULL,
  `descripcion_EA` varchar(500) DEFAULT NULL,
  `fk_idespecialidad` bigint(50) NOT NULL,
  `fk_idasistencia` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `especialidad_asistencia`
--

INSERT INTO `especialidad_asistencia` (`idespecialidadasistencia`, `descripcion_EA`, `fk_idespecialidad`, `fk_idasistencia`) VALUES
(1, 'El estudiante se encontraba enfermo', 1, 1),
(2, 'El estudiante asistio de manera satisfactoria', 4, 2);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `especialidad_estudiante`
--
CREATE TABLE `especialidad_estudiante` (
`Codigo_Estudiante` bigint(20)
,`Nombre_Estudiante` varchar(100)
,`Nombre_Especialidad` varchar(500)
,`Nombre_TipoEspecialidad` varchar(500)
,`NombreDelGrado` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `especialidad_tiposena`
--
CREATE TABLE `especialidad_tiposena` (
`Codigo_Especialidad` bigint(20)
,`Nombre_Especialidad` varchar(500)
,`Nombre_Tipoespecialidad` varchar(500)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `especialidad_tipouniminuto`
--
CREATE TABLE `especialidad_tipouniminuto` (
`Codigo_Especialidad` bigint(20)
,`Nombre_Especialidad` varchar(500)
,`Nombre_Tipoespecialidad` varchar(500)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE `estado` (
  `idestado` bigint(20) NOT NULL,
  `nombreestado` varchar(50) DEFAULT NULL,
  `fk_idtipoestado` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `estado`
--

INSERT INTO `estado` (`idestado`, `nombreestado`, `fk_idtipoestado`) VALUES
(1, 'Activo', 1),
(2, 'Inactivo', 1),
(3, 'Asistio', 2),
(4, 'No asistio', 2);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `estadoacudienteactivo`
--
CREATE TABLE `estadoacudienteactivo` (
`Codigo_Acudiente` bigint(20)
,`Estado` varchar(50)
,`Nombre_Acudiente` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `estadoacudienteinactivo`
--
CREATE TABLE `estadoacudienteinactivo` (
`Codigo_Acudiente` bigint(20)
,`Estado` varchar(50)
,`Nombre_Acudiente` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `estadoasistenteactivo`
--
CREATE TABLE `estadoasistenteactivo` (
`Codigo_Asistente` bigint(20)
,`Estado_Asistente` varchar(50)
,`Nombre_Asistente` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `estadoasistenteinactivo`
--
CREATE TABLE `estadoasistenteinactivo` (
`Codigo_Asistente` bigint(20)
,`Estado_Asistente` varchar(50)
,`Nombre_Asistente` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `estadodocenteactivo`
--
CREATE TABLE `estadodocenteactivo` (
`Codigo_Docente` bigint(20)
,`Estado` varchar(50)
,`Nombre_Docente` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `estadodocenteinactivo`
--
CREATE TABLE `estadodocenteinactivo` (
`Codigo_Docente` bigint(20)
,`Estado` varchar(50)
,`Nombre_Docente` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `estadoestudianteactivo`
--
CREATE TABLE `estadoestudianteactivo` (
`Codigo_Estudiante` bigint(20)
,`Estado` varchar(50)
,`Nombre_Estudiante` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `estadoestudianteinactivo`
--
CREATE TABLE `estadoestudianteinactivo` (
`Codigo_Estudiante` bigint(20)
,`Estado` varchar(50)
,`Nombre_Estudiante` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiante`
--

CREATE TABLE `estudiante` (
  `idestudiante` bigint(20) NOT NULL,
  `identificacionestudiante` bigint(50) DEFAULT NULL,
  `nombreestudiante` varchar(100) DEFAULT NULL,
  `direccionestudiante` varchar(50) DEFAULT NULL,
  `telefonofijoestudiante` bigint(20) DEFAULT NULL,
  `telefonocelularestudiante` bigint(20) DEFAULT NULL,
  `correoestudiante` varchar(100) DEFAULT NULL,
  `fk_idtipodocumento` bigint(50) NOT NULL,
  `fk_idestado` bigint(50) NOT NULL,
  `fk_idtiposangre` bigint(50) NOT NULL,
  `fk_idasistencia` bigint(50) NOT NULL,
  `fk_idgrado` bigint(50) NOT NULL,
  `fk_idespecialidad` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `estudiante`
--

INSERT INTO `estudiante` (`idestudiante`, `identificacionestudiante`, `nombreestudiante`, `direccionestudiante`, `telefonofijoestudiante`, `telefonocelularestudiante`, `correoestudiante`, `fk_idtipodocumento`, `fk_idestado`, `fk_idtiposangre`, `fk_idasistencia`, `fk_idgrado`, `fk_idespecialidad`) VALUES
(1, 9911224455, 'Pepito Perez', 'Calle simpre viva 7-2', 22336654, 31225446698, 'pepito@live.com', 2, 1, 1, 2, 4, 5),
(2, 88446332111, 'Juan Perez', 'N 13 bis 15 norte', 44223115, 2332144456, 'Juan@hotmail.com', 1, 2, 4, 2, 1, 4);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `estudianteprincipal`
--
CREATE TABLE `estudianteprincipal` (
`Codigo_estudiante` bigint(20)
,`Identificacion_E` bigint(50)
,`Nombre_Estudiante` varchar(100)
,`Telefono_E` bigint(20)
,`Movil_E` bigint(20)
,`Correo_E` varchar(100)
,`Tipo_Documento` varchar(50)
,`Tipo_Sangre` varchar(100)
,`Especialidad_E` varchar(500)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiante_acudiente`
--

CREATE TABLE `estudiante_acudiente` (
  `idestudianteacudiente` bigint(50) NOT NULL,
  `fk_idestudiante` bigint(50) NOT NULL,
  `fk_idacudiente` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `estudiante_acudiente`
--

INSERT INTO `estudiante_acudiente` (`idestudianteacudiente`, `fk_idestudiante`, `fk_idacudiente`) VALUES
(1, 1, 3),
(2, 2, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grado`
--

CREATE TABLE `grado` (
  `idgrado` bigint(20) NOT NULL,
  `nombregrado` varchar(100) DEFAULT NULL,
  `fk_idespecialidad` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `grado`
--

INSERT INTO `grado` (`idgrado`, `nombregrado`, `fk_idespecialidad`) VALUES
(1, '11-02', 5),
(2, '10-03', 2),
(3, '10-01', 4),
(4, '11-03', 3),
(5, '11-01', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipoacta`
--

CREATE TABLE `tipoacta` (
  `id_tipoacta` bigint(20) NOT NULL,
  `nombretipoacta` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipoacta`
--

INSERT INTO `tipoacta` (`id_tipoacta`, `nombretipoacta`) VALUES
(1, 'Observador'),
(2, 'Rectoria'),
(3, 'Acta'),
(4, 'Reporte Llamadas '),
(5, 'Asistencias'),
(6, 'Excusas'),
(7, 'Cancelación');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipodesangre`
--

CREATE TABLE `tipodesangre` (
  `id_tipodesangre` bigint(20) NOT NULL,
  `nombretipodesangre` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipodesangre`
--

INSERT INTO `tipodesangre` (`id_tipodesangre`, `nombretipodesangre`) VALUES
(1, 'A+'),
(2, 'O+'),
(3, 'B+'),
(4, 'AB+'),
(5, 'A-');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipodocente`
--

CREATE TABLE `tipodocente` (
  `id_tipodocente` bigint(20) NOT NULL,
  `nombretipodocente` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipodocente`
--

INSERT INTO `tipodocente` (`id_tipodocente`, `nombretipodocente`) VALUES
(1, 'Coordinador'),
(2, 'Instructor Sena'),
(3, 'Docente Institucion');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipodocumento`
--

CREATE TABLE `tipodocumento` (
  `idtipodocumento` bigint(20) NOT NULL,
  `nombretipodocumento` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipodocumento`
--

INSERT INTO `tipodocumento` (`idtipodocumento`, `nombretipodocumento`) VALUES
(1, 'Cedula de ciudadania'),
(2, 'Tarjeta de identidad');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipoespecialidad`
--

CREATE TABLE `tipoespecialidad` (
  `idtipoespecialidad` bigint(20) NOT NULL,
  `nombretipoespecialidad` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipoespecialidad`
--

INSERT INTO `tipoespecialidad` (`idtipoespecialidad`, `nombretipoespecialidad`) VALUES
(1, 'Sena'),
(2, 'uniminuto');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipoestado`
--

CREATE TABLE `tipoestado` (
  `idtipoestado` bigint(20) NOT NULL,
  `nombretipoestado` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipoestado`
--

INSERT INTO `tipoestado` (`idtipoestado`, `nombretipoestado`) VALUES
(1, 'General'),
(2, 'Asistencia');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipousuario`
--

CREATE TABLE `tipousuario` (
  `idtipousuario` bigint(20) NOT NULL,
  `nombretipousuario` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipousuario`
--

INSERT INTO `tipousuario` (`idtipousuario`, `nombretipousuario`) VALUES
(1, 'Coordinador'),
(2, 'Asistente'),
(3, 'Docente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `idusuario` bigint(20) NOT NULL,
  `nombreusuario` varchar(100) DEFAULT NULL,
  `contraseñausuario` varchar(100) DEFAULT NULL,
  `fk_idtipousuario` bigint(50) NOT NULL,
  `fk_idestado` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`idusuario`, `nombreusuario`, `contraseñausuario`, `fk_idtipousuario`, `fk_idestado`) VALUES
(1, 'Ivan123', '123456789', 1, 1),
(2, 'Linita456', '987654321', 2, 2),
(3, 'Jason7946 ', '123456', 3, 1),
(4, 'Jhotan156456', 'SoloRAp7979', 3, 1),
(5, 'Sarita12345', '12354Sara', 3, 1),
(6, 'Mariafer', 'maria145987', 3, 1),
(7, 'camila9874', '9746521', 2, 1),
(8, 'Gabriel12', '456321', 2, 1);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `usuario_docente`
--
CREATE TABLE `usuario_docente` (
`Codigo_Docente` bigint(20)
,`Nombre_Docente` varchar(100)
,`Nombre_Usuario` varchar(100)
,`Contraseña_U` varchar(100)
,`Tipo_Usuario` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `usuario_estado_tipo`
--
CREATE TABLE `usuario_estado_tipo` (
`Codigo_Usuario` bigint(20)
,`Nombre_Usuario` varchar(100)
,`Contraseña_usuario` varchar(100)
,`Nombre_Estado` varchar(50)
,`Nombre_TipoUsuario` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `acta_tipo`
--
DROP TABLE IF EXISTS `acta_tipo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `acta_tipo`  AS  select `acta`.`idacta` AS `Codigo_Acta`,`acta`.`fechaacta` AS `FechaActa`,`tipoacta`.`nombretipoacta` AS `Nombre_Tipo_Acta` from (`acta` join `tipoacta`) where (`acta`.`fk_idtipoacta` = `tipoacta`.`id_tipoacta`) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `acudiente_principal`
--
DROP TABLE IF EXISTS `acudiente_principal`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `acudiente_principal`  AS  select `acudiente`.`idacudiente` AS `Codigo_Acudiente`,`acudiente`.`identificacionacudiente` AS `Identificacion_Acudiente`,`acudiente`.`nombreacudiente` AS `Nombre_Acudiente`,`acudiente`.`direccionacudiente` AS `Direccion_Acudiente`,`acudiente`.`telefonofijoacudiente` AS `Telefono_Fijo`,`acudiente`.`telefonocelularacudiente` AS `Movil_Acudiente`,`acudiente`.`correoacudiente` AS `Correo_Acudiente`,`tipodocumento`.`nombretipodocumento` AS `Tipo_Documento`,`tipodesangre`.`nombretipodesangre` AS `Tipo_Sangre`,`estado`.`nombreestado` AS `EStado_Acudiente` from (((`acudiente` join `tipodocumento` on((`acudiente`.`fk_idtipodocumento` = `tipodocumento`.`idtipodocumento`))) join `tipodesangre` on((`acudiente`.`fk_idtiposangre` = `tipodesangre`.`id_tipodesangre`))) join `estado` on((`acudiente`.`fk_idestado` = `estado`.`idestado`))) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `asistente_asistencia_datos`
--
DROP TABLE IF EXISTS `asistente_asistencia_datos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `asistente_asistencia_datos`  AS  select `asistente_asistencia`.`idasistenteasistencia` AS `IdAsistente_A`,`asistente`.`nombreasistente` AS `Nombre_Asis`,`asistente`.`identificacionasistente` AS `Identificacion_Asis`,`asistente`.`correoasistente` AS `Correo_Asis`,`asistente`.`telefonocelularasistente` AS `Movil_Asistente`,`asistencia`.`fechaasistencia` AS `Fecha_Asistencia` from ((`asistente_asistencia` join `asistente` on((`asistente_asistencia`.`fk_idasistente` = `asistente`.`idasistente`))) join `asistencia` on((`asistente_asistencia`.`fk_idasistencia` = `asistencia`.`idasistencia`))) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `asis_estudiante`
--
DROP TABLE IF EXISTS `asis_estudiante`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `asis_estudiante`  AS  select `estudiante`.`idestudiante` AS `Id_Estu`,`estudiante`.`nombreestudiante` AS `Nombre_Estudiante`,`asistencia`.`fechaasistencia` AS `Fecha_asis` from (`estudiante` join `asistencia`) where (`estudiante`.`fk_idasistencia` = `asistencia`.`idasistencia`) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `detalle_docenteacta`
--
DROP TABLE IF EXISTS `detalle_docenteacta`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `detalle_docenteacta`  AS  select `docente`.`id_docente` AS `Codigo_Docen`,`docente`.`nombredocente` AS `Nombre_Docente`,`acta`.`fechaacta` AS `Fecha_Acta`,`detalle_da`.`descripciondetalleda` AS `Descripcion_Acta` from ((`detalle_da` join `docente` on((`detalle_da`.`fk_iddocente` = `docente`.`id_docente`))) join `acta` on((`detalle_da`.`fk_idacta` = `acta`.`idacta`))) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `docenteprincipal`
--
DROP TABLE IF EXISTS `docenteprincipal`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `docenteprincipal`  AS  select `docente`.`id_docente` AS `Codigo_Docente`,`docente`.`identificaciondocente` AS `Identificacion`,`docente`.`nombredocente` AS `Nombre_Docente`,`docente`.`direcciondocente` AS `Direccion_Docente`,`docente`.`telefonofijodocente` AS `Telefono`,`docente`.`telefonocelulardocente` AS `Movil`,`docente`.`correodocente` AS `Correo`,`tipodocumento`.`nombretipodocumento` AS `Tipo_Documento`,`tipodesangre`.`nombretipodesangre` AS `Tipo_Sangre`,`tipodocente`.`nombretipodocente` AS `Tipo_Docente` from ((((`docente` join `estado` on((`docente`.`fk_idestado` = `estado`.`idestado`))) join `tipodocumento` on((`docente`.`fk_idtipodocumento` = `tipodocumento`.`idtipodocumento`))) join `tipodesangre` on((`docente`.`fk_idtiposangre` = `tipodesangre`.`id_tipodesangre`))) join `tipodocente` on((`docente`.`fk_idtipodocente` = `tipodocente`.`id_tipodocente`))) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `especialidad_estudiante`
--
DROP TABLE IF EXISTS `especialidad_estudiante`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `especialidad_estudiante`  AS  select `estudiante`.`idestudiante` AS `Codigo_Estudiante`,`estudiante`.`nombreestudiante` AS `Nombre_Estudiante`,`especialidad`.`nombreespecialidad` AS `Nombre_Especialidad`,`tipoespecialidad`.`nombretipoespecialidad` AS `Nombre_TipoEspecialidad`,`grado`.`nombregrado` AS `NombreDelGrado` from (((`estudiante` join `especialidad` on((`estudiante`.`fk_idespecialidad` = `especialidad`.`idespecialidad`))) join `tipoespecialidad` on((`especialidad`.`fk_idtipoespecialidad` = `tipoespecialidad`.`idtipoespecialidad`))) join `grado` on((`estudiante`.`fk_idgrado` = `grado`.`idgrado`))) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `especialidad_tiposena`
--
DROP TABLE IF EXISTS `especialidad_tiposena`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `especialidad_tiposena`  AS  select `especialidad`.`idespecialidad` AS `Codigo_Especialidad`,`especialidad`.`nombreespecialidad` AS `Nombre_Especialidad`,`tipoespecialidad`.`nombretipoespecialidad` AS `Nombre_Tipoespecialidad` from (`especialidad` join `tipoespecialidad`) where ((`especialidad`.`fk_idtipoespecialidad` = `tipoespecialidad`.`idtipoespecialidad`) and (`tipoespecialidad`.`nombretipoespecialidad` = 'Sena')) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `especialidad_tipouniminuto`
--
DROP TABLE IF EXISTS `especialidad_tipouniminuto`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `especialidad_tipouniminuto`  AS  select `especialidad`.`idespecialidad` AS `Codigo_Especialidad`,`especialidad`.`nombreespecialidad` AS `Nombre_Especialidad`,`tipoespecialidad`.`nombretipoespecialidad` AS `Nombre_Tipoespecialidad` from (`especialidad` join `tipoespecialidad`) where ((`especialidad`.`fk_idtipoespecialidad` = `tipoespecialidad`.`idtipoespecialidad`) and (`tipoespecialidad`.`nombretipoespecialidad` = 'Uniminuto')) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `estadoacudienteactivo`
--
DROP TABLE IF EXISTS `estadoacudienteactivo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `estadoacudienteactivo`  AS  select `acudiente`.`idacudiente` AS `Codigo_Acudiente`,`estado`.`nombreestado` AS `Estado`,`acudiente`.`nombreacudiente` AS `Nombre_Acudiente` from (`acudiente` join `estado`) where ((`acudiente`.`fk_idestado` = `estado`.`idestado`) and (`estado`.`nombreestado` = 'Activo')) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `estadoacudienteinactivo`
--
DROP TABLE IF EXISTS `estadoacudienteinactivo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `estadoacudienteinactivo`  AS  select `acudiente`.`idacudiente` AS `Codigo_Acudiente`,`estado`.`nombreestado` AS `Estado`,`acudiente`.`nombreacudiente` AS `Nombre_Acudiente` from (`acudiente` join `estado`) where ((`acudiente`.`fk_idestado` = `estado`.`idestado`) and (`estado`.`nombreestado` = 'Inactivo')) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `estadoasistenteactivo`
--
DROP TABLE IF EXISTS `estadoasistenteactivo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `estadoasistenteactivo`  AS  select `asistente`.`idasistente` AS `Codigo_Asistente`,`estado`.`nombreestado` AS `Estado_Asistente`,`asistente`.`nombreasistente` AS `Nombre_Asistente` from (`asistente` join `estado`) where ((`asistente`.`fk_idestado` = `estado`.`idestado`) and (`estado`.`nombreestado` = 'Activo')) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `estadoasistenteinactivo`
--
DROP TABLE IF EXISTS `estadoasistenteinactivo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `estadoasistenteinactivo`  AS  select `asistente`.`idasistente` AS `Codigo_Asistente`,`estado`.`nombreestado` AS `Estado_Asistente`,`asistente`.`nombreasistente` AS `Nombre_Asistente` from (`asistente` join `estado`) where ((`asistente`.`fk_idestado` = `estado`.`idestado`) and (`estado`.`nombreestado` = 'Inactivo')) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `estadodocenteactivo`
--
DROP TABLE IF EXISTS `estadodocenteactivo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `estadodocenteactivo`  AS  select `docente`.`id_docente` AS `Codigo_Docente`,`estado`.`nombreestado` AS `Estado`,`docente`.`nombredocente` AS `Nombre_Docente` from (`docente` join `estado`) where ((`docente`.`fk_idestado` = `estado`.`idestado`) and (`estado`.`nombreestado` = 'Activo')) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `estadodocenteinactivo`
--
DROP TABLE IF EXISTS `estadodocenteinactivo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `estadodocenteinactivo`  AS  select `docente`.`id_docente` AS `Codigo_Docente`,`estado`.`nombreestado` AS `Estado`,`docente`.`nombredocente` AS `Nombre_Docente` from (`docente` join `estado`) where ((`docente`.`fk_idestado` = `estado`.`idestado`) and (`estado`.`nombreestado` = 'Inactivo')) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `estadoestudianteactivo`
--
DROP TABLE IF EXISTS `estadoestudianteactivo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `estadoestudianteactivo`  AS  select `estudiante`.`idestudiante` AS `Codigo_Estudiante`,`estado`.`nombreestado` AS `Estado`,`estudiante`.`nombreestudiante` AS `Nombre_Estudiante` from (`estudiante` join `estado`) where ((`estudiante`.`fk_idestado` = `estado`.`idestado`) and (`estado`.`nombreestado` = 'Activo')) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `estadoestudianteinactivo`
--
DROP TABLE IF EXISTS `estadoestudianteinactivo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `estadoestudianteinactivo`  AS  select `estudiante`.`idestudiante` AS `Codigo_Estudiante`,`estado`.`nombreestado` AS `Estado`,`estudiante`.`nombreestudiante` AS `Nombre_Estudiante` from (`estudiante` join `estado`) where ((`estudiante`.`fk_idestado` = `estado`.`idestado`) and (`estado`.`nombreestado` = 'Inactivo')) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `estudianteprincipal`
--
DROP TABLE IF EXISTS `estudianteprincipal`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `estudianteprincipal`  AS  select `estudiante`.`idestudiante` AS `Codigo_estudiante`,`estudiante`.`identificacionestudiante` AS `Identificacion_E`,`estudiante`.`nombreestudiante` AS `Nombre_Estudiante`,`estudiante`.`telefonofijoestudiante` AS `Telefono_E`,`estudiante`.`telefonocelularestudiante` AS `Movil_E`,`estudiante`.`correoestudiante` AS `Correo_E`,`tipodocumento`.`nombretipodocumento` AS `Tipo_Documento`,`tipodesangre`.`nombretipodesangre` AS `Tipo_Sangre`,`especialidad`.`nombreespecialidad` AS `Especialidad_E` from (((`estudiante` join `tipodocumento` on((`estudiante`.`fk_idtipodocumento` = `tipodocumento`.`idtipodocumento`))) join `tipodesangre` on((`estudiante`.`fk_idtiposangre` = `tipodesangre`.`id_tipodesangre`))) join `especialidad` on((`estudiante`.`fk_idespecialidad` = `especialidad`.`idespecialidad`))) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `usuario_docente`
--
DROP TABLE IF EXISTS `usuario_docente`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `usuario_docente`  AS  select `docente`.`id_docente` AS `Codigo_Docente`,`docente`.`nombredocente` AS `Nombre_Docente`,`usuario`.`nombreusuario` AS `Nombre_Usuario`,`usuario`.`contraseñausuario` AS `Contraseña_U`,`tipousuario`.`nombretipousuario` AS `Tipo_Usuario` from ((`docente` join `usuario` on((`docente`.`fk_idusuario` = `usuario`.`idusuario`))) join `tipousuario` on((`usuario`.`fk_idtipousuario` = `tipousuario`.`idtipousuario`))) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `usuario_estado_tipo`
--
DROP TABLE IF EXISTS `usuario_estado_tipo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `usuario_estado_tipo`  AS  select `usuario`.`idusuario` AS `Codigo_Usuario`,`usuario`.`nombreusuario` AS `Nombre_Usuario`,`usuario`.`contraseñausuario` AS `Contraseña_usuario`,`estado`.`nombreestado` AS `Nombre_Estado`,`tipousuario`.`nombretipousuario` AS `Nombre_TipoUsuario` from ((`usuario` join `estado` on((`usuario`.`fk_idestado` = `estado`.`idestado`))) join `tipousuario` on((`usuario`.`fk_idtipousuario` = `tipousuario`.`idtipousuario`))) ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `acta`
--
ALTER TABLE `acta`
  ADD PRIMARY KEY (`idacta`),
  ADD KEY `tipoacta_acta` (`fk_idtipoacta`);

--
-- Indices de la tabla `acudiente`
--
ALTER TABLE `acudiente`
  ADD PRIMARY KEY (`idacudiente`),
  ADD KEY `acudiante_tipoD` (`fk_idtipodocumento`),
  ADD KEY `acudiante_tipoS` (`fk_idtiposangre`),
  ADD KEY `Acudiente_Estado` (`fk_idestado`);

--
-- Indices de la tabla `asistencia`
--
ALTER TABLE `asistencia`
  ADD PRIMARY KEY (`idasistencia`),
  ADD KEY `asistencia_estado` (`fk_idestado`);

--
-- Indices de la tabla `asistencia_estudiante`
--
ALTER TABLE `asistencia_estudiante`
  ADD PRIMARY KEY (`idasistenciaestudiante`),
  ADD KEY `AcudienteE_Asis` (`fk_idasistencia`),
  ADD KEY `estudianteA_Asis` (`fk_idestudiante`);

--
-- Indices de la tabla `asistente`
--
ALTER TABLE `asistente`
  ADD PRIMARY KEY (`idasistente`),
  ADD KEY `asistente_tipoD` (`fk_idtipodocumento`),
  ADD KEY `asistente_estado` (`fk_idestado`),
  ADD KEY `asistente_tipoS` (`fk_idtiposangre`);

--
-- Indices de la tabla `asistente_asistencia`
--
ALTER TABLE `asistente_asistencia`
  ADD PRIMARY KEY (`idasistenteasistencia`),
  ADD KEY `Asistente_Asistencia_A` (`fk_idasistente`),
  ADD KEY `Asistencia_Asistente_A` (`fk_idasistencia`);

--
-- Indices de la tabla `detalle_da`
--
ALTER TABLE `detalle_da`
  ADD PRIMARY KEY (`iddetalleda`),
  ADD KEY `detalleda_docente` (`fk_iddocente`),
  ADD KEY `detalleda_acta` (`fk_idacta`);

--
-- Indices de la tabla `detalle_ea`
--
ALTER TABLE `detalle_ea`
  ADD PRIMARY KEY (`iddetalleea`),
  ADD KEY `DetalleEA_Acta` (`fk_idacta`),
  ADD KEY `DetalleEA_estudiante` (`fk_idestudiante`);

--
-- Indices de la tabla `docente`
--
ALTER TABLE `docente`
  ADD PRIMARY KEY (`id_docente`),
  ADD KEY `tipodocente_docente` (`fk_idtipodocente`),
  ADD KEY `docente_tipoD` (`fk_idtipodocumento`),
  ADD KEY `docente_estado` (`fk_idestado`),
  ADD KEY `docente_tipoS` (`fk_idtiposangre`),
  ADD KEY `docente_usuario` (`fk_idusuario`);

--
-- Indices de la tabla `docente_especialidad`
--
ALTER TABLE `docente_especialidad`
  ADD PRIMARY KEY (`iddocenteespecialidad`),
  ADD KEY `docenespe_docente` (`fk_iddocente`),
  ADD KEY `docenespe_especialidad` (`fk_idespecialidad`);

--
-- Indices de la tabla `docente_grado`
--
ALTER TABLE `docente_grado`
  ADD PRIMARY KEY (`iddocentegrado`),
  ADD KEY `docengrad_docente` (`fk_iddocente`),
  ADD KEY `docengrado_grado` (`fk_idgrado`);

--
-- Indices de la tabla `especialidad`
--
ALTER TABLE `especialidad`
  ADD PRIMARY KEY (`idespecialidad`),
  ADD KEY `especialidad_tipoE` (`fk_idtipoespecialidad`),
  ADD KEY `especialidad_estado` (`fk_idestado`);

--
-- Indices de la tabla `especialidad_asistencia`
--
ALTER TABLE `especialidad_asistencia`
  ADD PRIMARY KEY (`idespecialidadasistencia`),
  ADD KEY `especiA_asistencia` (`fk_idespecialidad`),
  ADD KEY `especiAsiet_asisten` (`fk_idasistencia`);

--
-- Indices de la tabla `estado`
--
ALTER TABLE `estado`
  ADD PRIMARY KEY (`idestado`),
  ADD KEY `Estado_tipoE` (`fk_idtipoestado`);

--
-- Indices de la tabla `estudiante`
--
ALTER TABLE `estudiante`
  ADD PRIMARY KEY (`idestudiante`),
  ADD KEY `estudiante_tipoD` (`fk_idtipodocumento`),
  ADD KEY `estudiante_estado` (`fk_idestado`),
  ADD KEY `estudiante_tipoS` (`fk_idtiposangre`),
  ADD KEY `estudiante_asistencia` (`fk_idasistencia`),
  ADD KEY `estudiante_grado` (`fk_idgrado`),
  ADD KEY `estudiante_especialidad` (`fk_idespecialidad`);

--
-- Indices de la tabla `estudiante_acudiente`
--
ALTER TABLE `estudiante_acudiente`
  ADD PRIMARY KEY (`idestudianteacudiente`),
  ADD KEY `estudiante_estudiante_A` (`fk_idestudiante`),
  ADD KEY `acudiente_estudiante_A` (`fk_idacudiente`);

--
-- Indices de la tabla `grado`
--
ALTER TABLE `grado`
  ADD PRIMARY KEY (`idgrado`),
  ADD KEY `Grado_Especialidad` (`fk_idespecialidad`);

--
-- Indices de la tabla `tipoacta`
--
ALTER TABLE `tipoacta`
  ADD PRIMARY KEY (`id_tipoacta`);

--
-- Indices de la tabla `tipodesangre`
--
ALTER TABLE `tipodesangre`
  ADD PRIMARY KEY (`id_tipodesangre`);

--
-- Indices de la tabla `tipodocente`
--
ALTER TABLE `tipodocente`
  ADD PRIMARY KEY (`id_tipodocente`);

--
-- Indices de la tabla `tipodocumento`
--
ALTER TABLE `tipodocumento`
  ADD PRIMARY KEY (`idtipodocumento`);

--
-- Indices de la tabla `tipoespecialidad`
--
ALTER TABLE `tipoespecialidad`
  ADD PRIMARY KEY (`idtipoespecialidad`);

--
-- Indices de la tabla `tipoestado`
--
ALTER TABLE `tipoestado`
  ADD PRIMARY KEY (`idtipoestado`);

--
-- Indices de la tabla `tipousuario`
--
ALTER TABLE `tipousuario`
  ADD PRIMARY KEY (`idtipousuario`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`idusuario`),
  ADD KEY `Usuario_TipoU` (`fk_idtipousuario`),
  ADD KEY `usuario_estado` (`fk_idestado`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `acta`
--
ALTER TABLE `acta`
  MODIFY `idacta` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `acudiente`
--
ALTER TABLE `acudiente`
  MODIFY `idacudiente` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `asistencia`
--
ALTER TABLE `asistencia`
  MODIFY `idasistencia` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `asistencia_estudiante`
--
ALTER TABLE `asistencia_estudiante`
  MODIFY `idasistenciaestudiante` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `asistente`
--
ALTER TABLE `asistente`
  MODIFY `idasistente` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `asistente_asistencia`
--
ALTER TABLE `asistente_asistencia`
  MODIFY `idasistenteasistencia` bigint(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `detalle_da`
--
ALTER TABLE `detalle_da`
  MODIFY `iddetalleda` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `detalle_ea`
--
ALTER TABLE `detalle_ea`
  MODIFY `iddetalleea` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `docente`
--
ALTER TABLE `docente`
  MODIFY `id_docente` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `docente_especialidad`
--
ALTER TABLE `docente_especialidad`
  MODIFY `iddocenteespecialidad` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `docente_grado`
--
ALTER TABLE `docente_grado`
  MODIFY `iddocentegrado` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `especialidad`
--
ALTER TABLE `especialidad`
  MODIFY `idespecialidad` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `especialidad_asistencia`
--
ALTER TABLE `especialidad_asistencia`
  MODIFY `idespecialidadasistencia` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `estado`
--
ALTER TABLE `estado`
  MODIFY `idestado` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `estudiante`
--
ALTER TABLE `estudiante`
  MODIFY `idestudiante` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `estudiante_acudiente`
--
ALTER TABLE `estudiante_acudiente`
  MODIFY `idestudianteacudiente` bigint(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `grado`
--
ALTER TABLE `grado`
  MODIFY `idgrado` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `tipoacta`
--
ALTER TABLE `tipoacta`
  MODIFY `id_tipoacta` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de la tabla `tipodesangre`
--
ALTER TABLE `tipodesangre`
  MODIFY `id_tipodesangre` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `tipodocente`
--
ALTER TABLE `tipodocente`
  MODIFY `id_tipodocente` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `tipodocumento`
--
ALTER TABLE `tipodocumento`
  MODIFY `idtipodocumento` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `tipoespecialidad`
--
ALTER TABLE `tipoespecialidad`
  MODIFY `idtipoespecialidad` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `tipoestado`
--
ALTER TABLE `tipoestado`
  MODIFY `idtipoestado` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `tipousuario`
--
ALTER TABLE `tipousuario`
  MODIFY `idtipousuario` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idusuario` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `acta`
--
ALTER TABLE `acta`
  ADD CONSTRAINT `tipoacta_acta` FOREIGN KEY (`fk_idtipoacta`) REFERENCES `tipoacta` (`id_tipoacta`);

--
-- Filtros para la tabla `acudiente`
--
ALTER TABLE `acudiente`
  ADD CONSTRAINT `acudiante_tipoD` FOREIGN KEY (`fk_idtipodocumento`) REFERENCES `tipodocumento` (`idtipodocumento`),
  ADD CONSTRAINT `acudiante_tipoS` FOREIGN KEY (`fk_idtiposangre`) REFERENCES `tipodesangre` (`id_tipodesangre`),
  ADD CONSTRAINT `acudiente_ibfk_1` FOREIGN KEY (`fk_idestado`) REFERENCES `estado` (`idestado`);

--
-- Filtros para la tabla `asistencia`
--
ALTER TABLE `asistencia`
  ADD CONSTRAINT `asistencia_estado` FOREIGN KEY (`fk_idestado`) REFERENCES `estado` (`idestado`);

--
-- Filtros para la tabla `asistencia_estudiante`
--
ALTER TABLE `asistencia_estudiante`
  ADD CONSTRAINT `asistencia_estudiante_ibfk_1` FOREIGN KEY (`fk_idasistencia`) REFERENCES `asistencia` (`idasistencia`),
  ADD CONSTRAINT `asistencia_estudiante_ibfk_2` FOREIGN KEY (`fk_idestudiante`) REFERENCES `estudiante` (`idestudiante`);

--
-- Filtros para la tabla `asistente`
--
ALTER TABLE `asistente`
  ADD CONSTRAINT `asistente_estado` FOREIGN KEY (`fk_idestado`) REFERENCES `estado` (`idestado`),
  ADD CONSTRAINT `asistente_tipoD` FOREIGN KEY (`fk_idtipodocumento`) REFERENCES `tipodocumento` (`idtipodocumento`),
  ADD CONSTRAINT `asistente_tipoS` FOREIGN KEY (`fk_idtiposangre`) REFERENCES `tipodesangre` (`id_tipodesangre`);

--
-- Filtros para la tabla `asistente_asistencia`
--
ALTER TABLE `asistente_asistencia`
  ADD CONSTRAINT `asistente_asistencia_ibfk_1` FOREIGN KEY (`fk_idasistente`) REFERENCES `asistente` (`idasistente`),
  ADD CONSTRAINT `asistente_asistencia_ibfk_2` FOREIGN KEY (`fk_idasistencia`) REFERENCES `asistencia` (`idasistencia`);

--
-- Filtros para la tabla `detalle_da`
--
ALTER TABLE `detalle_da`
  ADD CONSTRAINT `detalleda_acta` FOREIGN KEY (`fk_idacta`) REFERENCES `acta` (`idacta`),
  ADD CONSTRAINT `detalleda_docente` FOREIGN KEY (`fk_iddocente`) REFERENCES `docente` (`id_docente`);

--
-- Filtros para la tabla `detalle_ea`
--
ALTER TABLE `detalle_ea`
  ADD CONSTRAINT `detalle_ea_ibfk_1` FOREIGN KEY (`fk_idacta`) REFERENCES `acta` (`idacta`),
  ADD CONSTRAINT `detalle_ea_ibfk_2` FOREIGN KEY (`fk_idestudiante`) REFERENCES `estudiante` (`idestudiante`);

--
-- Filtros para la tabla `docente`
--
ALTER TABLE `docente`
  ADD CONSTRAINT `docente_estado` FOREIGN KEY (`fk_idestado`) REFERENCES `estado` (`idestado`),
  ADD CONSTRAINT `docente_tipoD` FOREIGN KEY (`fk_idtipodocumento`) REFERENCES `tipodocumento` (`idtipodocumento`),
  ADD CONSTRAINT `docente_tipoS` FOREIGN KEY (`fk_idtiposangre`) REFERENCES `tipodesangre` (`id_tipodesangre`),
  ADD CONSTRAINT `docente_usuario` FOREIGN KEY (`fk_idusuario`) REFERENCES `usuario` (`idusuario`),
  ADD CONSTRAINT `tipodocente_docente` FOREIGN KEY (`fk_idtipodocente`) REFERENCES `tipodocente` (`id_tipodocente`);

--
-- Filtros para la tabla `docente_especialidad`
--
ALTER TABLE `docente_especialidad`
  ADD CONSTRAINT `docenespe_docente` FOREIGN KEY (`fk_iddocente`) REFERENCES `docente` (`id_docente`),
  ADD CONSTRAINT `docenespe_especialidad` FOREIGN KEY (`fk_idespecialidad`) REFERENCES `especialidad` (`idespecialidad`);

--
-- Filtros para la tabla `docente_grado`
--
ALTER TABLE `docente_grado`
  ADD CONSTRAINT `docengrad_docente` FOREIGN KEY (`fk_iddocente`) REFERENCES `docente` (`id_docente`),
  ADD CONSTRAINT `docengrado_grado` FOREIGN KEY (`fk_idgrado`) REFERENCES `grado` (`idgrado`);

--
-- Filtros para la tabla `especialidad`
--
ALTER TABLE `especialidad`
  ADD CONSTRAINT `especialidad_estado` FOREIGN KEY (`fk_idestado`) REFERENCES `estado` (`idestado`),
  ADD CONSTRAINT `especialidad_tipoE` FOREIGN KEY (`fk_idtipoespecialidad`) REFERENCES `tipoespecialidad` (`idtipoespecialidad`);

--
-- Filtros para la tabla `especialidad_asistencia`
--
ALTER TABLE `especialidad_asistencia`
  ADD CONSTRAINT `especiA_asistencia` FOREIGN KEY (`fk_idespecialidad`) REFERENCES `especialidad` (`idespecialidad`),
  ADD CONSTRAINT `especiAsiet_asisten` FOREIGN KEY (`fk_idasistencia`) REFERENCES `asistencia` (`idasistencia`);

--
-- Filtros para la tabla `estado`
--
ALTER TABLE `estado`
  ADD CONSTRAINT `Estado_tipoE` FOREIGN KEY (`fk_idtipoestado`) REFERENCES `tipoestado` (`idtipoestado`);

--
-- Filtros para la tabla `estudiante`
--
ALTER TABLE `estudiante`
  ADD CONSTRAINT `estudiante_asistencia` FOREIGN KEY (`fk_idasistencia`) REFERENCES `asistencia` (`idasistencia`),
  ADD CONSTRAINT `estudiante_especialidad` FOREIGN KEY (`fk_idespecialidad`) REFERENCES `especialidad` (`idespecialidad`),
  ADD CONSTRAINT `estudiante_estado` FOREIGN KEY (`fk_idestado`) REFERENCES `estado` (`idestado`),
  ADD CONSTRAINT `estudiante_grado` FOREIGN KEY (`fk_idgrado`) REFERENCES `grado` (`idgrado`),
  ADD CONSTRAINT `estudiante_tipoD` FOREIGN KEY (`fk_idtipodocumento`) REFERENCES `tipodocumento` (`idtipodocumento`),
  ADD CONSTRAINT `estudiante_tipoS` FOREIGN KEY (`fk_idtiposangre`) REFERENCES `tipodesangre` (`id_tipodesangre`);

--
-- Filtros para la tabla `estudiante_acudiente`
--
ALTER TABLE `estudiante_acudiente`
  ADD CONSTRAINT `acudiente_estudiante_A` FOREIGN KEY (`fk_idacudiente`) REFERENCES `acudiente` (`idacudiente`),
  ADD CONSTRAINT `estudiante_estudiante_A` FOREIGN KEY (`fk_idestudiante`) REFERENCES `estudiante` (`idestudiante`);

--
-- Filtros para la tabla `grado`
--
ALTER TABLE `grado`
  ADD CONSTRAINT `grado_ibfk_1` FOREIGN KEY (`fk_idespecialidad`) REFERENCES `especialidad` (`idespecialidad`);

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `Usuario_TipoU` FOREIGN KEY (`fk_idtipousuario`) REFERENCES `tipousuario` (`idtipousuario`),
  ADD CONSTRAINT `usuario_estado` FOREIGN KEY (`fk_idestado`) REFERENCES `estado` (`idestado`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
