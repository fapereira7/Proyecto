@extends('layouts.app')
@section('content')
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::model($detalle_especialidad_asistencia,['route' => 'detalle_especialidad_asistencia/update', 'method' => 'put', 'novalidate']) !!}
				{!! Form::hidden('id', $detalle_especialidad_asistencia->id) !!}
					<article class="form-group">
						{!! Form::label('DescripcionEA', 'Descripción') !!}
						{!! Form::textarea('DescripcionEA', null, ['class' => 'form-control','required' => 'required']) !!}	
					</article>
					<article class="form-group">
						{!! Form::label('NombreEspecialidad', 'Especialidad') !!}
						{!! Form::select('NombreEspecialidad',$especialidads, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::label('FechaAsistencia', 'Asistencia') !!}
						{!! Form::select('FechaAsistencia',$asistencias, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!} 				
					</article>
			{!! Form::close() !!}		
		</section>
	</section>
@endsection