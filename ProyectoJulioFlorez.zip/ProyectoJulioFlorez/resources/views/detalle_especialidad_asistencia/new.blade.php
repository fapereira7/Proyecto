@extends('layouts.app')
@section('content')
<section class="container">
	<section class="row">
		<article class="col-md-10 col-md-offset-1">
			{!! Form::open(['route' => 'detalle_especialidad_asistencia.store', 'method' => 'post', 'novalidate']) !!}
				<section class="form-group">
					{!! Form::label('DescripcionEA', 'Descripción') !!}
					{!! Form::textarea('DescripcionEA', null, ['class' => 'form-control','required' => 'required']) !!}
				</section>
				<section class="form-group">
					{!! Form::label('NombreEspecialidad', 'Especialidad') !!}
					{!! Form::select('NombreEspecialidad',$especialidads, null, ['class' => 'form-control', 'required' => 'required']) !!}
				</section>
				<section class="form-group">
					{!! Form::label('FechaAsistencia', 'Asistencia') !!}
					{!! Form::select('FechaAsistencia',$asistencias, null, ['class' => 'form-control', 'required' => 'required']) !!}
				</section>
				<section class="form-group">
					{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!}
				</section>
			{!! Form::close() !!}
		</article>
	</section>
</section>
@endsection