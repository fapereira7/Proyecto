@extends('layouts.app')
@section('content')
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::model($detalle_asistencia_estudiante,['route' => 'detalle_asistencia_estudiante/update', 'method' => 'put', 'novalidate']) !!}
				{!! Form::hidden('id', $detalle_asistencia_estudiante->id) !!}
					<article class="form-group">
						{!! Form::label('FechaAsistencia', 'Asistencia') !!}
						{!! Form::select('FechaAsistencia',$asistencias, null, ['class' => 'form-control', 'required' => 'required']) !!}	
					</article>
					<article class="form-group">
						{!! Form::label('NombreEstudiante', 'Estudiante') !!}
						{!! Form::select('NombreEstudiante',$estudiantes, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!} 				
					</article>
			{!! Form::close() !!}		
		</section>
	</section>
@endsection