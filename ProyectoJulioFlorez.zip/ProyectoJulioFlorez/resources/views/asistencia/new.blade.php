@extends('layouts.app')
@extends('layouts.footerForm')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<section class="container">
	<section class="row">
		<article class="col-md-10 col-md-offset-1">
			{!! Form::open(['route' => 'asistencia.store', 'method' => 'post', 'novalidate']) !!}
			<input type="hidden" name="_token" id="tokencombo" value="{{ csrf_token() }}">
			    <section class="form-group">
					{!! Form::label('Fichas', 'Fichas') !!}
					<select name="Fichas" id="Fichas" class="form-control">
					<option value="" selected="true">Por favor seleccione una ficha</option>
						@foreach($fichas as $ficha)
							<option value="{{ $ficha->id }}">{{ $ficha->NumeroFicha }}</option>
						@endforeach
					</select>
				</section>
				<div id="combo">
					<section class="form-group">
					    {!! Form::label('Estudiantes', 'Estudiantes') !!}
						<select name="NombreEstudiante" id="Estudiantes" class="form-control">
						<option value="" >Por favor seleccione un estudiante</option>

						</select>
				    </section>
				</div>
				<section class="form-group">
					{!! Form::label('FechaAsistencia', 'Fecha') !!}
					{!! Form::date('FechaAsistencia', null, ['class' => 'form-control','required' => 'required']) !!}
				</section>
				<section class="form-group">
				        @foreach($options as $option)
				            <input type="radio" name="optradio" value="{{ $option->id }}"><label>{{ $option->NombreEstado }}</label>
					    @endforeach
				</section>
				<section class="form-group">
					{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!}
				</section>
			{!! Form::close() !!}
		</article>
	</section>
</section>
<script type="text/javascript" src="{{ asset('/js/jquery-3.1.0.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('/js/ajaxcombofichas.js') }}"></script>
@endsection
