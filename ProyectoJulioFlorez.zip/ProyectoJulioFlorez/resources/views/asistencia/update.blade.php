@extends('layouts.app')
@extends('layouts.footerForm')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::model($asistencia,['route' => 'asistencia/update', 'method' => 'put', 'novalidate']) !!}
				{!! Form::hidden('id', $asistencia->id) !!}
					<article class="form-group">
						{!! Form::label('FechaAsistencia', 'Fecha') !!}
						{!! Form::date('FechaAsistencia', null, ['class' => 'form-control','required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::label('NombreEstado', 'Estado') !!}
						{!! Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!}
					</article>
			{!! Form::close() !!}
		</section>
	</section>
@endsection
