<section class="form-group">
    {!! Form::label('Estudiantes', 'Estudiantes') !!}
	<select name="NombreEstudiante" id="Estudiantes" class="form-control">
	<option value="">Por favor seleccione un estudiante</option>
		@foreach($estudiantes as $estudiante)
			<option value="{{ $estudiante->id }}">{{ $estudiante->NombreEstudiante }}</option>
		@endforeach
	</select>
</section>