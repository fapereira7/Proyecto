@include('Programacion.menu')
@extends('layouts.footerForm')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<h1>Asistencias</h1>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::open(['route' => 'asistencia/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']) !!}
				<article class="form-group">
					<label for="exampleInputName2">Name</label>
					<input type="date" class="form-control" name="FechaAsistencia">
					<button type="submit" class="btn btn-default">Search</button>
					<a href="{{ route('asistencia.index') }}" class="btn btn-primary">All</a>
					<a href="{{ route('asistencia.create') }}" class="btn btn-primary">Create</a>
				</article>
			{!! Form::close() !!}
			<article class="form-group">
				<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Fecha asistencia</th>
						<th>Estudiante</th>
						<th>Estado</th>
						<th>Action</th>
					</tr>
					<tbody>
						@foreach($asistencias as $asistencia)
							<tr>
								<td>{{ $asistencia->FechaAsistencia }}</td>
								<td>{{ $asistencia->NombreEstudiante }}</td>
								<td>{{ $asistencia->NombreEstado }}</td>
								<td>
									<a class="btn btn-primary btn-xs" href="{{ route('asistencia.edit', ['id' => $asistencia->id] )}}">Edit</a>
									<a class="btn btn-danger btn-xs" href="{{ route('asistencia/destroy', ['id' => $asistencia->id] )}}">Delete</a>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</article>
		</section>
	</section>
<script type="text/javascript">
	  $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>
