@extends('layouts.menu')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
	<div id="page-content-wrapper">
            <div class="container-fluid">
				<p class="navbar-brand titulista">DOCENTES</p>
				{!! Form::open(['route' => 'docente/search', 'method' => 'post', 'novalidate', 'class' => 'navbar-form navbar-right']) !!}
				<article class="form-group">
					<label for="exampleInputName2" style="font-family: 'Raleway', sans-serif;">Nombre</label>
					<input type="text" class="form-control inputlista" name="NombreDocente">
					<button type="submit" class="btn botonlistabuscar">Buscar</button>
					<a href="{{ route('docente.index') }}" class="btn botonlista">Todos</a>
					<a href="{{ route('docente.create') }}" class="btn botonlista">Registrar nuevo docente</a>
				</article>
			{!! Form::close() !!}
			<div class="row">
                    <div class="col-lg-12">
						<article class="form-group tabla">
							<table class="table table-condensed table-striped table-bordered">
								<tr>
									<th>Tipo de documento</th>
									<th>Identificacion</th>
									<th>Nombre completo</th>
									<th>Dirección</th>
									<th>Telefono fijo</th>
									<th>Celular</th>
									<th>Correo</th>
									<th>Tipo de docente</th>
									<th>Tipo de sangre</th>
									<th>Estado</th>
									<th>Acción</th>
								</tr>
								<tbody>
									@foreach($docentes as $docente)
										<tr>
											<td>{{ $docente->NombreTipoDocumento }}</td>
											<td>{{ $docente->IdentificacionDocente }}</td>
											<td>{{ $docente->NombreDocente }}</td>
											<td>{{ $docente->DireccionDocente }}</td>
											<td>{{ $docente->TelefonoFijoDocente }}</td>
											<td>{{ $docente->TelefonoCelularDocente }}</td>
											<td>{{ $docente->CorreoDocente }}</td>
											<td>{{ $docente->NombreTipoDocente }}</td>
											<td>{{ $docente->TipoDeSangre }}</td>
											<td>{{ $docente->NombreEstado }}</td>
											<td>
												<a class="btn btn-primary btn-xs botonlista" href="{{ route('docente.edit', ['id' => $docente->id] )}}">Editar</a>
											</td>
										</tr>
									@endforeach
								</tbody>
							</table>
							{!!$docentes->render()!!}
						</article>
	            </div>
            </div>
        </div>
	</div>
@endsection