@extends('layouts.menu')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
	<div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="conRegistro  form-group">
            		<p class="Registros registro">ACTUALIZAR DOCENTE</p>
           	</div>
			{!! Form::model($docente,['route' => 'docente/update', 'method' => 'put', 'novalidate', 'class' => 'FormularioEst']) !!}
				{!! Form::hidden('id', $docente->id) !!}
					<section class="form-group">
					{!! Form::select('NombreTipoDocumento',$tipo_documentos, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Tipo de documento']) !!}
					</section>
					<section class="form-group">
						{!! Form::number('IdentificacionDocente', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Identificación']) !!}
					</section>
					<section class="form-group">
						{!! Form::text('NombreDocente', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Nombre completo']) !!}
					</section>
					<section class="form-group">
						{!! Form::text('DireccionDocente', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Dirección']) !!}
					</section>
					<section class="form-group">
						{!! Form::number('TelefonoFijoDocente', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Telefono fijo']) !!}
					</section>
					<section class="form-group">
						{!! Form::number('TelefonoCelularDocente', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Celular']) !!}
					</section>
					<section class="form-group">
						{!! Form::email('CorreoDocente', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Correo']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('NombreTipoDocente',$tipo_docentes, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Tipo de docente']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('TipoDeSangre',$tipo_de_sangres, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Tipo de sangre']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Estado']) !!}
					</section>
					
					<section class="form-group">
						{!! Form::submit('Actualizar', ['id' => 'btnregistrar']) !!}
					</section>
				{!! Form::close() !!}
		        </div>
	            </div>
	        </div>
	    </div>
	@endsection
