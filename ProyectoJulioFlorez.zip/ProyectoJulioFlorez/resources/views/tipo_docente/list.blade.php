@extends('layouts.app')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
  <span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<h1>Tipos de docente</h1>
  <section class="row">
    <section class="col-md-10 col-md-offset-1">
      {!! Form::open(['route' => 'tipo_docente/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']) !!}
        <article class="form-group">
          <label for="exampleInputName2">Name</label>
          <input type="text" class="form-control" name="NombreTipoDocente">
          <button type="submit" class="btn btn-default">Search</button>
          <a href="{{ route('tipo_docente.index') }}" class="btn btn-primary">All</a>
          <a href="{{ route('tipo_docente.create') }}" class="btn btn-primary">Create</a>
        </article>
      {!! Form::close() !!}
      <article class="form-group">
        <table class="table table-condensed table-striped table-bordered">
          <tr>
            <th>Tipo de docente</th>
            <th>Action</th>
          </tr>
          <tbody>
            @foreach($tipo_docentes as $tipo_docente)
              <tr>
                <td>{{ $tipo_docente->NombreTipoDocente }}</td>
                <td>
                  <a class="btn btn-primary btn-xs" href="{{ route('tipo_docente.edit', ['id' => $tipo_docente->id] )}}">Edit</a>
                  <a class="btn btn-danger btn-xs" href="{{ route('tipo_docente/destroy', ['id' => $tipo_docente->id] )}}">Delete</a>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </article>
    </section>
  </section>
@endsection