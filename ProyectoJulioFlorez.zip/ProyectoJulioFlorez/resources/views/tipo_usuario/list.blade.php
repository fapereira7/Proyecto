@extends('layouts.app')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
  <span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<h1>Tipos de usuarios</h1>
  <section class="row">
    <section class="col-md-10 col-md-offset-1">
      {!! Form::open(['route' => 'tipo_usuario/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']) !!}
        <article class="form-group">
          <label for="exampleInputName2">Name</label>
          <input type="text" class="form-control" name="NombreTipoUsuario">
          <button type="submit" class="btn btn-default">Search</button>
          <a href="{{ route('tipo_usuario.index') }}" class="btn btn-primary">All</a>
          <a href="{{ route('tipo_usuario.create') }}" class="btn btn-primary">Create</a>
        </article>
      {!! Form::close() !!}
      <article class="form-group">
        <table class="table table-condensed table-striped table-bordered">
          <tr>
            <th>Tipo de usuario</th>
            <th>Action</th>
          </tr>
          <tbody>
            @foreach($tipo_usuarios as $tipo_usuario)
              <tr>
                <td>{{ $tipo_usuario->NombreTipoUsuario }}</td>
                <td>
                  <a class="btn btn-primary btn-xs" href="{{ route('tipo_usuario.edit', ['id' => $tipo_usuario->id] )}}">Edit</a>
                  <a class="btn btn-danger btn-xs" href="{{ route('tipo_usuario/destroy', ['id' => $tipo_usuario->id] )}}">Delete</a>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </article>
    </section>
  </section>
@endsection