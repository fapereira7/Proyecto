@include('Programacion.menu')
@extends('layouts.footerForm')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="conRegistro form-group">
            				<p class="Registros registro">ACTUALIZAR ESTUDIANTE</p>
           				</div>
						{!! Form::model($estudiante,['route' => 'estudiante/update', 'method' => 'put', 'novalidate', 'class'=>'FormularioEst']) !!}
							{!! Form::hidden('id', $estudiante->id) !!}
								<section class="form-group">
									{!! Form::select('NombreTipoDocumento',$tipo_documentos, null, ['class' => 'form-control', 'required' => 'required']) !!}
								</section>
								<section class="form-group">
									{!! Form::number('IdentificacionEstudiante', null, ['class' => 'form-control','required' => 'required']) !!}
								</section>
								<section class="form-group">
									{!! Form::text('NombreEstudiante', null, ['class' => 'form-control','required' => 'required']) !!}
								</section>
								<section class="form-group">
									{!! Form::text('DireccionEstudiante', null, ['class' => 'form-control','required' => 'required']) !!}
								</section>
								<section class="form-group">
									{!! Form::number('TelefonoFijoEstudiante', null, ['class' => 'form-control','required' => 'required']) !!}
								</section>
								<section class="form-group">
									{!! Form::number('TelefonoCelularEstudiante', null, ['class' => 'form-control','required' => 'required']) !!}
								</section>
								<section class="form-group">
									{!! Form::email('CorreoEstudiante', null, ['class' => 'form-control','required' => 'required']) !!}
								</section>
								<section class="form-group">
									{!! Form::select('TipoDeSangre',$tipo_de_sangres, null, ['class' => 'form-control', 'required' => 'required']) !!}
								</section>
								<section class="form-group">
									{!! Form::select('NumeroFicha',$fichas, null, ['class' => 'form-control', 'required' => 'required']) !!}
								</section>
								<section class="form-group">
									{!! Form::select('NombreGenero',$generos, null, ['class' => 'form-control', 'required' => 'required']) !!}
								</section>
								<section class="form-group">
									{!! Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required']) !!}
								</section>
								<section class="form-group">
									{!! Form::submit('Actualizar', ['id' => 'btnregistrar']) !!}
								</section>
							{!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
		  $("#menu-toggle").click(function(e) {
	        e.preventDefault();
	        $("#wrapper").toggleClass("toggled");
	      });
		</script>
