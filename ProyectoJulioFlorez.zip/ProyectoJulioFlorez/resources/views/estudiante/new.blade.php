@include('layouts.MenuRegistros')
@extends('layouts.footerForm')
<script type="text/javascript" src="{{ asset('/js/jquery-3.1.0.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('/ajax/ajaxEstudiante.js') }}"></script>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="conRegistro  form-group">
            		<p class="Registros registro">REGISTRO ESTUDIANTE</p>
           		</div>
				{!! Form::open(['route' => 'estudiante.store', 'method' => 'post', 'novalidate' , 'id' => 'formEst', 'class' => 'FormularioEst']) !!}
				    <input type="hidden" name="_token" id="tokenEst" value="{{ csrf_token() }}">

					<section class="form-group">
						{!! Form::select('NombreTipoDocumento',$tipo_documentos, null, ['id' => 'NombreTipoDocumento', 'class' => 'form-control', 'required' => 'required', 'placeholder' => 'Tipo de documento']) !!}
					</section>
					<section class="form-group">
						{!! Form::number('IdentificacionEstudiante', null, ['id' => 'IdentificacionEstudiante', 'class' => 'form-control','required' => 'required', 'placeholder' => 'Identificación']) !!}
					</section>
					<section class="form-group">
						{!! Form::text('NombreEstudiante', null, ['id' => 'NombreEstudiante', 'class' => 'form-control','required' => 'required' , 'placeholder' => 'Nombres y apellidos']) !!}
					</section>
					<section class="form-group">
						{!! Form::text('DireccionEstudiante', null, ['id' => 'DireccionEstudiante', 'class' => 'form-control','required' => 'required', 'placeholder' => 'Dirección']) !!}
					</section>
					<section class="form-group">
						{!! Form::number('TelefonoFijoEstudiante', null, ['id' => 'TelefonoFijoEstudiante', 'class' => 'form-control','required' => 'required', 'placeholder' => 'Telefono fijo']) !!}
					</section>
					<section class="form-group">
						{!! Form::number('TelefonoCelularEstudiante', null, ['id' => 'TelefonoCelularEstudiante', 'class' => 'form-control','required' => 'required', 'placeholder' => 'Celular']) !!}
					</section>
					<section class="form-group">
						{!! Form::email('CorreoEstudiante', null, ['id' => 'CorreoEstudiante', 'class' => 'form-control','required' => 'required', 'placeholder' => 'Correo']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('TipoDeSangre',$tipo_de_sangres, null, ['id' => 'TipoDeSangre', 'class' => 'form-control', 'required' => 'required', 'placeholder' => 'Tipo de sangre']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('NumeroFicha',$fichas, null, ['id' => 'NumeroFicha', 'class' => 'form-control', 'required' => 'required', 'placeholder' => 'Ficha']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('NombreGenero',$generos, null, ['id' => 'NombreGenero', 'class' => 'form-control', 'required' => 'required', 'placeholder' => 'Genero']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('NombreEstado',$estados, null, ['id' => 'NombreEstado', 'class' => 'form-control', 'required' => 'required', 'placeholder' => 'Estado']) !!}
					</section>
					<section class="form-group">
					    <label>Opciones para registrar acudiente</label></br>
					    <input type="radio" id="selectacu" name="optradio" value="1"><label>  Seleccionar Acudiente</label></br>
					    <input type="radio" id="regacud" name="optradio" value="1"><label>  Registrar Acudiente</label>
					</section>
					<section id="formselecAcu" class="form-group">
						<label>Seleccionar Acudiente</label>
						<select class="form-control" name="Id_Acudiente" id="Id_Acudiente">
						    <option value="" selected="true">Por favor seleccione un acudiente</option>
							@foreach($acudientes as $acudiente)
							<option value="{{ $acudiente->id }}">{{ $acudiente->NombreAcudiente }}</option>
							@endforeach
						</select>
					</section>
					<section id="formAcu" class="form-group">
					    <section class="form-group">
					        <center><h1>Registrar Acudiente</h1></center>
					    </section>
						<section class="form-group">
							{!! Form::select('NombreTipoDocumento',$tipo_documentos, null, ['id' => 'NombreTipoDocumento', 'class' => 'form-control', 'required' => 'required', 'placeholder'=>'Tipo de documento']) !!}
						</section>
						<section class="form-group">
							{!! Form::number('IdentificacionAcudiente', null, ['id' => 'IdentificacionAcudiente', 'class' => 'form-control','required' => 'required', 'placeholder'=>'Identificación']) !!}
						</section>
						<section class="form-group">
							{!! Form::text('NombreAcudiente', null, ['id' => 'NombreAcudiente', 'class' => 'form-control','required' => 'required', 'placeholder'=>'Nombre completo']) !!}
						</section>
						<section class="form-group">
							{!! Form::text('DireccionAcudiente', null, ['id' => 'DireccionAcudiente', 'class' => 'form-control','required' => 'required', 'placeholder'=>'Dirección']) !!}
						</section>
						<section class="form-group">
							{!! Form::number('TelefonoFijoAcudiente', null, ['id' => 'TelefonoFijoAcudiente', 'class' => 'form-control','required' => 'required', 'placeholder'=>'Telefono fijo']) !!}
						</section>
						<section class="form-group">
							{!! Form::number('TelefonoCelularAcudiente', null, ['id' => 'TelefonoCelularAcudiente', 'class' => 'form-control','required' => 'required', 'placeholder'=>'Celular']) !!}
						</section>
						<section class="form-group">
							{!! Form::email('CorreoAcudiente', null, ['id' => 'CorreoAcudiente', 'class' => 'form-control','required' => 'required', 'placeholder'=>'Correo']) !!}
						</section>
						<section class="form-group">
							{!! Form::select('NombreGenero',$generos, null, ['id' => 'NombreGenero', 'class' => 'form-control', 'required' => 'required', 'placeholder'=>'Genero']) !!}
						</section>
						<section class="form-group">
							{!! Form::select('TipoDeSangre',$tipo_de_sangres, null, ['id' => 'TipoDeSangre', 'class' => 'form-control', 'required' => 'required', 'placeholder'=>'Tipo de sangre']) !!}
						</section>
						<section class="form-group">
							{!! Form::select('NombreEstado',$estados, null, ['id' => 'NombreEstado', 'class' => 'form-control', 'required' => 'required', 'placeholder'=>'Estado']) !!}
						</section>
						<section class="form-group" id="parentesco">
							<select class="form-control">
							    <option value="">Por favor seleccione un parentesco</option>
								<option value="Madre">Madre</option>
								<option value="Padre">Padre</option>
								<option value="Tío">Tío</option>
							</select>
						</section>
					</section>
					<section class="form-group">
					    {!! Form::button('Agregar Acudiente', ['id' => 'agregarAcu', 'class' => 'btn btn-primary']) !!}
						{!! Form::submit('Registrar', ['id' => 'btnregistrar', 'class' => 'btn btn-primary']) !!}
					</section>
					<section class="form-group">
					    <table class="table table-condensed table-striped table-bordered">
					    	<thead>
					    		<tr>
					    			<th>Nombre Acudiente</th>
					    			<th>Documento</th>
					    		    <th>Parentesto</th>
					    		    <th>Acción</th>
					    		</tr>
					    	<tbody id="fila">
					    		<tr>
					    			<td></td>
					    			<td></td>
					    			<td></td>
					    			<td></td>
					    		</tr>
					    	</tbody>
					    	</thead>
					    </table>
					</section>
					{{ Form::hidden('cantidadAcudiente', 0, ['id' => 'cantidadAcudiente']) }}
				{!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>
<script type="text/javascript">
	  $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>
