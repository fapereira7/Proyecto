@extends('layouts.menu')
@section('css')
	<link href="{{ asset('/css/dropzone.css') }}" rel="stylesheet">
	@endsection
	@section('content')
		    <div class="container">
		        <div class="row">
		            <div class="panel panel-default">
		                <div class="panel-heading">Archivos</div>
			                <div class="panel-body">
										 {!! Form::open([
										 'url'=> 'uploads.php',
										 'method' => 'POST',
										 'files'=>'true',
										 'id' => 'my-dropzone',
										 'class' => 'dropzone'])
										 !!}
										 @include('Load_File.button')
										 <button type="submit" class="btn btn-success" action="Validar.php" id="submit-download">Download</button>

			                    {!! Form::close() !!}
			                </div>			                      
		            </div>
		        </div>
		        <section> @include('Load_File.vistaArchivos') </section>
		    </div>	    
	@endsection
<section class="form-group">
		@section('scripts')
	    {!! Html::script('js/dropzone.js'); !!}
		<script>		
		{	
				Dropzone.options.myDropzone =
				{
				autoProcessQueue: false,
        		addRemoveLinks: true,
				oploadMultiple: true,
				maxFileSize: 100, //MB
				maxFiles: 1,
				init: function() 
				{

					    $rutaarchivos= "../uploads/";

						public function descargar
						{			         
				         $rutaarchivo= "../uploads/";
				         return response()->download($rutaarchivo);
				        }

				 		$ this -> carga -> helper ( 'download' );						
						var submitButton = document.querySelector("#submit-all") myDropzone = this;
						submitButton.addEventListener("click", function(e)
						{//alert("Precionaste el boton de submit");
							force_download([$filename = ''[, $data = 'file'[, $set_mime = FALSE]]])
							e.prevetDefault();
							e.stopPropagation();
							myDropzone.processQueue();//decirle a la zona de saltos para procesar todos los archivos de la cola
						});
						//es posible que desee mostrar el botton enviar archivos sólo cuando se dejan caer aquí
						this.on("addedfile", function(file)
						{// Mostrar botón de enviar aquí y / o informar a su uso para hacer clic.
							alert("Se agrego un archivo");
						});
						this.on("complete", function(file) {// Si estan en estado de completo los quitamos
		                    myDropzone.removeFile(file);
		                });
		                this.on("removedfile", handleFileRemoved);
							class Files extends CI_Controller {

							public function __construct() {
							        parent::__construct();
							        $this->load->helper(array('download', 'file', 'url', 'html', 'form'));
							        $this->folder = 'uploads/';

							        }
							   
							public function index()
							    {
							        $this->load->view('upload_form', array('error' => ' ' )); 
							    }
							    public function downloads($name)
							    {
         
							    $data = file_get_contents($this->folder.$name); 
							    force_download($name,$data); 
							     
								}
					}
		</script>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<script src="dist/js/dropzone.js"></script>
</section>