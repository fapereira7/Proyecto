<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);

function listarDirectoriosLocales($dir, &$results = array())
{ 
    // Pon la ruta del directorio de donde listar los archivos desde el root
    $path = "H:\ProyectoJulioFlorez\public\uploads";

    // Abrir la carpeta
    $dir_handle = @opendir($path) or die("Unable to open $path");

    // Leer los archivos
    while ($file = readdir($dir_handle)) {

    if($file == "." || $file == ".." || $file == "uploads" )

        continue;
        echo "<a href=\"$file\">$file</a><br />";

    }

    // Cerrar
    closedir($dir_handle);
}
echo '<h2>Listar Directorios Locales </h2><pre>';
print_r(listarDirectoriosLocales('H:\ProyectoJulioFlorez\public\uploads'));
echo '</pre>';
?>