<div class="dz-message" style="height:100px;">
    Arrastre sus archivos aquí.<br style="color-text:brown;">
</div>			
<div class="dropzone-previews"></div>
<button type="submit" class="btn btn-success" id="submit-all">Enviar</button>