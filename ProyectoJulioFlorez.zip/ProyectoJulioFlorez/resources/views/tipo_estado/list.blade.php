@extends('layouts.app')
@section('content')
<div class="iconomenu">
<script type="text/javascript" src="{{ asset('js/jquery-3.1.0.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/ajaxcombo.js') }}"></script>
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
  <span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
    <section class="row">
    <section class="col-md-10 col-md-offset-1">
      <h1>Tipos de estado</h1>
        <section id="sectioncombo">
              <input type="hidden" name="_token" id="tokencombo" class="tokencombo" value="{{ csrf_token() }}">
              <div class="form-group">
                {!! Form::label('full_estado', 'Tipo de Estado:') !!}
                  <select class="form-control combo" id="tipo_combo" name="Id_Tipo_Estado" onchange="combo_anidado()">
                  <option selected="selected"></option>
                  @foreach($tipo_estados as $tipo_estado)
                    <option value="{{$tipo_estado->id}}">{{$tipo_estado->NombreTipoEstado}}</option>
                  @endforeach
                  </select>
              </div>
              <div class="form-group">
                {!! Form::label('full_estado', 'Estado:') !!}
                  <select class="form-control" id="estado_combo" name="Fk_Id_Estado">
                    <option value="">Por favor seleccione un Estado</option>
                  </select>
              </div>
      </section>
      {!! Form::open(['route' => 'tipo_estado/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']) !!}
        <article class="form-group">
          <label for="exampleInputName2">Name</label>
          <input type="text" class="form-control" name="NombreTipoEstado">
          <button type="submit" class="btn btn-default">Search</button>
          <a href="{{ route('tipo_estado.index') }}" class="btn btn-primary">All</a>
          <a href="{{ route('tipo_estado.create') }}" class="btn btn-primary">Create</a>
        </article>
      {!! Form::close() !!}
      <article class="form-group">
        <table class="table table-condensed table-striped table-bordered">
          <tr>
            <th>Tipo de estado</th>
            <th>Action</th>
          </tr>
          <tbody>
            @foreach($tipo_estados as $tipo_estado)
              <tr>
                <td>{{ $tipo_estado->NombreTipoEstado }}</td>
                <td>
                  <a class="btn btn-primary btn-xs" href="{{ route('tipo_estado.edit', ['id' => $tipo_estado->id] )}}">Edit</a>
                  <a class="btn btn-danger btn-xs" href="{{ route('tipo_estado/destroy', ['id' => $tipo_estado->id] )}}">Delete</a>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </article>
    </section>
  </section>
@endsection