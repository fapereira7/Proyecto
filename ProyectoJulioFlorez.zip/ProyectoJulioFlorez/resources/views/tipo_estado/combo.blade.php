  <input type="hidden" name="_token" id="tokencombo" class="tokencombo" value="{{ csrf_token() }}">
    <div class="form-group">
    {!! Form::label('full_estado', 'Tipo de Estado:') !!}
      <select class="form-control combo" id="tipo_combo" name="Id_Tipo_Estado" onchange="combo_anidado()">
        <option selected="selected"></option>
      @foreach($tipo_estados as $tipo_estado)
        <option value="{{$tipo_estado->id}}">{{$tipo_estado->NombreTipoEstado}}</option>
      @endforeach
      </select>
  </div>
  <div class="form-group">
    {!! Form::label('full_estado', 'Estado:') !!}
      <select class="form-control" id="estado_combo" name="Fk_Id_Estado">
      @foreach($estados as $estado)
        <option value="{{$estado->id}}">{{$estado->NombreEstado}}</option>
      @endforeach
      </select>
  </div>