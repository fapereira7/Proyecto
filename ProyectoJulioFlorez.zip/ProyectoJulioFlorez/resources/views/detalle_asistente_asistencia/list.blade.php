@extends('layouts.app')
@section('content')
<h1>Registros detalle asistente asistencia</h1>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::open(['route' => 'detalle_asistente_asistencia/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']) !!}
				<article class="form-group">
					<label for="exampleInputName2">Name</label>
					<input type="text" class="form-control" name="NombreEstado">
					<button type="submit" class="btn btn-default">Search</button>
					<a href="{{ route('detalle_asistente_asistencia.index') }}" class="btn btn-primary">All</a>
					<a href="{{ route('detalle_asistente_asistencia.create') }}" class="btn btn-primary">Create</a>
				</article>
			{!! Form::close() !!}
			<article class="form-group">
				<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Estado</th>
						<th>Asistente</th>
						<th>Asistencia</th>
					</tr>
					<tbody>
						@foreach($detalle_asistente_asistencias as $detalle_asistente_asistencia)
							<tr>
								<td>{{ $detalle_asistente_asistencia->NombreAsistente }}</td>
								<td>{{ $detalle_asistente_asistencia->FechaAsistencia }}</td>
								<td>
									<a class="btn btn-primary btn-xs" href="{{ route('detalle_asistente_asistencia.edit', ['id' => $detalle_asistente_asistencia->id] )}}">Edit</a>
									<a class="btn btn-danger btn-xs" href="{{ route('detalle_asistente_asistencia/destroy', ['id' => $detalle_asistente_asistencia->id] )}}">Delete</a>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</article>
		</section>
	</section>
@endsection