@extends('layouts.app')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
  <span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<h1>Tipos de documento</h1>
  <section class="row">
    <section class="col-md-10 col-md-offset-1">
      {!! Form::open(['route' => 'tipo_documento/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']) !!}
        <article class="form-group">
          <label for="exampleInputName2">Name</label>
          <input type="text" class="form-control" name="NombreTipoDocumento">
          <button type="submit" class="btn btn-default">Search</button>
          <a href="{{ route('tipo_documento.index') }}" class="btn btn-primary">All</a>
          <a href="{{ route('tipo_documento.create') }}" class="btn btn-primary">Create</a>
        </article>
      {!! Form::close() !!}
      <article class="form-group">
        <table class="table table-condensed table-striped table-bordered">
          <tr>
            <th>Tipo de documento</th>
            <th>Action</th>
          </tr>
          <tbody>
            @foreach($tipo_documentos as $tipo_documento)
              <tr>
                <td>{{ $tipo_documento->NombreTipoDocumento }}</td>
                <td>
                  <a class="btn btn-primary btn-xs" href="{{ route('tipo_documento.edit', ['id' => $tipo_documento->id] )}}">Edit</a>
                  <a class="btn btn-danger btn-xs" href="{{ route('tipo_documento/destroy', ['id' => $tipo_documento->id] )}}">Delete</a>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </article>
    </section>
  </section>
@endsection