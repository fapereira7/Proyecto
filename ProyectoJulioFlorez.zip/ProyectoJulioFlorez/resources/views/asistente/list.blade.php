@extends('layouts.menu')
@extends('layouts.footerForm')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<h1>Asistentes</h1>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::open(['route' => 'asistente/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']) !!}
				<article class="form-group">
					<label for="exampleInputName2">Name</label>
					<input type="text" class="form-control" name="NombreAsistente">
					<button type="submit" class="btn btn-default">Search</button>
					<a href="{{ route('asistente.index') }}" class="btn btn-primary">All</a>
					<a href="{{ route('asistente.create') }}" class="btn btn-primary">Create</a>
				</article>
			{!! Form::close() !!}
			<article class="form-group">
				<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Tipo de documento</th>
						<th>Identificación del asistente</th>
						<th>Nombre del asistente</th>
						<th>Dirección</th>
						<th>Telefono</th>
						<th>Celular</th>
						<th>Correo</th>
						<th>Tipo de sangre</th>
						<th>Estado del asistente</th>
						<th>Action</th>
					</tr>
					<tbody>
						@foreach($asistentes as $asistente)
							<tr>
								<td>{{ $asistente->NombreTipoDocumento }}</td>
								<td>{{ $asistente->IdentificacionAsistente }}</td>
								<td>{{ $asistente->NombreAsistente }}</td>
								<td>{{ $asistente->DireccionAsistente }}</td>
								<td>{{ $asistente->TelefonoFijoAsistente }}</td>
								<td>{{ $asistente->TelefonoCelularAsistente }}</td>
								<td>{{ $asistente->CorreoAsistente }}</td>
								<td>{{ $asistente->TipoDeSangre }}</td>
								<td>{{ $asistente->NombreEstado }}</td>
								<td>
									<a class="btn btn-primary btn-xs" href="{{ route('asistente.edit', ['id' => $asistente->id] )}}">Edit</a>
									<a class="btn btn-danger btn-xs" href="{{ route('asistente/destroy', ['id' => $asistente->id] )}}">Delete</a>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</article>
		</section>
	</section>
@endsection
