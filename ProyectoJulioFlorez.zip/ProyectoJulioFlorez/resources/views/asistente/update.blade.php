@extends('layouts.menu')
@extends('layouts.footerForm')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::model($asistente,['route' => 'asistente/update', 'method' => 'put', 'novalidate']) !!}
				{!! Form::hidden('id', $asistente->id) !!}
					<article class="form-group">
						{!! Form::label('NombreTipoDocumento', 'Tipo de documento') !!}
						{!! Form::select('NombreTipoDocumento',$tipo_documentos, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::label('IdentificacionAsistente', 'Identificacion del asistente') !!}
						{!! Form::text('IdentificacionAsistente', null, ['class' => 'form-control','required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::label('NombreAsistente', 'Nombre completo del asistente') !!}
						{!! Form::text('NombreAsistente', null, ['class' => 'form-control','required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::label('DireccionAsistente', 'Direccion de residencia del asistente') !!}
						{!! Form::text('DireccionAsistente', null, ['class' => 'form-control','required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::label('TelefonoFijoAsistente', 'Telefono fijo del asistente') !!}
						{!! Form::text('TelefonoFijoAsistente', null, ['class' => 'form-control','required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::label('TelefonoCelularAsistente', 'Telefono celular del asistente') !!}
						{!! Form::text('TelefonoCelularAsistente', null, ['class' => 'form-control','required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::label('CorreoAsistente', 'Correo del asistente') !!}
						{!! Form::text('CorreoAsistente', null, ['class' => 'form-control','required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::label('TipoDeSangre', 'Tipo de sangre') !!}
						{!! Form::select('TipoDeSangre',$tipo_de_sangres, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::label('NombreEstado', 'Estado del asistente') !!}
						{!! Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!}
					</article>
			{!! Form::close() !!}
		</section>
	</section>
@endsection
