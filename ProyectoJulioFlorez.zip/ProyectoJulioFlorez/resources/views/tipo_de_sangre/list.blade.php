@extends('layouts.app')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
  <span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<h1>Tipos de sangre</h1>
  <section class="row">
    <section class="col-md-10 col-md-offset-1">
      {!! Form::open(['route' => 'tipo_de_sangre/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']) !!}
        <article class="form-group">
          <label for="exampleInputName2">Name</label>
          <input type="text" class="form-control" name="TipoDeSangre">
          <button type="submit" class="btn btn-default">Search</button>
          <a href="{{ route('tipo_de_sangre.index') }}" class="btn btn-primary">All</a>
          <a href="{{ route('tipo_de_sangre.create') }}" class="btn btn-primary">Create</a>
        </article>
      {!! Form::close() !!}
      <article class="form-group">
        <table class="table table-condensed table-striped table-bordered">
          <tr>
            <th>Tipo de sangre</th>
            <th>Action</th>
          </tr>
          <tbody>
            @foreach($tipo_de_sangres as $tipo_de_sangre)
              <tr>
                <td>{{ $tipo_de_sangre->TipoDeSangre }}</td>
                <td>
                  <a class="btn btn-primary btn-xs" href="{{ route('tipo_de_sangre.edit', ['id' => $tipo_de_sangre->id] )}}">Edit</a>
                  <a class="btn btn-danger btn-xs" href="{{ route('tipo_de_sangre/destroy', ['id' => $tipo_de_sangre->id] )}}">Delete</a>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </article>
    </section>
  </section>
@endsection