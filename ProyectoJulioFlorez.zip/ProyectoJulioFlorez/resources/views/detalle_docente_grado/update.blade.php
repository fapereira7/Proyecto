@extends('layouts.app')
@section('content')
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::model($detalle_docente_grado,['route' => 'detalle_docente_grado/update', 'method' => 'put', 'novalidate']) !!}
				{!! Form::hidden('id', $detalle_docente_grado->id) !!}
					<article class="form-group">
						{!! Form::label('NombreDocente', 'Docente') !!}
						{!! Form::select('NombreDocente',$docentes, null, ['class' => 'form-control', 'required' => 'required']) !!}	
					</article>
					<article class="form-group">
						{!! Form::label('NombreGrado', 'Grado') !!}
						{!! Form::select('NombreGrado',$grados, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!} 				
					</article>
			{!! Form::close() !!}		
		</section>
	</section>
@endsection