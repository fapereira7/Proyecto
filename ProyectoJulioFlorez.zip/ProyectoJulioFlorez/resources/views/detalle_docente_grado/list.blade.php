@extends('layouts.app')
@section('content')
<h1>Registros detalle docente grado</h1>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::open(['route' => 'detalle_docente_grado/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']) !!}
				<article class="form-group">
					<label for="exampleInputName2">Name</label>
					<input type="text" class="form-control" name="NombreEstado">
					<button type="submit" class="btn btn-default">Search</button>
					<a href="{{ route('detalle_docente_grado.index') }}" class="btn btn-primary">All</a>
					<a href="{{ route('detalle_docente_grado.create') }}" class="btn btn-primary">Create</a>
				</article>
			{!! Form::close() !!}
			<article class="form-group">
				<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Docente</th>
						<th>Grado</th>
						<th>Action</th>
					</tr>
					<tbody>
						@foreach($detalle_docente_grados as $detalle_docente_grado)
							<tr>
								<td>{{ $detalle_docente_grado->NombreDocente }}</td>
								<td>{{ $detalle_docente_grado->NombreGrado }}</td>
								<td>
									<a class="btn btn-primary btn-xs" href="{{ route('detalle_docente_grado.edit', ['id' => $detalle_docente_grado->id] )}}">Edit</a>
									<a class="btn btn-danger btn-xs" href="{{ route('detalle_docente_grado/destroy', ['id' => $detalle_docente_grado->id] )}}">Delete</a>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</article>
		</section>
	</section>
@endsection