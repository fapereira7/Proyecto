 @include('layouts.MenuRegistros')
 @extends('layouts.footerForm')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-xs-12 text-center">
				<div class="conRegistro  form-group">
	            	<p class="Registros registro">NUEVO FORMATO</p>
	           	</div>
			@if(Session::has('success'))

			{!!Session::get('Success')!!}

			@endif

				{!!Form::open(array('url' =>'formato/post','files' =>true, 'method' => 'post', 'novalidate', 'class' => 'FormularioEst'))!!}
					<section class="form-group">
						<span class="input input--kaede">
				        	{!! Form::text('NumeroFormato', null, ['id' => 'input1','class' => 'input__field input__field--kaede','required' => 'required']) !!}
							<label class="input__label input__label--kaede" for="input1">
							<span class="input__label-content input__label-content--kaede">Número del formato</span>
							</label>
						</span>
					</section>
					<section class="form-group">
						{!! Form::textarea('DescripcionFormato', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Descripción']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('NombreTipoFormato',$tipo_formatos, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Seleccione el tipo de formato...']) !!}
						<input type="file" name="UrlFormato" value="Formatos" id="file-7" class="inputfile inputfile-6" data-multiple-caption="{count} files selected" multiple />
					</section>
					<section class="form-group">
						{!! Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Seleccione el estado...']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('NombreEstudiante',$estudiantes, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Seleccione el estudiante...']) !!}
					</section>
					<section class="form-group">
						<input for="file-7 type="file" name="UrlFormato" id="file-7" class="inputfile inputfile-6" data-multiple-caption="{count} files selected" multiple />
						<label for="file-7"><span></span> <strong><svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/></svg>Seleccione el archivo</strong></label>
					</section>
					<section class="form-group">
						{!! Form::submit('Registrar', ['class' => 'btn-2 btn-2d']) !!}
					</section>
				{!! Form::close() !!}
			</div>
		</div>
    </div>
</div>
<script src="{{ asset('js/custom-file-input.js') }}"></script>
<script type="text/javascript">
	  $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>
<script type="text/javascript" src="{{ asset('js/classie.js') }}"></script>
<script>
	(function() {
		// trim polyfill : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/Trim
		if (!String.prototype.trim) {
			(function() {
				// Make sure we trim BOM and NBSP
				var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
				String.prototype.trim = function() {
					return this.replace(rtrim, '');
				};
			})();
		}

		[].slice.call( document.querySelectorAll( 'input.input__field' ) ).forEach( function( inputEl ) {
			// in case the input is already filled..
			if( inputEl.value.trim() !== '' ) {
				classie.add( inputEl.parentNode, 'input--filled' );
			}

			// events:
			inputEl.addEventListener( 'focus', onInputFocus );
			inputEl.addEventListener( 'blur', onInputBlur );
		} );

		function onInputFocus( ev ) {
			classie.add( ev.target.parentNode, 'input--filled' );
		}

		function onInputBlur( ev ) {
			if( ev.target.value.trim() === '' ) {
				classie.remove( ev.target.parentNode, 'input--filled' );
			}
		}
	})();
</script>
