@extends('layouts.menu')
@extends('layouts.footerForm')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::model($formato,['route' => 'formato/update', 'method' => 'put', 'novalidate']) !!}
				{!! Form::hidden('id', $formato->id) !!}
					<section class="form-group">
					{!! Form::label('NumeroFormato', 'Número de formato') !!}
					{!! Form::text('NumeroFormato', null, ['class' => 'form-control','required' => 'required']) !!}
					</section>
					<section class="form-group">
						{!! Form::label('DescripcionFormato', 'Descripción del formato') !!}
						{!! Form::textarea('DescripcionFormato', null, ['class' => 'form-control','required' => 'required']) !!}
					</section>
					<section class="form-group">
						{!! Form::label('UrlFormato', 'formato') !!}
						{!! Form::text('UrlFormato', null, ['class' => 'form-control','required' => 'required']) !!}
					</section>
					<section class="form-group">
						{!! Form::label('NombreTipoFormato', 'Tipo del formato') !!}
						{!! Form::select('NombreTipoFormato',$tipo_formatos, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</section>
					<section class="form-group">
						{!! Form::label('NombreEstado', 'Estado del formato') !!}
						{!! Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</section>
					<section class="form-group">
						{!! Form::label('NombreEstudiante', 'Nombre del estudiante') !!}
						{!! Form::select('NombreEstudiante',$estudiantes, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</section>
					<section class="form-group">
						{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!}
					</section>
			{!! Form::close() !!}
		</section>
	</section>
@endsection
