 @include('layouts.MenuRegistros')
 @extends('layouts.footerForm')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
            <div class="container-fluid">
            <p class="navbar-brand titulista">FORMATOS</p>
    			{!! Form::open(['route' => 'formato/search', 'method' => 'post', 'novalidate', 'class' => 'navbar-form navbar-right']) !!}
    				<article class="form-group">
    					<label for="exampleInputName2" style="font-family: 'Raleway', sans-serif;">Nombre</label>
    					<input type="text" class="form-control inputlista" name="NombreAcudiente">
    					<button type="submit" class="btn botonlistabuscar">Search</button>
    					<a href="{{ route('formato.index') }}" class="btn botonlista">Todos</a>
    					<a href="{{ route('formato.create') }}" class="btn botonlista">Registrar nuevo formato</a>
    				</article>
    			{!! Form::close() !!}
    			<div class="row">
                        <div class="col-lg-12">
    			<article class="form-group tabla">
    				<table class="table table-condensed table-striped table-bordered">
    					<tr>
    						<th>Número de formato</th>
    						<th>Descripción</th>
    						<th>Formato</th>
    						<th>Tipo de formato</th>
    						<th>Estado del formato</th>
                            <th>Nombre del estudiante</th>
    						<th>Action</th>
    					</tr>
    					<tbody>
    						@foreach($formatos as $formato)
    							<tr>
    								<td>{{ $formato->NumeroFormato }}</td>
    								<td>{{ $formato->DescripcionFormato }}</td>
    								<td>{{ $formato->UrlFormato }}</td>
    								<td>{{ $formato->NombreTipoFormato }}</td>
    								<td>{{ $formato->NombreEstado }}</td>
                                    <td>{{ $formato->NombreEstudiante }}</td>
    								<td>
    									<a class="btn btn-primary btn-xs botonlista" href="{{ route('formato.edit', ['id' => $formato->id] )}}">Editar</a>
    									<a class="btn btn-primary btn-xs botonlista" href="{{ route('formato/download', ['archivo' => $formato->id]) }}">Descargar</a>
    								</td>
    							</tr>
						@endforeach
							   </tbody>
							</table>
							{!!$formatos->render()!!}
						</article>
                    </div>
                </div>
            </div>
	</div>
<script type="text/javascript">
	  $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>
