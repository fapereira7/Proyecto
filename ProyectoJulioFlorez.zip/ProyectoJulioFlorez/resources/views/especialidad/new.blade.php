@extends('layouts.menu')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<section class="container">
	<section class="row">
		<article class="col-md-10 col-md-offset-1">
			{!! Form::open(['route' => 'especialidad.store', 'method' => 'post', 'novalidate']) !!}
				<section class="form-group">
					{!! Form::label('NombreEspecialidad', 'Especialidad') !!}
					{!! Form::text('NombreEspecialidad', null, ['class' => 'form-control','required' => 'required']) !!}
				</section>
				<section class="form-group">
					{!! Form::label('NombreTipoEspecialidad', 'Tipo de especialidad') !!}
					{!! Form::select('NombreTipoEspecialidad',$tipo_especialidads, null, ['class' => 'form-control', 'required' => 'required']) !!}
				</section>
				<section class="form-group">
					{!! Form::label('NombreEstado', 'Estado') !!}
					{!! Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required']) !!}
				</section>
				<section class="form-group">
					{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!}
				</section>
			{!! Form::close() !!}
		</article>
	</section>
</section>
@endsection
