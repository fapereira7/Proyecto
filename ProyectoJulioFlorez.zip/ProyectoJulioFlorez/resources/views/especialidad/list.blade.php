@extends('layouts.menu')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<h1>Especialidades</h1>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::open(['route' => 'especialidad/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']) !!}
				<article class="form-group">
					<label for="exampleInputName2">Name</label>
					<input type="text" class="form-control" name="NombreEspecialidad">
					<button type="submit" class="btn btn-default">Search</button>
					<a href="{{ route('especialidad.index') }}" class="btn btn-primary">All</a>
					<a href="{{ route('especialidad.create') }}" class="btn btn-primary">Create</a>
				</article>
			{!! Form::close() !!}
			<article class="form-group">
				<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Especialidad</th>
						<th>Tipo de especialidad</th>
						<th>Estado</th>
						<th>Action</th>
					</tr>
					<tbody>
						@foreach($especialidads as $especialidad)
							<tr>
								<td>{{ $especialidad->NombreEspecialidad }}</td>
								<td>{{ $especialidad->NombreTipoEspecialidad }}</td>
								<td>{{ $especialidad->NombreEstado }}</td>
								<td>
									<a class="btn btn-primary btn-xs" href="{{ route('especialidad.edit', ['id' => $especialidad->id] )}}">Edit</a>
									<a class="btn btn-danger btn-xs" href="{{ route('especialidad/destroy', ['id' => $especialidad->id] )}}">Delete</a>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</article>
		</section>
	</section>
@endsection
