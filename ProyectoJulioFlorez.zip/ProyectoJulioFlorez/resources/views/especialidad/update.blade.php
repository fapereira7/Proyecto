@extends('layouts.menu')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::model($especialidad,['route' => 'especialidad/update', 'method' => 'put', 'novalidate']) !!}
				{!! Form::hidden('id', $especialidad->id) !!}
					<article class="form-group">
						{!! Form::label('NombreEspecialidad', 'Especialidad') !!}
						{!! Form::text('NombreEspecialidad', null, ['class' => 'form-control','required' => 'required']) !!}	
					</article>
					<article class="form-group">
						{!! Form::label('NombreTipoEspecialidad', 'Tipo de especialidad') !!}
						{!! Form::select('NombreTipoEspecialidad',$tipo_especialidads, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::label('NombreEstado', 'Estado') !!}
						{!! Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!} 				
					</article>
			{!! Form::close() !!}		
		</section>
	</section>
@endsection