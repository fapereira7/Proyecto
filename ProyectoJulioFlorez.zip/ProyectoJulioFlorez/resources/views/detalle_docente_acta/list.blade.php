@extends('layouts.app')
@section('content')
<h1>Registros detalle docente acta</h1>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::open(['route' => 'detalle_docente_acta/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']) !!}
				<article class="form-group">
					<label for="exampleInputName2">Name</label>
					<input type="text" class="form-control" name="DescripcionDetalleDa">
					<button type="submit" class="btn btn-default">Search</button>
					<a href="{{ route('detalle_docente_acta.index') }}" class="btn btn-primary">All</a>
					<a href="{{ route('detalle_docente_acta.create') }}" class="btn btn-primary">Create</a>
				</article>
			{!! Form::close() !!}
			<article class="form-group">
				<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Descripcion acta</th>
						<th>Docente</th>
						<th>Acta</th>
						<th>Action</th>
					</tr>
					<tbody>
						@foreach($detalle_docente_actas as $detalle_docente_acta)
							<tr>
								<td>{{ $detalle_docente_acta->DescripcionDetalleDA }}</td>
								<td>{{ $detalle_docente_acta->NombreDocente }}</td>
								<td>{{ $detalle_docente_acta->FechaActa }}</td>
								<td>
									<a class="btn btn-primary btn-xs" href="{{ route('detalle_docente_acta.edit', ['id' => $detalle_docente_acta->id] )}}">Edit</a>
									<a class="btn btn-danger btn-xs" href="{{ route('detalle_docente_acta/destroy', ['id' => $detalle_docente_acta->id] )}}">Delete</a>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</article>
		</section>
	</section>
@endsection