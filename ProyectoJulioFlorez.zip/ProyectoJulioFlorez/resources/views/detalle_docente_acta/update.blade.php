@extends('layouts.app')
@section('content')
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::model($detalle_docente_acta,['route' => 'detalle_docente_acta/update', 'method' => 'put', 'novalidate']) !!}
				{!! Form::hidden('id', $detalle_docente_acta->id) !!}
					<article class="form-group">
						{!! Form::label('DescripcionDetalleDA', 'Descripcion del acta') !!}
						{!! Form::textarea('DescripcionDetalleDA', null, ['class' => 'form-control','required' => 'required']) !!}	
					</article>
					<article class="form-group">
						{!! Form::label('NombreDocente', 'Docente') !!}
						{!! Form::select('NombreDocente',$docentes, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::label('FechaActa', 'Fecha de acta') !!}
						{!! Form::select('FechaActa',$actas, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!} 				
					</article>
			{!! Form::close() !!}		
		</section>
	</section>
@endsection