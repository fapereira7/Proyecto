@extends('layouts.app')
@section('content')
<section class="container">
	<section class="row">
		<article class="col-md-10 col-md-offset-1">
			{!! Form::open(['route' => 'detalle_docente_acta.store', 'method' => 'post', 'novalidate']) !!}
				<section class="form-group">
					{!! Form::label('DescripcionDetalleDA', 'Descripcion del acta') !!}
					{!! Form::textarea('DescripcionDetalleDA', null, ['class' => 'form-control','required' => 'required']) !!}
				</section>
				<section class="form-group">
					{!! Form::label('NombreDocente', 'Docente') !!}
					{!! Form::select('NombreDocente',$docentes, null, ['class' => 'form-control', 'required' => 'required']) !!}
				</section>
				<section class="form-group">
					{!! Form::label('FechaActa', 'Fecha de acta') !!}
					{!! Form::select('FechaActa',$actas, null, ['class' => 'form-control', 'required' => 'required']) !!}
				</section>
				<section class="form-group">
					{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!}
				</section>
			{!! Form::close() !!}
		</article>
	</section>
</section>
@endsection