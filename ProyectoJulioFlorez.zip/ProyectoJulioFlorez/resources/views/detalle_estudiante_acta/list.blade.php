@extends('layouts.app')
@section('content')
<h1>Registros detalle estudiante acta</h1>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::open(['route' => 'detalle_estudiante_acta/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']) !!}
				<article class="form-group">
					<label for="exampleInputName2">Name</label>
					<input type="text" class="form-control" name="NombreEstado">
					<button type="submit" class="btn btn-default">Search</button>
					<a href="{{ route('detalle_estudiante_acta.index') }}" class="btn btn-primary">All</a>
					<a href="{{ route('detalle_estudiante_acta.create') }}" class="btn btn-primary">Create</a>
				</article>
			{!! Form::close() !!}
			<article class="form-group">
				<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Descripción</th>
						<th>Estudiante</th>
						<th>Acta</th>
						<th>Action</th>
					</tr>
					<tbody>
						@foreach($detalle_estudiante_actas as $detalle_estudiante_acta)
							<tr>
								<td>{{ $detalle_estudiante_acta->DescripcionDetalleEA }}</td>
								<td>{{ $detalle_estudiante_acta->NombreEstudiante }}</td>
								<td>{{ $detalle_estudiante_acta->FechaActa }}</td>
								<td>
									<a class="btn btn-primary btn-xs" href="{{ route('detalle_estudiante_acta.edit', ['id' => $detalle_estudiante_acta->id] )}}">Edit</a>
									<a class="btn btn-danger btn-xs" href="{{ route('detalle_estudiante_acta/destroy', ['id' => $detalle_estudiante_acta->id] )}}">Delete</a>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</article>
		</section>
	</section>
@endsection