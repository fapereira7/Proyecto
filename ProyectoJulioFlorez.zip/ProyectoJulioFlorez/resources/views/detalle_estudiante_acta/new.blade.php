@extends('layouts.app')
@section('content')
<section class="container">
	<section class="row">
		<article class="col-md-10 col-md-offset-1">
			{!! Form::open(['route' => 'detalle_estudiante_acta.store', 'method' => 'post', 'novalidate']) !!}
				<section class="form-group">
					{!! Form::label('DescripcionDetalleEA', 'Descripción') !!}
					{!! Form::textarea('DescripcionDetalleEA', null, ['class' => 'form-control','required' => 'required']) !!}
				</section>
				<section class="form-group">
					{!! Form::label('NombreEstudiante', 'Estudiante') !!}
					{!! Form::select('NombreEstudiante',$estudiantes, null, ['class' => 'form-control', 'required' => 'required']) !!}
				</section>
				<section class="form-group">
					{!! Form::label('FechaActa', 'Acta') !!}
					{!! Form::select('FechaActa',$actas, null, ['class' => 'form-control', 'required' => 'required']) !!}
				</section>
				<section class="form-group">
					{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!}
				</section>
			{!! Form::close() !!}
		</article>
	</section>
</section>
@endsection