@extends('layouts.app')
@section('content')
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::model($detalle_estudiante_acta,['route' => 'detalle_estudiante_acta/update', 'method' => 'put', 'novalidate']) !!}
				{!! Form::hidden('id', $detalle_estudiante_acta->id) !!}
					<article class="form-group">
						{!! Form::label('DescripcionDetalleEA', 'Descripción') !!}
						{!! Form::textarea('DescripcionDetalleEA', null, ['class' => 'form-control','required' => 'required']) !!}	
					</article>
					<article class="form-group">
						{!! Form::label('NombreEstudiante', 'Estudiante') !!}
						{!! Form::select('NombreEstudiante',$estudiantes, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::label('FechaActa', 'Acta') !!}
						{!! Form::select('FechaActa',$actas, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!} 				
					</article>
			{!! Form::close() !!}		
		</section>
	</section>
@endsection