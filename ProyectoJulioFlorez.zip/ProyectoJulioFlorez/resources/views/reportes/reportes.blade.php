 @include('layouts.MenuRegistros')
<div class="container">
	<div class="row">
		<div class="col-md-12 col-xs-12"> 
			<a href="{{ route('estudiante.index') }}">Historial estudiante</a>
			<a href="{{ route('especialidad/invoice') }}">Reporte especialidades</a>
			<a href="{{ route('ficha/invoice') }}">Reporte actas</a>
		</div>
	</div>
</div>
