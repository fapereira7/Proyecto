@extends('layouts.menu')
@section('content') 
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
  <span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper"> 
  <div class="row">
  <a href="{{ route('estudiante.index') }}">
    <div class="col-sm-4 col-md-4">
            <div class="col-xs-12 text-center well panel">
              <div class="row">
                <div class="col-xs-3 visible-xs"></div>
                  <div class="col-xs-6 col-sm-4 col-sm-offset-3">
                    <img class="img-responsive img-circle" src="http://localhost:8000/images/iconos menu/icon.png">
                  </div>
                </div>
                <div class="letras">
                  <h5 class="jf">ESTUDIANTES</h5>
                </div>
              </div>
          </div>
        </a>
        <a href="#">
          <div class="col-sm-4 col-md-4">
            <div class="col-xs-12 text-center well panel">
              <div class="row">
                <div class="col-xs-3 visible-xs"></div>
                  <div class="col-xs-6 col-sm-4 col-sm-offset-3">
                    <img class="img-responsive img-circle" src="http://localhost:8000/images/iconos menu/icon1.png">
                  </div>
                </div>
                <div class="letras">
                  <h5 class="jf">DOCENTES</h5>
                </div>
              </div>
          </div>
        </a>
        <a href="#">
          <div class="col-sm-4 col-md-4">
            <div class="col-xs-12 text-center well panel">
              <div class="row">
                <div class="col-xs-3 visible-xs col-sm-offset-1"></div>
                  <div class="col-xs-6 col-sm-4 col-sm-offset-3">
                    <img class="img-responsive img-circle" src="http://localhost:8000/images/iconos menu/icon2.png">
                  </div>
                </div>
                <div class="letras">
                  <h5 class="jf">ASISTENCIAS</h5>
                </div>
              </div>
              </div>
        </a>
      </div>
      <div class="row">
          <a href="#" class="panel">
            <div class="col-sm-4 col-md-4 col-md-offset-2 col-xs-offset-2">
              <div class="col-xs-12 text-center well panel">
                <div class="row ">
                  <div class="col-xs-3 visible-xs"></div>
                    <div class="col-xs-6 col-sm-4 col-sm-offset-3">
                      <img class="img-responsive img-circle" src="http://localhost:8000/images/iconos menu/icon3.png">
                    </div>
                  </div>
                  <div class="letras">
                    <h5 class="jf">ESTADISTICAS</h5>
                  </div>
                </div>
            </div>
          </a>
          <a href="#" class="panel">
            <div class="col-sm-4 col-md-4">
              <div class="col-xs-12 text-center well panel">
                <div class="row">
                  <div class="col-xs-3 visible-xs col-sm-offset-1"></div>
                    <div class="col-xs-6 col-sm-4 col-sm-offset-3">
                      <img class="img-responsive img-circle" src="http://localhost:8000/images/iconos menu/icon6.png">
                    </div>
                  </div>
                  <div class="letras">
                    <h5 class="jf">ACTAS</h5>
                  </div>
                </div>
                </div>
        </a>
      </div>

@endsection