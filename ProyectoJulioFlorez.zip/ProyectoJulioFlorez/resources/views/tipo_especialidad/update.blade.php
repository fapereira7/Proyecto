@extends('layouts.app')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::model($tipo_especialidad,['route' => 'tipo_especialidad/update', 'method' => 'put', 'novalidate']) !!}
				{!! Form::hidden('id', $tipo_especialidad->id) !!}
					<article class="form-group">
						{!! Form::label('NombreTipoEspecialidad', 'Nombre del tipo de especialidad') !!}
						{!! Form::text('NombreTipoEspecialidad', null, ['class' => 'form-control','required' => 'required']) !!}
					</article>
					<article class="form-group">
						{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!}
					</article>
			{!! Form::close() !!}
		</section>
	</section>
@endsection