@extends('layouts.app')
@section('content')
<h1>Registros detalle docente especialidad</h1>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::open(['route' => 'detalle_docente_especialidad/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']) !!}
				<article class="form-group">
					<label for="exampleInputName2">Name</label>
					<input type="text" class="form-control" name="NombreEstado">
					<button type="submit" class="btn btn-default">Search</button>
					<a href="{{ route('detalle_docente_especialidad.index') }}" class="btn btn-primary">All</a>
					<a href="{{ route('detalle_docente_especialidad.create') }}" class="btn btn-primary">Create</a>
				</article>
			{!! Form::close() !!}
			<article class="form-group">
				<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Descripcion</th>
						<th>Docente</th>
						<th>Especialidad</th>
						<th>Acción</th>
					</tr>
					<tbody>
						@foreach($detalle_docente_especialidads as $detalle_docente_especialidad)
							<tr>
								<td>{{ $detalle_docente_especialidad->DescripcionDetalleDE }}</td>
								<td>{{ $detalle_docente_especialidad->NombreDocente }}</td>
								<td>{{ $detalle_docente_especialidad->NombreEspecialidad }}</td>
								<td>
									<a class="btn btn-primary btn-xs" href="{{ route('detalle_docente_especialidad.edit', ['id' => $detalle_docente_especialidad->id] )}}">Edit</a>
									<a class="btn btn-danger btn-xs" href="{{ route('detalle_docente_especialidad/destroy', ['id' => $detalle_docente_especialidad->id] )}}">Delete</a>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</article>
		</section>
	</section>
@endsection