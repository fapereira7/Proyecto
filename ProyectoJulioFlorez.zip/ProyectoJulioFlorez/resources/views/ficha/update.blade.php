@include('layouts.MenuRegistros')
@extends('layouts.footerForm')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-xs-12 text-center">
				<div class="conRegistro  form-group">
	            	<p class="Registros registro">ACTUALIZAR FICHA</p>
	           	</div>
				{!! Form::model($ficha,['route' => 'ficha/update', 'method' => 'put', 'novalidate','class' => 'FormularioEst']) !!}
				{!! Form::hidden('id', $ficha->id) !!}
					<section class="form-group">
					<span class="input input--kaede">
						{!! Form::text('NumeroFicha', null, ['id' => 'input1', 'class' => 'input__field input__field--kaede','required' => 'required']) !!}
						<label class="input__label input__label--kaede" for="input1">
							<span class="input__label-content input__label-content--kaede">Número de ficha</span>
						</label>
					</span>
					</section>
					<section class="form-group">
						{!! Form::select('NombreGrado',$grados, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('NombreEspecialidad',$especialidads, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</section>
					<section class="form-group">
						{!! Form::submit('Editar', ['class' => 'btn-2 btn-2d']) !!}
					</section>
				{!! Form::close() !!}
			</div>
		</div>
	</div>
</div>
