@extends('layouts.menu')
@extends('layouts.footerForm')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			{!! Form::model($acta,['route' => 'acta/update', 'method' => 'put', 'novalidate']) !!}
				{!! Form::hidden('id', $acta->id) !!}
					<section class="form-group">
					{!! Form::label('IdentificacionActa', 'Número de acta') !!}
					{!! Form::text('IdentificacionActa', null, ['class' => 'form-control','required' => 'required']) !!}
					</section>
					<section class="form-group">
					{!! Form::label('FechaActa', 'Fecha del acta') !!}
					{!! Form::date('FechaActa', null, ['class' => 'form-control','required' => 'required']) !!}
				</section>
					<section class="form-group">
						{!! Form::label('Descripcion', 'Descripción') !!}
						{!! Form::textarea('Descripcion', null, ['class' => 'form-control','required' => 'required']) !!}
					</section>
					<section class="form-group">
						{!! Form::label('UrlActa', 'Url del acta') !!}
						{!! Form::text('UrlActa', null, ['class' => 'form-control','required' => 'required']) !!}
					</section>
					<section class="form-group">
						{!! Form::label('NombreTipoActa', 'Tipo del acta') !!}
						{!! Form::select('NombreTipoActa',$tipo_actas, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</section>
					<section class="form-group">
						{!! Form::label('NombreEstado', 'Estado') !!}
						{!! Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required']) !!}
					</section>
					<section class="form-group">
						{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!}
					</section>
			{!! Form::close() !!}
		</section>
	</section>
@endsection
