 @include('layouts.MenuRegistros')
 @extends('layouts.footerForm')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
            <div class="container-fluid">
            <p class="navbar-brand titulista">ACTAS</p>
    			{!! Form::open(['route' => 'acta/search', 'method' => 'post', 'novalidate', 'class' => 'navbar-form navbar-right']) !!}
    				<article class="form-group">
    					<label for="exampleInputName2" style="font-family: 'Raleway', sans-serif;">Nombre</label>
    					<input type="text" class="form-control inputlista" name="NombreAcudiente">
    					<button type="submit" class="btn botonlistabuscar">Search</button>
    					<a href="{{ route('acta.index') }}" class="btn botonlista">Todos</a>
    					<a href="{{ route('acta.create') }}" class="btn botonlista">Registrar nueva acta</a>
    				</article>
    			{!! Form::close() !!}
    			<div class="row">
                        <div class="col-lg-12">
    			<article class="form-group tabla">
    				<table class="table table-condensed table-striped table-bordered">
    					<tr>
    						<th>Número de acta</th>
    						<th>Fecha</th>
    						<th>Descripción</th>
    						<th>URL</th>
    						<th>Tipo de acta</th>
    						<th>Estado del acta</th>
    						<th>Action</th>
    					</tr>
    					<tbody>
    						@foreach($actas as $acta)
    							<tr>
    								<td>{{ $acta->IdentificacionActa }}</td>
    								<td>{{ $acta->FechaActa }}</td>
    								<td>{{ $acta->Descripcion }}</td>
    								<td>{{ $acta->UrlActa }}</td>
    								<td>{{ $acta->NombreTipoActa }}</td>
    								<td>{{ $acta->NombreEstado }}</td>
    								<td>
    									<a class="btn btn-primary btn-xs botonlista" href="{{ route('acta.edit', ['id' => $acta->id] )}}">Editar</a>
    									<a class="btn btn-primary btn-xs botonlista" href="{{ route('acta/download', ['archivo' => $acta->id]) }}">Descargar</a>
    								</td>
    							</tr>
						@endforeach
							   </tbody>
							</table>
							{!!$actas->render()!!}
						</article>
                    </div>
                </div>
            </div>
	</div>
<script type="text/javascript">
	  $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>
