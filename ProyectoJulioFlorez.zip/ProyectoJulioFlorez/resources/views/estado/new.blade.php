@extends('layouts.app')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<section class="container">
	<section class="row">
		<article class="col-md-10 col-md-offset-1">
			{!! Form::open(['route' => 'estado.store', 'method' => 'post', 'novalidate']) !!}
				<section class="form-group">
					{!! Form::label('NombreEstado', 'Estado') !!}
					{!! Form::text('NombreEstado', null, ['class' => 'form-control','required' => 'required']) !!}
				</section>
				<section class="form-group">
					{!! Form::label('NombreTipoEstado', 'Tipo de estado') !!}
					{!! Form::select('NombreTipoEstado',$tipo_estados, null, ['class' => 'form-control', 'required' => 'required']) !!}
				</section>
				<section class="form-group">
					{!! Form::submit('Enviar', ['class' => 'btn btn-success']) !!}
				</section>
			{!! Form::close() !!}
		</article>
	</section>
</section>
@endsection
