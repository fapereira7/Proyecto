@extends('layouts.app')
@extends('layouts.footerForm')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="conRegistro  form-group">
            		<p class="Registros registro">REGISTRO ACUDIENTE</p>
           		</div>
				{!! Form::open(['route' => 'acudiente.store', 'method' => 'post', 'novalidate', 'class' => 'FormularioEst']) !!}
				<section class="form-group">
					{!! Form::select('NombreTipoDocumento',$tipo_documentos, null, ['class' => 'form-control', 'required' => 'required', 'placeholder'=>'Tipo de documento']) !!}
				</section>
				<section class="form-group">
					{!! Form::number('IdentificacionAcudiente', null, ['class' => 'form-control','required' => 'required', 'placeholder'=>'Identificación']) !!}
				</section>
				<section class="form-group">
					{!! Form::text('NombreAcudiente', null, ['class' => 'form-control','required' => 'required', 'placeholder'=>'Nombre completo']) !!}
				</section>
				<section class="form-group">
					{!! Form::text('DireccionAcudiente', null, ['class' => 'form-control','required' => 'required', 'placeholder'=>'Dirección']) !!}
				</section>
				<section class="form-group">
					{!! Form::number('TelefonoFijoAcudiente', null, ['class' => 'form-control','required' => 'required', 'placeholder'=>'Telefono fijo']) !!}
				</section>
				<section class="form-group">
					{!! Form::number('TelefonoCelularAcudiente', null, ['class' => 'form-control','required' => 'required', 'placeholder'=>'Celular']) !!}
				</section>
				<section class="form-group">
					{!! Form::email('CorreoAcudiente', null, ['class' => 'form-control','required' => 'required', 'placeholder'=>'Correo']) !!}
				</section>
				<section class="form-group">
					{!! Form::select('NombreGenero',$generos, null, ['class' => 'form-control', 'required' => 'required', 'placeholder'=>'Genero']) !!}
				</section>
				<section class="form-group">
					{!! Form::select('TipoDeSangre',$tipo_de_sangres, null, ['class' => 'form-control', 'required' => 'required', 'placeholder'=>'Tipo de sangre']) !!}
				</section>
				<section class="form-group">
					{!! Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required', 'placeholder'=>'Estado']) !!}
				</section>
				<section class="form-group">
					{!! Form::submit('Registrar', ['id' => 'btnregistrar']) !!}
				</section>
				{!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>

@endsection
