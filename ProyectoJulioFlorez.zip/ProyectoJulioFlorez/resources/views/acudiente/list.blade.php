@extends('layouts.app')
@extends('layouts.footerForm')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
            <div class="container-fluid">
            <p class="navbar-brand titulista">ACUDIENTES</p>
			{!! Form::open(['route' => 'acudiente/search', 'method' => 'post', 'novalidate', 'class' => 'navbar-form navbar-right']) !!}
				<article class="form-group">
					<label for="exampleInputName2" style="font-family: 'Raleway', sans-serif;">Nombre</label>
					<input type="text" class="form-control inputlista" name="NombreAcudiente">
					<button type="submit" class="btn botonlistabuscar">Search</button>
					<a href="{{ route('acudiente.index') }}" class="btn botonlista">Todos</a>
					<a href="{{ route('acudiente.create') }}" class="btn botonlista">Registrar nuevo acudiente</a>
				</article>
			{!! Form::close() !!}
			<div class="row">
                    <div class="col-lg-12">
			<article class="form-group tabla">
				<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Tipo de documento</th>
						<th>Identificación</th>
						<th>Nombre completo</th>
						<th>Dirección</th>
						<th>Telefono</th>
						<th>Celular</th>
						<th>Correo</th>
						<th>Tipo de sangre</th>
						<th>Estado del acudiente</th>
						<th>Action</th>
					</tr>
					<tbody>
						@foreach($acudientes as $acudiente)
							<tr>
								<td>{{ $acudiente->NombreTipoDocumento }}</td>
								<td>{{ $acudiente->IdentificacionAcudiente }}</td>
								<td>{{ $acudiente->NombreAcudiente }}</td>
								<td>{{ $acudiente->DireccionAcudiente }}</td>
								<td>{{ $acudiente->TelefonoFijoAcudiente }}</td>
								<td>{{ $acudiente->TelefonoCelularAcudiente }}</td>
								<td>{{ $acudiente->CorreoAcudiente }}</td>
								<td>{{ $acudiente->TipoDeSangre }}</td>
								<td>{{ $acudiente->NombreEstado }}</td>
								<td>
									<a class="btn btn-primary btn-xs botonlista" href="{{ route('acudiente.edit', ['id' => $acudiente->id] )}}">Editar</a>
								</td>
							</tr>
						@endforeach
							   </tbody>
							</table>
							{!!$acudientes->render()!!}
						</article>
                    </div>
                </div>
            </div>
	</div>
@endsection
