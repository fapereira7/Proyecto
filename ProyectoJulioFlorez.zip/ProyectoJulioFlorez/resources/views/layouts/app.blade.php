<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Colegio Julio Florez</title>

    <link href="http://localhost:8000/images/julio1.png" rel="shortcut icon" type="image/x-icon"/>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700">
    <link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Titillium+Web' rel='stylesheet' type='text/css'>

    <!-- Styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css" integrity="sha384-XdYbMnZ/QjLh6iI4ogqCTaIjrFk87ip+ekIjefZch0Y+PvJ8CDYtEs1ipDmPorQ+" crossorigin="anonymous">

    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">

    <link href="{{ asset('css/Style.css') }}" rel="stylesheet">

    <link href="{{ asset('css/menuanimado.css') }}" rel="stylesheet">

    <link href="{{ asset('css/component.css') }}" rel="stylesheet">

    <link href="{{ asset('css/simple-sidebar.css') }}" rel="stylesheet">

    <link href="{{ asset('css/footer.css') }}" rel="stylesheet">

    <link href="{{ asset('css/footerForm.css') }}" rel="stylesheet">

    <link href="{{ asset('css/inputfiles.css') }}" rel="stylesheet">

    <link href="{{ asset('css/formdesplegable.css') }}" rel="stylesheet">

    {{-- <link href="{{ elixir('css/app.css') }}" rel="stylesheet"> --}}

    <script type="text/javascript" src="{{ asset('js/menuanimado.js') }}"></script>

    <script type="text/javascript" src="{{ asset('js/snap.svg-min.js') }}"></script>

    <script type="text/javascript" src="{{ asset('js/modernizr.custom.js') }}"></script>

    <!--[if IE]>
        <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->

</head>
<body id="app-layout" class="cuerpo">
<div class="main">
   <div class="media banner">
        <div class="media-left media-middle">
          <a href="{{ url('/principal') }}">
            <img class="media-object" src="/images/julio1.png" width="120" height="120" alt="Escudo Colegio Julio Florez">
          </a>
        </div>
        <div class="media-body"">
          <h1 class="media-heading letraheader white" style="margin-left:2%;">Institución Técnico Distrital Colegio Julio Florez</h1>
        </div>

     </div>
     <ul class="nav navbar-nav navbar-right">
        <!-- Authentication Links -->
        @if (Auth::guest())
        @else
            <li class="dropdown boxuser">
                <a href="#" class="dropdown-toggle linkuser" data-toggle="dropdown" role="button" aria-expanded="false" style="color: #FFFFFF; margin: 2px;">
                  <span class="glyphicon glyphicon-user"></span> {{ Auth::user()->name }} <span class="caret"></span>
                </a>

                <ul class="dropdown-menu logoutuser" role="menu">
                    <li><a href="{{ url('/logout') }}" style="color: #FFFFFF;"><i class="fa fa-btn fa-sign-out"></i>Cerrar sesión</a></li>
                </ul>
            </li>
        @endif
     </ul>

    @yield('content')

    <!-- JavaScripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js" integrity="sha384-I6F5OKECLVtK/BL+8iSLDEHowSAfUo76ZL9+kGAgTRdiByINKJaqTPH/QVNS1VDb" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>

    {{-- <script src="{{ elixir('js/app.js') }}"></script> --}}
