
   <footer>
        <div class="splitter"></div>
        <ul>
            <!-- three footer columns are here -->
        </ul>

        <div class="bar">
            <div class="bar-wrap">
                <p>Institución Educativa Distrital Colegio Julio Florez</p>
                <p>Tecnologo en Analisis y Desarrollo de Sistemas de Información &copy; 2016</p>
                <div class="social">
                    <!-- social icons are here -->
                </div>
                <div class="clear"></div>                
            </div>
        </div>
    </footer>

</body>
</html>
