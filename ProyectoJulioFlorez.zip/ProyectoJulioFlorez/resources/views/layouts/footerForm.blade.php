
<div id="footer1">
  <div class="col-lg-12 col-md-12 col-xs-12"></div>
    <div class="container">
        <p class="text-muted credit">
          <section id="texto">
                <p>Institución Educativa Distrital Colegio Julio Florez</p>
                <p>Tecnologo en Analisis y Desarrollo de Sistemas de Información &copy; 2016</p>
          </section>
        </p>
    </div>
</div>
