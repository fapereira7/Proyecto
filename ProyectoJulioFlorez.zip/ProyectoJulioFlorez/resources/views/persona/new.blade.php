@extends('layouts.app')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="conRegistro  form-group">
            		<p class="Registros registro">REGISTRO PERSONA</p>
           		</div>
				{!! Form::open(['route' => 'persona.store', 'method' => 'post', 'novalidate' , 'class' => 'FormularioEst']) !!}
				
					<section class="form-group">
						{!! Form::select('NombreTipoDocumento',$tipo_documentos, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Tipo de documento']) !!}
					</section>
					<section class="form-group">
						{!! Form::number('IdentificacionPersona', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Identificación']) !!}
					</section>
					<section class="form-group">
						{!! Form::text('NombrePersona', null, ['class' => 'form-control','required' => 'required' , 'placeholder' => 'Nombres y apellidos']) !!}
					</section>
					<section class="form-group">
						{!! Form::text('DireccionPersona', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Dirección']) !!}
					</section>
					<section class="form-group">
						{!! Form::number('TelefonoFijoPersona', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Telefono fijo']) !!}
					</section>
					<section class="form-group">
						{!! Form::number('TelefonoCelularPersona', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Celular']) !!}
					</section>
					<section class="form-group">
						{!! Form::email('CorreoPersona', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Correo']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('TipoDeSangre',$tipo_de_sangres, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Tipo de sangre']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('name',$users, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Usuario']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('NombreGenero',$generos, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Genero']) !!}
					</section>
					<section class="form-group">
						{!! Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Estado']) !!}
					</section>
					<section class="form-group">
						{!! Form::submit('Registrar', ['id' => 'btnregistrar']) !!}
					</section>
				{!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>

@endsection
