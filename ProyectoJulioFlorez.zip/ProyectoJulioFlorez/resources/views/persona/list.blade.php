@extends('layouts.menu')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
	<div id="page-content-wrapper">
            <div class="container-fluid">
            <p class="navbar-brand titulista">PERSONAS</p>
            {!! Form::open(['route' => 'persona/search', 'method' => 'post', 'novalidate', 'class' => 'navbar-form navbar-right']) !!}
						  <article class="form-group ">
							<label for="exampleInputName2" style="font-family: 'Raleway', sans-serif;">Nombre</label>
							<input type="text" class="form-control inputlista" name="NombreEstudiante">
							<button type="submit" class="btn botonlistabuscar">Buscar</button>
							<a href="{{ route('persona.index') }}" class="btn botonlista">Todos</a>
							<a href="{{ route('persona.create') }}" class="btn botonlista">Registrar nueva persona</a>
				          </article>
						{!! Form::close() !!}
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-xs-12">
						<article class="form-group tabla">
							<table class="table table-condensed table-striped table-bordered">
								<tr>
									<th>Tipo de documento</th>
									<th>Identificación</th>
									<th>Nombre completo</th>
									<th>Direccion</th>
									<th>Telefono fijo</th>
									<th>Celular</th>
									<th>Correo</th>
									<th>Tipo de sangre</th>
									<th>Usuario</th>
									<th>Genero</th>
									<th>Estado</th>
									<th>Action</th>
								</tr>
								<tbody>
									@foreach($personas as $persona)
										<tr>
											<td>{{ $persona->NombreTipoDocumento }}</td>
											<td>{{ $persona->IdentificacionPersona }}</td>
											<td>{{ $persona->NombrePersona }}</td>
											<td>{{ $persona->DireccionPersona }}</td>
											<td>{{ $persona->TelefonoFijoPersona }}</td>
											<td>{{ $persona->TelefonoCelularPersona }}</td>
											<td>{{ $persona->CorreoPersona }}</td>
											<td>{{ $persona->TipoDeSangre }}</td>
											<td>{{ $persona->name }}</td>
											<td>{{ $persona->NombreGenero }}</td>
											<td>{{ $persona->NombreEstado }}</td>

											<td>
												<a class="btn btn-primary btn-xs botonlista" href="{{ route('persona.edit', ['id' => $persona->id] )}}">Editar</a>
											</td>
										</tr>
									@endforeach
								</tbody>
							</table>
							{!!$personas->render()!!}
						</article>
                    </div>
                </div>
            </div>
	</div>
@endsection