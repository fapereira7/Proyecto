@extends('layouts.menu')
@section('content')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
    <span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="conRegistro  form-group">
                    <p class="Registros registro">ACTUALIZAR PERSONA</p>
                </div>
            {!! Form::model($persona,['route' => 'persona/update', 'method' => 'put', 'novalidate', 'class'=>'FormularioEst']) !!}
                {!! Form::hidden('id', $persona->id) !!}
                    <section class="form-group">
                        {!! Form::select('NombreTipoDocumento',$tipo_documentos, null, ['class' => 'form-control', 'required' => 'required']) !!}
                    </section>
                    <section class="form-group">
                        {!! Form::number('IdentificacionPersona', null, ['class' => 'form-control','required' => 'required']) !!}
                    </section>
                    <section class="form-group">
                        {!! Form::text('NombrePersona', null, ['class' => 'form-control','required' => 'required']) !!}
                    </section>
                    <section class="form-group">
                        {!! Form::text('DireccionPersona', null, ['class' => 'form-control','required' => 'required']) !!}
                    </section>
                    <section class="form-group">
                        {!! Form::number('TelefonoFijoPersona', null, ['class' => 'form-control','required' => 'required']) !!}
                    </section>
                    <section class="form-group">
                        {!! Form::number('TelefonoCelularPersona', null, ['class' => 'form-control','required' => 'required']) !!}
                    </section>
                    <section class="form-group">
                        {!! Form::email('CorreoPersona', null, ['class' => 'form-control','required' => 'required']) !!}
                    </section>
                    <section class="form-group">
                        {!! Form::select('TipoDeSangre',$tipo_de_sangres, null, ['class' => 'form-control', 'required' => 'required']) !!}
                    </section>
                    <section class="form-group">
                        {!! Form::select('name',$users, null, ['class' => 'form-control', 'required' => 'required']) !!}
                    </section>
                    <section class="form-group">
                        {!! Form::select('NombreGenero',$generos, null, ['class' => 'form-control', 'required' => 'required']) !!}
                    </section>
                    <section class="form-group">
                        {!! Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required']) !!}
                    </section>
                    <section class="form-group">
                        {!! Form::submit('Registrar', ['id' => 'btnregistrar']) !!}
                    </section>
                {!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>
@endsection