 @include('Multimedia.menu')
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
	<div id="page-content-wrapper">
            <div class="container-fluid">
            <p class="navbar-brand titulista">ESTUDIANTES</p>
            {!! Form::open(['route' => 'estudiante/search', 'method' => 'post', 'novalidate', 'class' => 'navbar-form navbar-right']) !!}
						  <article class="form-group ">
							<label for="exampleInputName2" style="font-family: 'Raleway', sans-serif;">Nombre</label>
							<input type="text" class="form-control inputlista" name="NombreEstudiante">
							<button type="submit" class="btn botonlistabuscar">Buscar</button>
							<a href="{{ route('estudiante.index') }}" class="btn botonlista">Todos</a>
							<a href="{{ route('estudiante.create') }}" class="btn botonlista">Registrar nuevo estudiante</a>
				          </article>
						{!! Form::close() !!}
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-xs-12">
						<article class="form-group tabla">
							<table class="table table-condensed table-striped table-bordered">
								<tr>
									<th>Tipo de documento</th>
									<th>Identificación</th>
									<th>Nombre completo</th>
									<th>Direccion</th>
									<th>Telefono fijo</th>
									<th>Celular</th>
									<th>Correo</th>
									<th>Tipo de sangre</th>
									<th>Ficha</th>
									<th>Genero</th>
									<th>Estado</th>
									<th>Action</th>
								</tr>
								<tbody>
									@foreach($estudiantes as $estudiante)
										<tr>
											<td>{{ $estudiante->NombreTipoDocumento }}</td>
											<td>{{ $estudiante->IdentificacionEstudiante }}</td>
											<td>{{ $estudiante->NombreEstudiante }}</td>
											<td>{{ $estudiante->DireccionEstudiante }}</td>
											<td>{{ $estudiante->TelefonoFijoEstudiante }}</td>
											<td>{{ $estudiante->TelefonoCelularEstudiante }}</td>
											<td>{{ $estudiante->CorreoEstudiante }}</td>
											<td>{{ $estudiante->TipoDeSangre }}</td>
											<td>{{ $estudiante->NumeroFicha }}</td>
											<td>{{ $estudiante->NombreGenero }}</td>
											<td>{{ $estudiante->NombreEstado }}</td>

											<td>
												<a class="btn btn-primary btn-xs botonlista" href="{{ route('estudiante.edit', ['id' => $estudiante->id] )}}">Editar</a>
											</td>
										</tr>
									@endforeach
								</tbody>
							</table>
							{!!$estudiantes->render()!!}
						</article>
                    </div>
                </div>
            </div>
	</div>
	</div>
<script type="text/javascript">
	  $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>
	<!--@include('layouts.footer') -->

