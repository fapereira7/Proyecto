
function validacion(event) {
  valor = document.getElementById("input1").value;
  valor2 = document.getElementById("NombreEstado").selectedIndex;
  if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {

    // Si no se cumple la condicion...
    alert('El nombre del grado es obligatorio');
    return false;
    
  }
  else if ( valor2 == null || valor2 == 0 ) {

    // Si no se cumple la condicion...
    alert('Porfavor seleccione un estado');
    return false;
    
  }
  else {
   return true;
 }
}
