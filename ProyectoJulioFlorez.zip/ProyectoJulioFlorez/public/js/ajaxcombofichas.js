$(document).ready(function(){
	$('#Fichas').change(function(){
		//alert("Selecciono una opción");
		var Id_ficha = $('#Fichas').val();
	    var tokencombo = $('#tokencombo').val();
		$.ajax({
			dataType: 'json',
			type: "POST",
			url: "/asistencia/fichas",
			headers: {'X-CSRF-TOKEN': tokencombo},
			data: {Id_ficha},
			success: function(resp) {
				//alert("Todo bien");
				//console.log(resp);
				$('#combo').html(resp);
			},
			error: function(data) {
				alert("Ocurrio un error");
			}
		});
	});
});