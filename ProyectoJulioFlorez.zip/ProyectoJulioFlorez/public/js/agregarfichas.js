$(document).ready(function(){
   //Función para agregar columnas
   
   var arrayNumeroFicha = new Array();
   var arrayNombreEspecialidad = new Array();
   var arrayNombreEstadoFicha = new Array();

   alert("Ola ke ase Party Asqueroso");
   $("#agregar").click(function(e){
   	   var NumeroFicha = $('#NumeroFicha').val();
	   var NombreEspecialidad = $('option:selected').text();
	   var NombreEstadoFicha = $('#NombreEstadoFicha').val();
	   var NumFichas = $('#cantidadFichas').val();
       $("#fichas").append('<tr class="form-group"><td>"'+NumeroFicha+'"</td><td>"'+NombreEspecialidad+'"</td><td>"'+NombreEstadoFicha+'"</td></tr>');
       NumFichas++;
       arrayNumeroFicha[NumFichas] = $('#NumeroFicha').val();
       arrayNombreEspecialidad[NumFichas] = $('#NombreEspecialidad').val();
       arrayNombreEstadoFicha[NumFichas] = $('#NombreEstadoFicha').val();

       alert("ArrayFichas: "+NumeroFicha);
   });

   $("#enviarGrado").click(function(e){
       
   });
});