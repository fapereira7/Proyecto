function combo_anidado(){
	var Id_Tipo_Estado = $("#tipo_combo").val();
	var tokencombo = $("#tokencombo").val();
	//alert(Id_Tipo_Estado);
    //console.log(tokencombo);
	$.ajax({
		dataType: "json",
		type: "POST",
		url: "/tipo_estado/combo",
		headers: {'X-CSRF-TOKEN': tokencombo},
		data: {Id_Tipo_Estado},
		success: function(resp){
			if(resp!="")
		    {
		    	//alert("La consulta se realizó correctamente. ");
		    	console.log(resp);
			    $("#sectioncombo").html(resp);
			}
		},
		error: function(data){
			alert("Ocurrio un error en el envío de la petición. ");
			//console.log("Error"+data);
		}
	});
}