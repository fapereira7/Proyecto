$(document).ready(function(){
	$('#formEst').submit(function(e){
		e.preventDefault();
	});

	var NombreTipoDocumentoArray = new Array();
	var IdentificacionAcudienteArray = new Array();
	var NombreAcudienteArray = new Array();
	var DireccionAcudienteArray = new Array();
	var TelefonoFijoAcudienteArray = new Array();
	var TelefonoCelularAcudienteArray = new Array();
	var CorreoAcudienteArray = new Array();
	var NombreGeneroArray = new Array();
	var TipoDeSangreArray = new Array();
	var NombreEstadoArray = new Array();

	//Variable contadora
	var numAcudientes = 0;

	//Campos del detalle
	var parentescoArray = new Array();

    $('#formselecAcu').hide();
	$('#formAcu').hide();

	$('#selectacu').click(function(){
		var selected = jQuery('#selectacu');
		if (selected.is(':checked')) {
			$('#formselecAcu').slideDown(1000);
			$('#formAcu').slideUp('fast');
		} else {
			$('#formselecAcu').slideUp('fast');
		}
	});

	$('#regacud').click(function(){
		var regacud = jQuery('#regacud');
		if (regacud.is(':checked')) {
				$('#formAcu').slideDown(1000);
				$('#formselecAcu').slideUp('fast');
		} else {
			$('#formAcu').slideUp('fast');
		}
	});
	

	$('#agregarAcu').click(function(){
		var NombreAcudiente = $('#NombreAcudiente').val();
		var IdentificacionAcudiente = $('#IdentificacionAcudiente').val();
		var parentesco = $('#parentesco').find("option:selected").text();
		if (IdentificacionAcudiente == $('#Identificacion').attr('name')) {
			alert("El acudiente ya se encuentra registrado.");
		}
		else
		{
		    $('#fila').append('<tr id="Identificacion" name="'+IdentificacionAcudiente+'"><td>'+NombreAcudiente+'</td><td>'+IdentificacionAcudiente+'</td><td>'+parentesco+'</td><td class="remove"><button class="btn btn-danger">&times</button></td></tr>');
            NombreTipoDocumentoArray[numAcudientes] = $('#NombreTipoDocumento').val();
            IdentificacionAcudienteArray[numAcudientes] = $('#IdentificacionAcudiente').val();
            NombreAcudienteArray[numAcudientes] = $('#NombreAcudiente').val();
            DireccionAcudienteArray[numAcudientes] = $('#DireccionAcudiente').val();
            TelefonoFijoAcudienteArray[numAcudientes] = $('#TelefonoFijoAcudiente').val();
            TelefonoCelularAcudienteArray[numAcudientes] = $('#TelefonoCelularAcudiente').val();
            CorreoAcudienteArray[numAcudientes] = $('#CorreoAcudiente').val();
            NombreGeneroArray[numAcudientes] = $('#NombreGenero').val();
            TipoDeSangreArray[numAcudientes] = $('#TipoDeSangre').val();
            NombreEstadoArray[numAcudientes] = $('#NombreEstado').val();
            parentescoArray[numAcudientes] = $('#parentesco').val();
            numAcudientes++;
            alert("NombreTipoDocumentoArray: "+NombreTipoDocumentoArray);
	    }
	});

	$('table').on('click','.remove', function(event){
		var parentTag = $(this).parent('tr:first').attr('name');

		var buscador = IdentificacionAcudienteArray.indexOf(parentTag[1]);

		NombreTipoDocumentoArray.splice(buscador, 1);
		IdentificacionAcudienteArray.splice(buscador, 1);
		NombreAcudienteArray.splice(buscador, 1);
		DireccionAcudienteArray.splice(buscador, 1);
		TelefonoFijoAcudienteArray.splice(buscador, 1);
		TelefonoCelularAcudienteArray.splice(buscador, 1);
		CorreoAcudienteArray.splice(buscador, 1);
		NombreGeneroArray.splice(buscador, 1);
		TipoDeSangreArray.splice(buscador, 1);
		NombreEstadoArray.splice(buscador, 1);
		parentescoArray.splice(buscador, 1);

		$(this).parent('tr:first').remove();

		alert("NombreTipoDocumentoArray: "+NombreTipoDocumentoArray);

	});

	$('#btnregistrar').click(function(){
		var NombreTipoDocumento = $('#NombreTipoDocumento').val();
		var IdentificacionEstudiante = $('#IdentificacionEstudiante').val();
		var NombreEstudiante = $('#NombreEstudiante').val();
		var DireccionEstudiante = $('#DireccionEstudiante').val();
		var TelefonoFijoEstudiante = $('#TelefonoFijoEstudiante').val();
		var TelefonoCelularEstudiante = $('#TelefonoCelularEstudiante').val();
		var CorreoEstudiante = $('#CorreoEstudiante').val();
		var TipoDeSangre = $('#TipoDeSangre').val();
		var NumeroFicha = $('#NumeroFicha').val();
		var NombreGenero = $('#NombreGenero').val();
		var NombreEstado = $('#NombreEstado').val();
		var tokenEst = $('#tokenEst').val();
        
        //Campos del Acudiente
        var NombreTipoDocumento = $('#NombreTipoDocumento').val();
		var IdentificacionAcudiente = $('#IdentificacionAcudiente').val();
		var NombreAcudiente = $('#NombreAcudiente').val();
		var DireccionAcudiente = $('#DireccionAcudiente').val();
		var TelefonoFijoAcudiente = $('#TelefonoFijoAcudiente').val();
		var TelefonoCelularAcudiente = $('#TelefonoCelularAcudiente').val();
		var CorreoAcudiente = $('#CorreoAcudiente').val();
		var NombreGenero = $('#NombreGenero').val();
		var TipoDeSangre = $('#TipoDeSangre').val();
		var NombreEstado = $('#NombreEstado').val();
		var Id_Acudiente = $('#Id_Acudiente').val();

		//Campos del detalle
		var parentesco = $('#parentesco').find("option:selected").text();

		console.log(tokenEst);

		$.ajax({
			type: "POST",
			url: "/estudiante/store",
			headers: {'X-CSRF-TOKEN': tokenEst },
			data: {NombreTipoDocumento, IdentificacionEstudiante, NombreEstudiante, 
				DireccionEstudiante, TelefonoFijoEstudiante, TelefonoCelularEstudiante, 
				CorreoEstudiante, TipoDeSangre, NumeroFicha, NombreGenero, NombreEstado,
			    NombreTipoDocumentoArray, IdentificacionAcudienteArray, NombreAcudienteArray, DireccionAcudienteArray, 
			    TelefonoFijoAcudienteArray, TelefonoCelularAcudienteArray, CorreoAcudienteArray, NombreGeneroArray, TipoDeSangreArray, 
			    NombreEstadoArray, parentescoArray, numAcudientes, Id_Acudiente},
			success: function(data) {
				if(data != null){
					alert("Datos Guardados correctamente.");
					//window.location.href='/estudiante';
				}
			},
			error: function(data){
				alert("Ocurrio un error al realizar la petición.");
			}
		});
	});
});