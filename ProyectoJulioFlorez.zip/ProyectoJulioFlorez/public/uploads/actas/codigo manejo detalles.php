Archivo JS

$('#boton').click(function(event){

  // metodo para deshabilitar envio del formulario por submit
    event.preventDefault();

  // captura de los valores de los controles html en variables js
    var campo1 = $('#campo1').val();
    var campo2 = $('#campo2').val();
    var arrayDetalle = new Array();
    var cantidadDetalle = $('#cantidad').val();
    var token = $('#token').val();

  // ciclo para capturar los id's de las foraneas
    for (var i = 0; i < cantidad; i++) {
      arrayDetalle[i]=$('#campo3'+i).val();
    }

  //Inicio Metodo envio ajax
    $.ajax({
      type: "post",
      url: "/prueba/store",
      headers: {'X-CSRF-TOKEN': token},
      data: {campo1,campo2,arrayDetalle,cantidad},
      success: function(resp){
        if(resp!=""){
          alert("Datos Guardados Correctamente");
          window.location.href="/ruta";
        }
      },
      error: function(data) {
        alert("Error No se han Guardado los Datos!!");
      }
    });
  //Fin Metodo envio ajax
});

Controlador Metodo store
  Recuerden importar el modelo de la tabla detalle al inicio del controlador

public function store(Request $request)
{
  //pregunta si la peticion es ajax
  if($request->ajax())
  {
    // Registro de la tabla Padre

      $Prueba = new Prueba;
      $Prueba->campo1 = $request->campo1;
      $Prueba->campo2 = $request->campo2;
      $Prueba-> save();

  // Registro tabla Detalle

      for ($i=0; $i < $request->cantidad; $i++)
      {
        $detalle = new Deatalle;
        $detalle->fkprueba = $Prueba->id;
        $detalle->fktabla1 = $request->arrayDetalle;
        $detalle->save();
      }
      return redirect('Evaluacion');
  }
}
