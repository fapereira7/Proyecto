<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/



Route::get('/', function () {
    return view('index');
});
Route::auth();

Route::get('password/email','Auth\PasswordController@getEmail');
Route::post('password/email','Auth\PasswordController@postEmail');



//Rutas para el coordinador

Route::group(['middleware' => ['auth','Coordinador']],function(){

Route::get('/principal', function () {
    return view('pagprincipal');
});

Route::get('/reportes', function () {
    return view('reportes/reportes');
});

Route::get('/menu', function () {
    return view('Programacion/menu');
});

//Rutas para el recurso tipo_acta
Route::resource('tipo_acta','TipoActaController');

//Ruta para eliminar registros
Route::get('tipo_acta/destroy/{id}', ['as' => 'tipo_acta/destroy', 'uses'=>'TipoActaController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('tipo_acta/search', ['as' => 'tipo_acta/search', 'uses'=>'TipoActaController@search']);

//Ruta para realizar actualizacion de registros
Route::post('tipo_acta/update', ['as' => 'tipo_acta/update', 'uses'=>'TipoActaController@update']);

//--------------------------------------------------------------------------------------------------------------

//Ruta para acceder al formulario de archivos
Route::get('/formulario', 'StorageController@index');

Route::post('storage/create', 'StorageController@save');

Route::get('storage/{archivo}', function ($archivo) {
     $public_path = public_path();
     $url = $public_path.'/storage/'.$archivo;
     //verificamos si el archivo existe y lo retornamos
     if (Storage::exists($archivo))
     {
       return response()->download($url);
     }
     //si no se encuentra lanzamos un error 404.
     abort(404);

});

//--------------------------------------------------------------------------------------------------------------

//Rutas para el recurso acudiente
Route::resource('acudiente','AcudienteController');

//Ruta para eliminar registros
Route::get('acudiente/destroy/{id}', ['as' => 'acudiente/destroy', 'uses'=>'AcudienteController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('acudiente/search', ['as' => 'acudiente/search', 'uses'=>'AcudienteController@search']);

//Ruta para realizar actualizacion de registros
Route::post('acudiente/update', ['as' => 'acudiente/update', 'uses'=>'AcudienteController@update']);

//--------------------------------------------------------------------------------------------------------------


//Rutas para ver el archivo
Route::get('acta/stream/{id}', ['as' => 'acta/stream', 'uses'=>'ActaController@stream']);
//Rutas para el descargar archivo
Route::get('acta/download/{id}', ['as' => 'acta/download', 'uses'=>'ActaController@download']);

//Rutas para el form acta
Route::post('acta/post','ActaController@store');

//Rutas para el recurso acta
Route::resource('acta','ActaController');

//Ruta para eliminar registros
Route::get('acta/destroy/{id}', ['as' => 'acta/destroy', 'uses'=>'ActaController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('acta/search', ['as' => 'acta/search', 'uses'=>'ActaController@search']);

//Ruta para realizar actualizacion de registros
Route::post('acta/update', ['as' => 'acta/update', 'uses'=>'ActaController@update']);

//--------------------------------------------------------------------------------------------------------------


//Rutas para ver el archivo
Route::get('formato/stream/{id}', ['as' => 'formato/stream', 'uses'=>'FormatoController@stream']);
//Rutas para el descargar archivo
Route::get('formato/download/{id}', ['as' => 'formato/download', 'uses'=>'FormatoController@download']);

//Rutas para el form formato
Route::post('formato/post','FormatoController@store');

//Rutas para el recurso formato
Route::resource('formato','FormatoController');

//Ruta para eliminar registros
Route::get('formato/destroy/{id}', ['as' => 'formato/destroy', 'uses'=>'FormatoController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('formato/search', ['as' => 'formato/search', 'uses'=>'FormatoController@search']);

//Ruta para realizar actualizacion de registros
Route::post('formato/update', ['as' => 'formato/update', 'uses'=>'FormatoController@update']);



//--------------------------------------------------------------------------------------------------------------

//Rutas para el recurso grado
Route::resource('grado','GradoController');

//Ruta para eliminar registros
Route::get('grado/destroy/{id}', ['as' => 'grado/destroy', 'uses'=>'GradoController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('grado/search', ['as' => 'grado/search', 'uses'=>'GradoController@search']);

//Ruta para realizar actualizacion de registros
Route::post('grado/update', ['as' => 'grado/update', 'uses'=>'GradoController@update']);


//--------------------------------------------------------------------------------------------------------------

//Rutas para el recurso asistencia
Route::resource('asistencia','AsistenciaController');

//Ruta para eliminar registros
Route::get('asistencia/destroy/{id}', ['as' => 'asistencia/destroy', 'uses'=>'AsistenciaController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('asistencia/search', ['as' => 'asistencia/search', 'uses'=>'AsistenciaController@search']);

//Ruta para realizar actualizacion de registros
Route::post('asistencia/update', ['as' => 'asistencia/update', 'uses'=>'AsistenciaController@update']);

Route::post('asistencia/fichas', ['as' => 'asistencia/fichas', 'uses'=>'AsistenciaController@fichas']);


//--------------------------------------------------------------------------------------------------------------

//Rutas para el recurso estudiante
Route::resource('estudiante','EstudianteController');

//Ruta para eliminar registros
Route::get('estudiante/destroy/{id}', ['as' => 'estudiante/destroy', 'uses'=>'EstudianteController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('estudiante/search', ['as' => 'estudiante/search', 'uses'=>'EstudianteController@search']);

//Ruta para realizar actualizacion de registros
Route::post('estudiante/update', ['as' => 'estudiante/update', 'uses'=>'EstudianteController@update']);

//Ruta para ajax
Route::post('estudiante/store', ['as' => 'estudiante/store', 'uses'=>'EstudianteController@store']);

//--------------------------------------------------------------------------------------------------------------

//Reportes
Route::get('ficha/invoice', ['as' => 'ficha/invoice', 'uses'=>'FichaController@invoice']);

Route::get('estudiante/invoice/{id}', ['as' => 'estudiante/invoice', 'uses'=>'EstudianteController@invoice']);

Route::get('especialidad/invoice', ['as' => 'especialidad/invoice', 'uses'=>'EspecialidadController@invoice']);

//--------------------------------------------------------------------------------------------------------------

//Rutas para el recurso ficha
Route::resource('ficha','FichaController');

//Ruta para eliminar registros
Route::get('ficha/destroy/{id}', ['as' => 'ficha/destroy', 'uses'=>'FichaController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('ficha/search', ['as' => 'ficha/search', 'uses'=>'FichaController@search']);

//Ruta para realizar actualizacion de registros
Route::post('ficha/update', ['as' => 'ficha/update', 'uses'=>'FichaController@update']);

//--------------------------------------------------------------------------------------------------------------

//Rutas para el recurso persona
Route::resource('persona','PersonaController');

//Ruta para eliminar registros
Route::get('persona/destroy/{id}', ['as' => 'persona/destroy', 'uses'=>'PersonaController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('persona/search', ['as' => 'persona/search', 'uses'=>'PersonaController@search']);

//Ruta para realizar actualizacion de registros
Route::post('persona/update', ['as' => 'persona/update', 'uses'=>'PersonaController@update']);

//--------------------------------------------------------------------------------------------------------------

//Rutas para el recurso estudiante programacion
Route::resource('Programacion','EstudiantesProgramacionController');

//Ruta para eliminar registros
Route::get('Programacion/destroy/{id}', ['as' => 'Programacion/destroy', 'uses'=>'EstudiantesProgramacionController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('Programacion/search', ['as' => 'Programacion/search', 'uses'=>'EstudiantesProgramacionController@search']);

//Ruta para realizar actualizacion de registros
Route::post('Programacion/update', ['as' => 'Programacion/update', 'uses'=>'EstudiantesProgramacionController@update']);

//--------------------------------------------------------------------------------------------------------------

//Rutas para el recurso estudiante multimedia
Route::resource('Multimedia','EstudiantesMultimediaController');

//Ruta para eliminar registros
Route::get('Multimedia/destroy/{id}', ['as' => 'Multimedia/destroy', 'uses'=>'EstudiantesMultimediaController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('Multimedia/search', ['as' => 'Multimedia/search', 'uses'=>'EstudiantesMultimediaController@search']);

//Ruta para realizar actualizacion de registros
Route::post('Multimedia/update', ['as' => 'Multimedia/update', 'uses'=>'EstudiantesMultimediaController@update']);

//--------------------------------------------------------------------------------------------------------------

//Rutas para el recurso estudiante multimedia
Route::resource('Turismo','EstudiantesTurismoController');

//Ruta para eliminar registros
Route::get('Turismo/destroy/{id}', ['as' => 'Turismo/destroy', 'uses'=>'EstudiantesTurismoController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('Turismo/search', ['as' => 'Turismo/search', 'uses'=>'EstudiantesTurismoController@search']);

//Ruta para realizar actualizacion de registros
Route::post('Turismo/update', ['as' => 'Turismo/update', 'uses'=>'EstudiantesTurismoController@update']);
//--------------------------------------------------------------------------------------------------------------

//Rutas para el recurso estudiante multimedia
Route::resource('Empresas','EstudiantesEmpresasController');

//Ruta para eliminar registros
Route::get('Empresas/destroy/{id}', ['as' => 'Empresas/destroy', 'uses'=>'EstudiantesEmpresasController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('Empresas/search', ['as' => 'Empresas/search', 'uses'=>'EstudiantesEmpresasController@search']);

//Ruta para realizar actualizacion de registros
Route::post('Empresas/update', ['as' => 'Empresas/update', 'uses'=>'EstudiantesEmpresasController@update']);
//--------------------------------------------------------------------------------------------------------------

//Rutas para el recurso estudiante multimedia
Route::resource('Ambiente','EstudiantesAmbienteController');

//Ruta para eliminar registros
Route::get('Ambiente/destroy/{id}', ['as' => 'Ambiente/destroy', 'uses'=>'EstudiantesAmbienteController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('Ambiente/search', ['as' => 'Ambiente/search', 'uses'=>'EstudiantesAmbienteController@search']);

//Ruta para realizar actualizacion de registros
Route::post('Ambiente/update', ['as' => 'Ambiente/update', 'uses'=>'EstudiantesAmbienteController@update']);

});

//--------------------------------------------------------------------------------------------------------------

// Rutas para el asistente
//****************************************************************************************************
Route::group(['middleware' => ['auth','Asistente']],function(){
    //Rutas para el recurso asistencia
Route::resource('asistenciaAsis','AsistenciaController');

//Ruta para eliminar registros
Route::get('asistenciaAsis/destroy/{id}', ['as' => 'asistencia/destroy', 'uses'=>'AsistenciaController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('asistenciaAsis/search', ['as' => 'asistencia/search', 'uses'=>'AsistenciaController@search']);

//Ruta para realizar actualizacion de registros
Route::post('asistenciaAsis/update', ['as' => 'asistencia/update', 'uses'=>'AsistenciaController@update']);
});


//--------------------------------------------------------------------------------------------------------------

//Rutas para Tipo de estado

Route::resource('tipo_estado','TipoEstadoController');

//Ruta para eliminar registros
Route::get('tipo_estado/destroy/{id}', ['as' => 'tipo_estado/destroy', 'uses'=>'TipoEstadoController@destroy']);

//Ruta para realizar busqueda de registros
Route::post('tipo_estado/search', ['as' => 'tipo_estado/search', 'uses'=>'TipoEstadoController@search']);

//Ruta para realizar actualizacion de registros
Route::post('tipo_estado/update', ['as' => 'tipo_estado/update', 'uses'=>'TipoEstadoController@update']);

Route::post('tipo_estado/combo', ['as' => 'tipo_estado/combo', 'uses'=>'TipoEstadoController@combo']);
