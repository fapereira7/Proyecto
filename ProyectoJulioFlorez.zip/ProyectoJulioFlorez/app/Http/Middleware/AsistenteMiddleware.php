<?php

namespace App\Http\Middleware;

use Closure;
use App\Models\TipoPersona;

class AsistenteMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $tipo_personas =  TipoPersona::select('tipo_personas.NombreTipoPersona')
                ->join('users','users.fk_TipoPersona','=','tipo_personas.id')
                ->where('tipo_personas.id','=', \Auth::user()->fk_TipoPersona)
                ->get();
        
        foreach ($tipo_personas as $tipo_persona) {
             if($tipo_persona->NombreTipoPersona == 'Asistente')
            {
                return $next($request);
            }
            else
            {
                abort('403');
            }
        }
    }
}
