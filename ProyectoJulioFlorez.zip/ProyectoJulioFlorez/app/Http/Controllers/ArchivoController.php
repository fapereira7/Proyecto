<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class ArchivoController extends Controller
{
		/**
		* muestra el formulario para guardar archivos
		*
		* @return Response
		**/
public function index()
   {	
      return \View::make('storage/new');
   }
		/**
		* guarda un archivo en nuestro directorio local.
		*
		* @return Response
		*/
public function Store(Request $request)
	{
		Archivo::create($request->all());
		return "Listo";
	}
}
