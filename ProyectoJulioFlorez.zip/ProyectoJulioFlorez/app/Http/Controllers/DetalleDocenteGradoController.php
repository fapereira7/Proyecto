<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\DetalleDocenteGrado as DetalleDocenteGrado;
use App\Models\Docente as Docente;
use App\Models\Grado as Grado;

class DetalleDocenteGradoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $detalle_docente_grados = DetalleDocenteGrado::select('detalle_docente_grados.*','docentes.NombreDocente','grados.NombreGrado')
                  ->join('docentes','docentes.id','=','detalle_docente_grados.fk_Docente')
                  ->join('grados','grados.id','=','detalle_docente_grados.fk_Grado')
                  ->get();        
        return \View::make('detalle_docente_grado/list',compact('detalle_docente_grados'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $docentes = Docente::lists('NombreDocente','id');
        $grados = Grado::lists('NombreGrado','id');
        return \View::make('detalle_docente_grado/new',compact('docentes','grados'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $detalle_docente_grado = new DetalleDocenteGrado;
        $detalle_docente_grado->fk_Docente = $request->NombreDocente;
        $detalle_docente_grado->fk_Grado = $request->NombreGrado;
        $detalle_docente_grado->save();
        return redirect('detalle_docente_grado');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // Recibe el parametro id del registro a modificar
        $detalle_docente_grado = DetalleDocenteGrado::find($id);
        $docentes = Docente::lists('NombreDocente','id');
        $grados = Grado::lists('NombreGrado','id');
        return \View::make('detalle_docente_grado/update', compact('detalle_docente_grado','docentes','grados'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Almacenar los cambios modificados en el registro
        $detalle_docente_grado = DetalleDocenteGrado::find($request->id);
        $detalle_docente_grado->fk_Docente = $request->NombreDocente;
        $detalle_docente_grado->fk_Grado = $request->NombreGrado;
        $detalle_docente_grado->save();
        return redirect('detalle_docente_grado');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $detalle_docente_grado = DetalleDocenteGrado::find($id);
        $detalle_docente_grado->delete();
        return redirect()->back();
    }

    public function search(Request $request)
    {
        
    }
}
