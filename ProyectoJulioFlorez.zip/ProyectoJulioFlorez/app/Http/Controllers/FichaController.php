<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Models\Especialidad as Especialidad;
use App\Models\Grado as Grado;
use App\Models\Estado as Estado;
use App\Models\Ficha as Ficha;

use Illuminate\Support\Collection as Collection;


class FichaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $fichas = Ficha::select('fichas.*','especialidads.NombreEspecialidad','estados.NombreEstado','grados.NombreGrado')
                  ->join('especialidads','especialidads.id','=','fichas.fk_Especialidad')
                  ->join('estados','estados.id','=','fichas.fk_Estado')
                  ->join('grados','grados.id','=','fichas.fk_Grado')
                  ->paginate(5);        
        return \View::make('ficha/list',compact('fichas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $especialidads = Especialidad::lists('NombreEspecialidad','id');
        $estados = Estado::lists('NombreEstado','id');
        $grados = Grado::lists('NombreGrado','id');
        return \View::make('ficha/new',compact('grados','estados','especialidads'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Manejar peticiones
        $ficha = new Ficha;
        $ficha->NumeroFicha = $request->NumeroFicha;
        $ficha->fk_Especialidad = $request->NombreEspecialidad;
        $ficha->fk_Estado = $request->NombreEstado;
        $ficha->fk_Grado = $request->NombreGrado;
        $ficha->save();
        return redirect('ficha');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $ficha = Ficha::find($id); 
        $especialidads = Especialidad::lists('NombreEspecialidad','id');
        $estados = Estado::lists('NombreEstado','id');
        $grados = Grado::lists('NombreGrado','id');
        return \View::make('ficha/update',compact('grados','estados','especialidads','ficha'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $ficha = Ficha::find($request->id);
        $ficha->NumeroFicha = $request->NumeroFicha;
        $ficha->fk_Especialidad = $request->NombreEspecialidad;
        $ficha->fk_Estado = $request->NombreEstado;
        $ficha->fk_Grado = $request->NombreGrado;
        $ficha->save();
        return redirect('ficha');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function search(Request $request)
    {
        $fichas = Ficha::select('fichas.*','especialidads.NombreEspecialidad','estados.NombreEstado','grados.NombreGrado')
                  ->join('especialidads','especialidads.id','=','fichas.fk_Especialidad')
                  ->join('estados','estados.id','=','fichas.fk_Estado')
                  ->join('grados','grados.id','=','fichas.fk_Grado')
                  ->where('NumeroFicha','like','%'.$request->NumeroFicha.'%')
                  ->paginate(5);        
        return \View::make('ficha/list',compact('fichas'));
    }

     public function invoice(Request $request) 
    {
        $fichas = \DB::select(\DB::raw('select * from espinasistencias'));
       // $fichas = Collection::make($array);

        $especialidads1 = \DB::select(\DB::raw('select * from cantestudiantesfichas'));
        // $especialidads1 = Collection::make($array1);
        
        //dd($especialidads1);
        //$results = $especialidads1->chunk(20);

        $especialidads2 = \DB::select(\DB::raw('select * from cantidadtipoactas'));
        //$especialidads2 = Collection::make($array2);
        $pdf = \App::make('dompdf.wrapper');        
        $view =  \View::make('reportes/ReporteR3', compact('fichas','especialidads1','especialidads2'))->render();        
        $pdf->loadHTML($view);
        return $pdf->stream('reportes/ReporteR3.pdf');  
    }
}
