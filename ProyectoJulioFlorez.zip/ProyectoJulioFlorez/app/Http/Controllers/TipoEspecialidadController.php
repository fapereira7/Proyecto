<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\TipoEspecialidad as TipoEspecialidad;

class TipoEspecialidadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tipo_especialidads = TipoEspecialidad::all();
        return \View::make('tipo_especialidad/list',compact('tipo_especialidads'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tipo_especialidad.new');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $tipo_especialidad = new TipoEspecialidad;
        $tipo_especialidad ->create($request->all());
        return redirect('tipo_especialidad');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tipo_especialidad = TipoEspecialidad::find($id);
        return \View::make('tipo_especialidad/update',compact('tipo_especialidad'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $tipo_especialidad = TipoEspecialidad::find($request->id);
        $tipo_especialidad->NombreTipoEspecialidad = $request->NombreTipoEspecialidad;
        $tipo_especialidad->save();
        return redirect('tipo_especialidad');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $tipo_especialidad = TipoEspecialidad::find($id);
        $tipo_especialidad->delete();
        return redirect()->back();
    }

    //Buscar registros
     public function search(Request $request)
    {
        // funcion buscar
        $tipo_especialidads = TipoEspecialidad::where('NombreTipoEspecialidad','like','%'.$request->NombreTipoEspecialidad.'%')->get();
        return \View::make('tipo_especialidad/list', compact('tipo_especialidads'));
    }
}
