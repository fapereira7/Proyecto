<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Estado as Estado;
use App\Models\Estudiante as Estudiante;
use App\Models\Asistencia as Asistencia;
use App\Models\Ficha as Ficha;

class AsistenciaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $asistencias = Asistencia::select('asistencias.*','estudiantes.NombreEstudiante','estados.NombreEstado')
                  ->join('estados','estados.id','=','asistencias.fk_Estado')
                  ->join('estudiantes','estudiantes.id','=','asistencias.fk_Estudiante')
                  ->paginate(10);        
        return \View::make('asistencia/list',compact('asistencias'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $fichas = Ficha::select('fichas.*')
        ->join('especialidads','fichas.fk_Especialidad','=','especialidads.id')
        ->where('fichas.fk_Especialidad','=',1)
        ->paginate(10);
        $estudiantes = Estudiante::lists('NombreEstudiante','id');
        $options = Estado::select('id','NombreEstado')->where('estados.fk_TipoEstado','=',2)->get();
        return \View::make('asistencia/new',compact('estudiantes','options','fichas'));
    }

    public function fichas(Request $request)
    {
        if ($request->ajax()) {
            $fichas = Ficha::select('fichas.*')
            ->join('especialidads','fichas.fk_Especialidad','=','especialidads.id')
            ->where('fichas.fk_Especialidad','=',1)
            ->paginate(10);
            $estudiantes = Estudiante::select('estudiantes.*')
            ->join('fichas','estudiantes.fk_Ficha','=','fichas.id')
            ->where('fichas.id','=',$request->Id_ficha)
            ->paginate(10);
            $options = Estado::lists('NombreEstado','id');
            return response()->json(\View::make('asistencia/combo',compact('estudiantes','options','fichas'))->render());
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
   public function store(Request $request)
    {
        //Manejar peticiones
        //dd($request->all());
        $asistencia = new Asistencia;
        $asistencia->FechaAsistencia = $request->FechaAsistencia;
        $asistencia->fk_Estado = $request->optradio;
        $asistencia->fk_Estudiante = $request->NombreEstudiante;
        $asistencia->save();
        return redirect('asistencia');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $asistencia = Asistencia::find($id);  
        // Recibe el parametro id del registro a modificar
        $estados = Estado::lists('NombreEstado','id');
        $estudiantes = Estudiante::lists('NombreEstudiante','id');
        return \View::make('asistencia/update',compact('estados','asistencia','estudiantes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function update(Request $request)
     {
         // Almacenar los cambios modificados en el registro
         $asistencia = Asistencia::find($request->id);
         $asistencia->FechaAsistencia = $request->FechaAsistencia;
         $asistencia->fk_Estado = $request->NombreEstado;
         $asistencia->fk_Estudiante = $request->NombreEstudiante;
         $asistencia->save();
         return redirect('asistencia');
     }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $asistencia = Asistencia::find($id);
        $asistencia->delete();
        return redirect()->back();
    }


    public function search(Request $request)
    {
         $asistencias = Asistencia::select('asistencias.*','estudiantes.NombreEstudiante','estados.NombreEstado')
                  ->join('estados','estados.id','=','asistencias.fk_Estado')
                  ->join('estudiantes','estudiantes.id','=','asistencias.fk_Estudiante')
                  ->where('FechaAsistencia','=',$request->FechaAsistencia)
                  ->paginate(5); 
        return \View::make('asistencia/list', compact('asistencias'));
    }
}
