<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Estudiante as Estudiante;
use App\Models\Especialidad as Especialidad;
use App\Models\Estado as Estado;
use App\Models\TipoDocumento as TipoDocumento;
use App\Models\TipoDeSangre as TipoDeSangre;
use App\Models\Ficha as Ficha;
use App\Models\Genero as Genero;
use App\Models\Grado as Grado;
use App\Models\Acudiente as Acudiente;
use App\Models\DetalleEstudianteAcudiente as DetalleEstudianteAcudiente;
use Illuminate\Support\Collection as Collection;

class EstudianteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $estudiantes = Estudiante::select('estudiantes.*','fichas.NumeroFicha','estados.NombreEstado','tipo_documentos.NombreTipoDocumento','tipo_de_sangres.TipoDeSangre','generos.NombreGenero')
                  ->join('estados','estados.id','=','estudiantes.fk_Estado')
                  ->join('tipo_documentos','tipo_documentos.id','=','estudiantes.fk_TipoDocumento')
                  ->join('tipo_de_sangres','tipo_de_sangres.id','=','estudiantes.fk_TipoSangre')
                  ->join('fichas','fichas.id','=','estudiantes.fk_Ficha')
                  ->join('generos','generos.id','=','estudiantes.fk_Genero')
                  ->paginate(5);
        return \View::make('estudiante/list',compact('estudiantes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
       public function create()
    {
        $fichas = Ficha::lists('NumeroFicha','id');
        $estados = Estado::lists('NombreEstado','id');
        $tipo_documentos = TipoDocumento::lists('NombreTipoDocumento','id');
        $tipo_de_sangres = TipoDeSangre::lists('TipoDeSangre','id');
        $generos = Genero::lists('NombreGenero','id');
        $acudientes = Acudiente::select('NombreAcudiente','id')->paginate(10);
        return \View::make('Estudiante/new',compact('fichas','estados','tipo_documentos','tipo_de_sangres','generos','acudientes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
  public function store(Request $request)
    {
        if ($request->ajax()) {
            //dd($request->parentesco);
            //Manejar peticiones
            $estudiante = new Estudiante;
            $estudiante->CorreoEstudiante = $request->CorreoEstudiante;
            $estudiante->DireccionEstudiante = $request->DireccionEstudiante;
            $estudiante->fk_Genero = $request->NombreGenero;
            $estudiante->fk_Estado = $request->NombreEstado;
            $estudiante->fk_Ficha = $request->NumeroFicha;
            $estudiante->fk_TipoDocumento = $request->NombreTipoDocumento;
            $estudiante->fk_TipoSangre = $request->TipoDeSangre;
            $estudiante->IdentificacionEstudiante = $request->IdentificacionEstudiante;
            $estudiante->NombreEstudiante = $request->NombreEstudiante;
            $estudiante->TelefonoCelularEstudiante = $request->TelefonoCelularEstudiante;
            $estudiante->TelefonoFijoEstudiante = $request->TelefonoFijoEstudiante;
            $estudiante->save();
            //if($request->Id_Acudiente == "") {
            for ($i=0; $i < $request->numAcudientes; $i++) {
                //Manejar peticiones
                $acudiente = new Acudiente;
                $acudiente->IdentificacionAcudiente = $request->IdentificacionAcudienteArray[$i];
                $acudiente->NombreAcudiente = $request->NombreAcudienteArray[$i];
                $acudiente->DireccionAcudiente = $request->DireccionAcudienteArray[$i];
                $acudiente->TelefonoFijoAcudiente = $request->TelefonoFijoAcudienteArray[$i];
                $acudiente->TelefonoCelularAcudiente = $request->TelefonoCelularAcudienteArray[$i];
                $acudiente->CorreoAcudiente = $request->CorreoAcudienteArray[$i];
                $acudiente->fk_Genero = $request->NombreGeneroArray[$i];
                $acudiente->fk_Estado = $request->NombreEstadoArray[$i];
                $acudiente->fk_TipoDocumento = $request->NombreTipoDocumentoArray[$i];
                $acudiente->fk_TipoSangre = $request->TipoDeSangreArray[$i];
                $acudiente->save();

                //Agregamos en el detalle
                $detalle_estudiante = new DetalleEstudianteAcudiente;
                $detalle_estudiante->parentesco = $request->parentescoArray[$i];
                $detalle_estudiante->fk_Estudiante = $estudiante->id;
                $detalle_estudiante->fk_Acudiente = $acudiente->id;
                $detalle_estudiante->save();
            }
        }
      //} else {
                 /*$acudientes = Acudiente::select('acudientes.*')
                 ->where('acudientes.id',$request->Id_Acudiente)
                 ->get();
                 dd($acudientes);

                foreach ($acudientes as $acudiente) {
                    //Manejar peticiones
                    $IdentificacionAcudiente1 = $acudiente->IdentificacionAcudiente;
                    $NombreAcudiente1 = $acudiente->NombreAcudiente;
                    $DireccionAcudiente1 = $acudiente->DireccionAcudiente;
                    $TelefonoFijoAcudiente1 = $acudiente->TelefonoFijoAcudiente;
                    $TelefonoCelularAcudiente1 = $acudiente->TelefonoCelularAcudiente;
                    $CorreoAcudiente1 = $acudiente->CorreoAcudiente;
                    $fk_Estado1 = $acudiente->fk_Estado;
                    $fk_TipoDocumento1 = $acudiente->fk_TipoDocumento;
                    $fk_TipoSangre1 = $acudiente->fk_TipoSangre;
                    $fk_Genero1 = $acudiente->fk_Genero;
                }

                $acudiente = new Acudiente;
                $acudiente->IdentificacionAcudiente = $IdentificacionAcudiente1;
                $acudiente->NombreAcudiente = $NombreAcudiente1;
                $acudiente->DireccionAcudiente = $DireccionAcudiente1;
                $acudiente->TelefonoFijoAcudiente = $TelefonoFijoAcudiente1;
                $acudiente->TelefonoCelularAcudiente = $TelefonoCelularAcudiente1;
                $acudiente->CorreoAcudiente = $CorreoAcudiente1;
                $acudiente->fk_Estado = $fk_Estado1;
                $acudiente->fk_TipoDocumento = $fk_TipoDocumento1;
                $acudiente->fk_TipoSangre = $fk_TipoSangre1;
                $acudiente->fk_Genero = $fk_Genero1;
                $acudiente->save();

                $detalle_estudiante = new DetalleEstudianteAcudiente;
                $detalle_estudiante->parentesco = $request->parentesco;
                $detalle_estudiante->fk_Estudiante = $estudiante->id;
                $detalle_estudiante->fk_Acudiente = $acudiente->id;
                $detalle_estudiante->save();
            }
            
        }*/
        //return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $estudiante = Estudiante::find($id);
        // Recibe el parametro id del registro a modificar
        $fichas = Ficha::lists('NumeroFicha','id');
        $estados = Estado::lists('NombreEstado','id');
        $tipo_documentos = TipoDocumento::lists('NombreTipoDocumento','id');
        $tipo_de_sangres = TipoDeSangre::lists('TipoDeSangre','id');
        $generos = Genero::lists('NombreGenero','id');
        return \View::make('Estudiante/update',compact('fichas','estados','asistencias','tipo_documentos','tipo_de_sangres','generos','estudiante'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function update(Request $request)
     {
         // Almacenar los cambios modificados en el registro
         $estudiante = Estudiante::find($request->id);
         $estudiante->IdentificacionEstudiante = $request->IdentificacionEstudiante;
         $estudiante->NombreEstudiante = $request->NombreEstudiante;
         $estudiante->DireccionEstudiante = $request->DireccionEstudiante;
         $estudiante->TelefonoFijoEstudiante = $request->TelefonoFijoEstudiante;
         $estudiante->TelefonoCelularEstudiante = $request->TelefonoCelularEstudiante;
         $estudiante->CorreoEstudiante = $request->CorreoEstudiante;
         $estudiante->fk_TipoDocumento = $request->NombreTipoDocumento;
         $estudiante->fk_TipoSangre = $request->TipoDeSangre;
         $estudiante->fk_Ficha = $request->NumeroFicha;
         $estudiante->fk_Genero = $request->NombreGenero;
         $estudiante->fk_Estado = $request->NombreEstado;
         $estudiante->save();
         return redirect('estudiante');
     }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $estudiante = Estudiante::find($id);
        $estudiante->delete();
        return redirect()->back();
    }


    public function search(Request $request)
    {
        // funcion buscar
        $estudiantes = Estudiante::select('estudiantes.*','fichas.NumeroFicha','estados.NombreEstado','tipo_documentos.NombreTipoDocumento','tipo_de_sangres.TipoDeSangre','generos.NombreGenero')
                  ->join('estados','estados.id','=','estudiantes.fk_Estado')
                  ->join('tipo_documentos','tipo_documentos.id','=','estudiantes.fk_TipoDocumento')
                  ->join('tipo_de_sangres','tipo_de_sangres.id','=','estudiantes.fk_TipoSangre')
                  ->join('fichas','fichas.id','=','estudiantes.fk_Ficha')
                  ->join('generos','generos.id','=','estudiantes.fk_Genero')
                  ->where('NombreEstudiante','like','%'.$request->NombreEstudiante.'%')
                  ->paginate(5);

        return \View::make('Ambiente/list',compact('estudiantes'));
    }

    public function invoice(Request $request, $id)
    {
        //$estudiantes = Estudiante::find($id)->get();
        //$estudiantes = (\DB::raw('select estudiantes.IdentificacionEstudiante as "Identificación del estudiante", estudiantes.NombreEstudiante as "Nombre completo", especialidads.NombreEspecialidad as "Especialidad", fichas.NumeroFicha as "Ficha",count(formatos.fk_TipoFormato) as "Observaciones" from estudiantes inner join fichas on estudiantes.fk_Ficha = fichas.id inner join especialidads on especialidads.id = fichas.fk_Especialidad inner join formatos on formatos.fk_Estudiante = estudiantes.id inner join tipo_formatos on tipo_formatos.id = formatos.fk_TipoFormato where estudiantes.id = '.$request->id.' and formatos.fk_TipoFormato = 1;');
        //\DB::select('exec ProcedimientoHistorialEstudiante(?)',array($id));
        //$array = \DB::statement('CALL ProcedimientoHistorialEstudiante('.$id.')');
        $array = \DB::select(\DB::raw('CALL ProcedimientoHistorialEstudiante('.$id.')'));
        $estudiantes = Collection::make($array);

        $arrayA = \DB::select(\DB::raw('CALL LlamadosAtencion('.$id.')'));
        $estudiantesA = Collection::make($arrayA);

        $arrayB = \DB::select(\DB::raw('CALL Inasistencias('.$id.')'));
        $estudiantesB = Collection::make($arrayB);

        $arrayC = \DB::select(\DB::raw('CALL Excusas('.$id.')'));
        $estudiantesC = Collection::make($arrayC);

        $arrayD = \DB::select(\DB::raw('CALL FechasIn('.$id.')'));
        $estudiantesD = Collection::make($arrayD);

        $date = date('Y-m-d');
        //\DB::statement(\DB::raw('CALL ProcedimientoHistorialEstudiante(?)'),
        //array($id)
        //);
        //DB::select('CALL ProcedimientoHistorialEstudiante('.$request->id.')');
        //\DB::statement(\DB::raw('CALL ProcedimientoHistorialEstudiante('.$request->id.')'))->first();
        //$estudiantes = \DB::statement('CALL ProcedimientoHistorialEstudiante;');
        //$estudiante= \DB::statement(\DB::raw('CALL ProcedimientoHistorialEstudiante('.$request->id.');'));
        //dd($estudiantes);
        $view =  \View::make('reportes/ReporteEstudiante', compact('estudiantes','estudiantesA','estudiantesB','estudiantesC','estudiantesD','date'))->render();
        $pdf = \App::make('dompdf.wrapper');
        $pdf->loadHTML($view);
        return $pdf->stream('reportes/ReporteEstudiante'.$id.'.pdf');
    }
}
