<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\DetalleDocenteActa as DetalleDocenteActa;
use App\Models\Docente as Docente;
use App\Models\Acta as Acta;

class DetalleDocenteActaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $detalle_docente_actas = DetalleDocenteActa::select('detalle_docente_actas.*','docentes.NombreDocente','actas.FechaActa')
                  ->join('docentes','docentes.id','=','detalle_docente_actas.fk_Docente')
                  ->join('actas','actas.id','=','detalle_docente_actas.fk_Acta')
                  ->get();        
        return \View::make('detalle_docente_acta/list',compact('detalle_docente_actas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $docentes = Docente::lists('NombreDocente','id');
        $actas = Acta::lists('FechaActa','id');
        return \View::make('detalle_docente_acta/new',compact('docentes','actas'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $detalle_docente_acta = new DetalleDocenteActa;
        $detalle_docente_acta->DescripcionDetalleDA = $request->DescripcionDetalleDA;
        $detalle_docente_acta->fk_Docente = $request->NombreDocente;
        $detalle_docente_acta->fk_Acta = $request->FechaActa;
        $detalle_docente_acta->save();
        return redirect('detalle_docente_acta');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // Recibe el parametro id del registro a modificar
        $detalle_docente_acta = DetalleDocenteActa::find($id);
        $docentes = Docente::lists('NombreDocente','id');
        $actas = Acta::lists('FechaActa','id');
        return \View::make('detalle_docente_acta/update', compact('detalle_docente_acta','docentes','actas'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Almacenar los cambios modificados en el registro
        $detalle_docente_acta = DetalleDocenteActa::find($request->id);
        $detalle_docente_acta->DescripcionDetalleDA = $request->DescripcionDetalleDA;
        $detalle_docente_acta->fk_Docente = $request->NombreDocente;
        $detalle_docente_acta->fk_Acta = $request->FechaActa;
        $detalle_docente_acta->save();
        return redirect('detalle_docente_acta');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $detalle_docente_acta = DetalleDocenteActa::find($id);
        $detalle_docente_acta->delete();
        return redirect()->back();
    }

    public function search(Request $request)
    {
        // funcion buscar
        $detalle_docente_actas = DetalleDocenteActa::where('DescripcionDetalleDA','like','%'.$request->DescripcionDetalleDA.'%')->get();
        return \View::make('detalle_docente_acta/list', compact('detalle_docente_actas'));
    }
}
