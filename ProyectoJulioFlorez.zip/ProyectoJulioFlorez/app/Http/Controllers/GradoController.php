<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Estado as Estado;
use App\Models\Grado as Grado;
use App\Models\TipoEstado as TipoEstado;

class GradoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $grados = Grado::select('grados.*','estados.NombreEstado')
              ->join('estados','estados.id','=','grados.fk_Estado')
              ->paginate(5);        
        return \View::make('grado/list',compact('grados'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
   public function create()
    {
        $estados = Estado::lists('NombreEstado','id');
        return \View::make('grado/new',compact('grados','estados'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $grado = new Grado;
            $grado->NombreGrado = $request->NombreGrado;
            $grado->fk_Estado = $request->NombreEstado;
            $grado->save();
            return redirect('grado');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $grado = Grado::find($id);  
        // Recibe el parametro id del registro a modificar
        $estados = Estado::lists('NombreEstado','id');
        return \View::make('grado/update',compact('estados','grado'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function update(Request $request)
     {
         // Almacenar los cambios modificados en el registro
         $grado = Grado::find($request->id);
         $grado->NombreGrado = $request->NombreGrado;
         $grado->fk_Estado = $request->NombreEstado;
         $grado->save();
         return redirect('grado');
     }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $grado = Grado::find($id);
        $grado->delete();
        return redirect()->back();
    }


    public function search(Request $request)
    {
        $grados = Grado::select('grados.*','estados.NombreEstado')
              ->join('estados','estados.id','=','grados.fk_Estado')
              ->where('NombreGrado','like','%'.$request->NombreGrado.'%')
              ->paginate(5);
        return \View::make('grado/list', compact('grados'));
    }