<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Controller;

use App\Http\Requests;

use App\Models\Acta as Acta;
use App\Models\TipoActa as TipoActa;
use App\Models\Estado as Estado;

class ActaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $actas = Acta::select('actas.*','tipo_actas.NombreTipoActa','estados.NombreEstado')
                  ->join('tipo_actas','tipo_actas.id','=','actas.fk_TipoActa')
                  ->join('estados','estados.id','=','actas.fk_Estado')
                  ->paginate(10);       
        return \View::make('acta/list',compact('actas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tipo_actas = TipoActa::lists('NombreTipoActa','id');
        $estados = Estado::select('fk_TipoEstado','NombreEstado','id')->where('estados.fk_TipoEstado','=',1)->get();
        return \View::make('acta/new',compact('tipo_actas','estados'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getForm()
    {
        return view('acta/form');
    }


    public function store(Request $data)
    {
        $validation = Validator::make($data->all(), array( 
           'IdentificacionActa' => '',
            'FechaActa' => '',
            'Descripcion' => '',
            'UrlActa' => '',
            'fk_TipoActa' => '',
            'fk_Estado' => '',            
            ));
             if ($validation->fails())
            {
                return Redirect::to('acta/create')->WithErrors($validation);            
            }else
            {
                $Archivos = $data->file('UrlActa');
                $upload = 'uploads/actas';
                $filename = $Archivos->getClientOriginalName();
                $success = $Archivos->move($upload, $filename);

                if ($success)
                {
                    //Manejar peticiones
                    $acta = new Acta;
                    $acta->IdentificacionActa = $data->Input('IdentificacionActa');
                    $acta->FechaActa = $data->Input('FechaActa');
                    $acta->Descripcion = $data->Input('Descripcion');
                    $acta->UrlActa = $filename;
                    $acta->fk_TipoActa = $data->Input('NombreTipoActa');
                    $acta->fk_Estado = $data->NombreEstado;
                    $acta->save();
                    //print_r($table);exit();
                    return Redirect::to('acta')->with('success', 'Datos Subidos');
                }
            }
        //Manejar peticiones
        /*$acta = new Acta;
        $acta->IdentificacionActa = $request->IdentificacionActa;
        $acta->FechaActa = $request->FechaActa;
        $acta->Descripcion = $request->Descripcion;
        $acta->UrlActa = $request->UrlActa;
        $acta->fk_TipoActa = $request->NombreTipoActa;
        $acta->fk_Estado = $request->NombreEstado;
        $acta->save();
        return redirect('acta');*/
    }
    public function download($id)
    {
            $actas = Acta::select('actas.*')
                ->where('actas.id','=',$id)
                ->get();
            foreach ($actas as $acta) {
                $NombreArchivo = $acta->UrlActa;
            }
            //dd($NombreArchivo);
            $public_path = public_path();
            $url = $public_path.'/uploads/actas/'.$NombreArchivo;
            //verificamos si el archivo existe y lo retornamos
            //if (Storage::exists($NombreArchivo))
            //{
                return response()->download($url);
            //} else
            //{//si no se encuentra lanzamos un error 404.
                abort(404);
                //echo "Error 404:El archivo no se encuentra, intentelo nuevamente";
            //}
    }
    public function stream($id)
    {/*
            $actas = Acta::select('actas.*')
                ->where('actas.id','=',$id)
                ->get();
            foreach ($actas as $acta) {
                $NombreArchivo = $acta->UrlActa;
            }
            //dd($NombreArchivo);
            $public_path = public_path();
            $url = $public_path.'/uploads/actas/'.$NombreArchivo;
            //verificamos si el archivo existe y lo retornamos
            if (Storage::exists($NombreArchivo))
            {
                return response()->stream($url);
                
            } else
            {//si no se encuentra lanzamos un error 404.
                //abort(404);
                echo "Error 404:El archivo no se encuentra, intentelo nuevamente";
            }*/
    }
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $acta = Acta::find($id);
        // Recibe el parametro id del registro a modificar
        $tipo_actas = TipoActa::lists('NombreTipoActa','id');
        $estados = Estado::lists('NombreEstado','id');
        return \View::make('acta/update',compact('tipo_actas','acta','estados'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function update(Request $request)
     {
         // Almacenar los cambios modificados en el registro
         $acta = Acta::find($request->id);
         $acta->IdentificacionActa = $request->IdentificacionActa;
         $acta->FechaActa = $request->FechaActa;
         $acta->Descripcion = $request->Descripcion;
         $acta->UrlActa = $request->UrlActa;
         $acta->fk_TipoActa = $request->NombreTipoActa;
         $acta->fk_Estado = $request->NombreEstado;
         $acta->save();
         return redirect('acta');
     }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $acta = Acta::find($id);
        $acta->delete();
        return redirect()->back();
    }


    public function search(Request $request)
    {
        $actas = Acta::select('actas.*','tipo_actas.NombreTipoActa','estados.NombreEstado')
                  ->join('tipo_actas','tipo_actas.id','=','actas.fk_TipoActa')
                  ->join('estados','estados.id','=','actas.fk_Estado')
                  ->where('IdentificacionActa','like','%'.$request->IdentificacionActa.'%')
                  ->paginate(5);   
        return \View::make('acta/list', compact('actas'));
    }
}
