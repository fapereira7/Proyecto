<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Models\TipoActa as TipoActa;

class TipoActaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function index()
    {
        $tipo_actas = TipoActa::all();
       if(!$tipo_actas)
            $tipo_actas = [''=>''];

        return \View::make('tipo_acta/list',compact('tipo_actas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tipo_acta.new');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $tipo_acta = new TipoActa;
        $tipo_acta ->create($request->all());
        return redirect('tipo_acta');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tipo_acta = TipoActa::find($id);
        return \View::make('tipo_acta/update',compact('tipo_acta'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $tipo_acta = TipoActa::find($request->id);
        $tipo_acta->NombreTipoActa = $request->NombreTipoActa;
        $tipo_acta->save();
        return redirect('tipo_acta');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $tipo_acta = TipoActa::find($id);
        $tipo_acta->delete();
        return redirect()->back();
    }

    //Buscar registros
     public function search(Request $request)
    {
        // funcion buscar
        $tipo_actas = TipoActa::where('NombreTipoActa','like','%'.$request->NombreTipoActa.'%')->get();
        return \View::make('tipo_acta/list', compact('tipo_actas'));
    }
}
