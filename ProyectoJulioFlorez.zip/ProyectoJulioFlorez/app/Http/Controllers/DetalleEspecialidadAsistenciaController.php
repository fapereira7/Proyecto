<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\DetalleEspecialidadAsistencia as DetalleEspecialidadAsistencia;
use App\Models\Especialidad as Especialidad;
use App\Models\Asistencia as Asistencia;

class DetalleEspecialidadAsistenciaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $detalle_especialidad_asistencias = DetalleEspecialidadAsistencia::select('detalle_especialidad_asistencias.*','especialidads.NombreEspecialidad','asistencias.FechaAsistencia')
                  ->join('especialidads','especialidads.id','=','detalle_especialidad_asistencias.fk_Especialidad')
                  ->join('asistencias','asistencias.id','=','detalle_especialidad_asistencias.fk_Asistencia')
                  ->get();        
        return \View::make('detalle_especialidad_asistencia/list',compact('detalle_especialidad_asistencias'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $especialidads = Especialidad::lists('NombreEspecialidad','id');
        $asistencias = Asistencia::lists('FechaAsistencia','id');
        return \View::make('detalle_especialidad_asistencia/new',compact('especialidads','asistencias'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $detalle_especialidad_asistencia = new DetalleEspecialidadAsistencia;
        $detalle_especialidad_asistencia->DescripcionEA = $request->DescripcionEA;
        $detalle_especialidad_asistencia->fk_Especialidad = $request->NombreEspecialidad;
        $detalle_especialidad_asistencia->fk_Asistencia = $request->FechaAsistencia;
        $detalle_especialidad_asistencia->save();
        return redirect('detalle_especialidad_asistencia');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // Recibe el parametro id del registro a modificar
        $detalle_especialidad_asistencia = DetalleEspecialidadAsistencia::find($id);
        $especialidads = Especialidad::lists('NombreEspecialidad','id');
        $asistencias = Asistencia::lists('FechaAsistencia','id');
        return \View::make('detalle_especialidad_asistencia/update', compact('especialidads','asistencias','detalle_especialidad_asistencia'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Almacenar los cambios modificados en el registro
        $detalle_especialidad_asistencia = DetalleEspecialidadAsistencia::find($request->id);
        $detalle_especialidad_asistencia->DescripcionEA = $request->DescripcionEA;
        $detalle_especialidad_asistencia->fk_Especialidad = $request->NombreEspecialidad;
        $detalle_especialidad_asistencia->fk_Asistencia = $request->FechaAsistencia;
        $detalle_especialidad_asistencia->save();
        return redirect('detalle_especialidad_asistencia');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $detalle_especialidad_asistencia = DetalleEspecialidadAsistencia::find($id);
        $detalle_especialidad_asistencia->delete();
        return redirect()->back();
    }

    public function search(Request $request)
    {
        // funcion buscar
        $detalle_especialidad_asistencias = DetalleEspecialidadAsistencia::where('DescripcionEA','like','%'.$request->DescripcionEA.'%')->get();
        return \View::make('detalle_especialidad_asistencia/list', compact('detalle_especialidad_asistencias'));
    }
}
