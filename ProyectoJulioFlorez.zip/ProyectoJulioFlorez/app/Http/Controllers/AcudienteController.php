<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Acudiente as Acudiente;
use App\Models\Estado as Estado;
use App\Models\TipoDocumento as TipoDocumento;
use App\Models\TipoDeSangre as TipoDeSangre;
use App\Models\Genero as Genero;

class AcudienteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $acudientes = Acudiente::select('acudientes.*','estados.NombreEstado','tipo_documentos.NombreTipoDocumento','tipo_de_sangres.TipoDeSangre','generos.NombreGenero')
                  ->join('estados','estados.id','=','acudientes.fk_Estado')
                  ->join('tipo_documentos','tipo_documentos.id','=','acudientes.fk_TipoDocumento')
                  ->join('tipo_de_sangres','tipo_de_sangres.id','=','acudientes.fk_TipoSangre')
                  ->join('generos','generos.id','=','acudientes.fk_Genero')
                  ->paginate(5);       

        return \View::make('Acudiente/list',compact('acudientes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $estados = Estado::lists('NombreEstado','id');
        $tipo_documentos = TipoDocumento::lists('NombreTipoDocumento','id');
        $tipo_de_sangres = TipoDeSangre::lists('TipoDeSangre','id');
        $generos = Genero::lists('NombreGenero','id');
        return \View::make('acudiente/new',compact('estados','tipo_documentos','tipo_de_sangres','generos'));   
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
  public function store(Request $request)
    {
        //Manejar peticiones
        $acudiente = new Acudiente;
        $acudiente->IdentificacionAcudiente = $request->IdentificacionAcudiente;
        $acudiente->NombreAcudiente = $request->NombreAcudiente;
        $acudiente->DireccionAcudiente = $request->DireccionAcudiente;
        $acudiente->TelefonoFijoAcudiente = $request->TelefonoFijoAcudiente;
        $acudiente->TelefonoCelularAcudiente = $request->TelefonoCelularAcudiente;
        $acudiente->CorreoAcudiente = $request->CorreoAcudiente;
        $acudiente->fk_Genero = $request->NombreGenero;
        $acudiente->fk_Estado = $request->NombreEstado;
        $acudiente->fk_TipoDocumento = $request->NombreTipoDocumento;
        $acudiente->fk_TipoSangre = $request->TipoDeSangre;
        $acudiente->save();
        return redirect('acudiente');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $acudiente = Acudiente::find($id);  
        // Recibe el parametro id del registro a modificar
        $estados = Estado::lists('NombreEstado','id');
        $tipo_documentos = TipoDocumento::lists('NombreTipoDocumento','id');
        $tipo_de_sangres = TipoDeSangre::lists('TipoDeSangre','id');
        $generos = Genero::lists('NombreGenero','id');
        return \View::make('acudiente/update',compact('estados','asistencias','tipo_documentos','tipo_de_sangres','generos','acudiente'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function update(Request $request)
     {
         // Almacenar los cambios modificados en el registro
         $acudiente = Acudiente::find($request->id);
         $acudiente->IdentificacionAcudiente = $request->IdentificacionAcudiente;
         $acudiente->NombreAcudiente = $request->NombreAcudiente;
         $acudiente->DireccionAcudiente = $request->DireccionAcudiente;
         $acudiente->TelefonoFijoAcudiente = $request->TelefonoFijoAcudiente;
         $acudiente->TelefonoCelularAcudiente = $request->TelefonoCelularAcudiente;
         $acudiente->CorreoAcudiente = $request->CorreoAcudiente;
         $acudiente->fk_Genero = $request->NombreGenero;
         $acudiente->fk_Estado = $request->NombreEstado;
         $acudiente->fk_TipoDocumento = $request->NombreTipoDocumento;
         $acudiente->fk_TipoSangre = $request->TipoDeSangre;
         $acudiente->save();
         return redirect('acudiente');
     }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function search(Request $request)
    {
        // funcion buscar
        $acudientes = Acudiente::select('acudientes.*','estados.NombreEstado','tipo_documentos.NombreTipoDocumento','tipo_de_sangres.TipoDeSangre','generos.NombreGenero')
                  ->join('estados','estados.id','=','estudiantes.fk_Estado')
                  ->join('tipo_documentos','tipo_documentos.id','=','estudiantes.fk_TipoDocumento')
                  ->join('tipo_de_sangres','tipo_de_sangres.id','=','estudiantes.fk_TipoSangre')
                  ->join('generos','generos.id','=','estudiantes.fk_Genero')
                  ->where('NombreAcudiente','like','%'.$request->NombreAcudiente.'%')
                  ->paginate(5);       

        return \View::make('acudiente/list',compact('acudientes')); 
    }
}
