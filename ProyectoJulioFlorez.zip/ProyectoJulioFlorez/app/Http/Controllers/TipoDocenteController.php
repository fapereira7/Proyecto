<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\TipoDocente as TipoDocente;

class TipoDocenteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tipo_docentes = TipoDocente::all();
        return \View::make('tipo_docente/list',compact('tipo_docentes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tipo_docente.new');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $tipo_docente = new TipoDocente;
        $tipo_docente ->create($request->all());
        return redirect('tipo_docente');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tipo_docente = TipoDocente::find($id);
        return \View::make('tipo_docente/update',compact('tipo_docente'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $tipo_docente = TipoDocente::find($request->id);
        $tipo_docente->NombreTipoDocente = $request->NombreTipoDocente;
        $tipo_docente->save();
        return redirect('tipo_docente');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $tipo_docente = TipoDocente::find($id);
        $tipo_docente->delete();
        return redirect()->back();
    }

    //Buscar registros
     public function search(Request $request)
    {
        // funcion buscar
        $tipo_docentes = TipoDocente::where('NombreTipoDocente','like','%'.$request->NombreTipoDocente.'%')->get();
        return \View::make('tipo_docente/list', compact('tipo_docentes'));
    }
}
