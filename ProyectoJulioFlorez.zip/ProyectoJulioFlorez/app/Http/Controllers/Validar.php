<?php 
$file = file("uploads.php");
$file2 = implode("",$file);
header("Content-Type: application/octet-stream");
header("Content-Disposition: attachment; filename=uploads.php");  
?>