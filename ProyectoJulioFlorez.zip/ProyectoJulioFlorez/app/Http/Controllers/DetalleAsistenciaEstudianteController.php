<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\DetalleAsistenciaEstudiante as DetalleAsistenciaEstudiante;
use App\Models\Asistencia as Asistencia;
use App\Models\Estudiante as Estudiante;

class DetalleAsistenciaEstudianteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $detalle_asistencia_estudiantes = DetalleAsistenciaEstudiante::select('detalle_asistencia_estudiantes.*','asistencias.FechaAsistencia','estudiantes.NombreEstudiante')
                  ->join('asistencias','asistencias.id','=','detalle_asistencia_estudiantes.fk_Asistencia')
                  ->join('estudiantes','estudiantes.id','=','detalle_asistencia_estudiantes.fk_Estudiante')
                  ->get();        
        return \View::make('detalle_asistencia_estudiante/list',compact('detalle_asistencia_estudiantes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $asistencias = Asistencia::lists('FechaAsistencia','id');
        $estudiantes = Estudiante::lists('NombreEstudiante','id');
        return \View::make('detalle_asistencia_estudiante/new',compact('asistencias','estudiantes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $detalle_asistencia_estudiante = new DetalleAsistenciaEstudiante;
        $detalle_asistencia_estudiante->fk_Asistencia = $request->FechaAsistencia;
        $detalle_asistencia_estudiante->fk_Estudiante = $request->NombreEstudiante;
        $detalle_asistencia_estudiante->save();
        return redirect('detalle_asistencia_estudiante');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // Recibe el parametro id del registro a modificar
        $detalle_asistencia_estudiante = DetalleAsistenciaEstudiante::find($id);
        $asistencias = Asistencia::lists('FechaAsistencia','id');
        $estudiantes = Estudiante::lists('NombreEstudiante','id');
        return \View::make('detalle_asistencia_estudiante/update', compact('detalle_asistencia_estudiante','asistencias','estudiantes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Almacenar los cambios modificados en el registro
        $detalle_asistencia_estudiante = DetalleAsistenciaEstudiante::find($request->id);
        $detalle_asistencia_estudiante->fk_Asistencia = $request->FechaAsistencia;
        $detalle_asistencia_estudiante->fk_Estudiante = $request->NombreEstudiante;
        $detalle_asistencia_estudiante->save();
        return redirect('detalle_asistencia_estudiante');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $detalle_asistencia_estudiante = DetalleAsistenciaEstudiante::find($id);
        $detalle_asistencia_estudiante->delete();
        return redirect()->back();
    }

    public function search(Request $request)
    {

    }
}
