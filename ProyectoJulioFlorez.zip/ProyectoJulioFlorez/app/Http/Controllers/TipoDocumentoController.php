<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\TipoDocumento as TipoDocumento;

class TipoDocumentoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tipo_documentos = TipoDocumento::all();
        return \View::make('tipo_documento/list',compact('tipo_documentos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tipo_documento.new');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $tipo_documento = new TipoDocumento;
        $tipo_documento ->create($request->all());
        return redirect('tipo_documento');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tipo_documento = TipoDocumento::find($id);
        return \View::make('tipo_documento/update',compact('tipo_documento'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $tipo_documento = TipoDocumento::find($request->id);
        $tipo_documento->NombreTipoDocumento = $request->NombreTipoDocumento;
        $tipo_documento->save();
        return redirect('tipo_documento');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $tipo_documento = TipoDocumento::find($id);
        $tipo_documento->delete();
        return redirect()->back();
    }

    //Buscar registros
     public function search(Request $request)
    {
        // funcion buscar
        $tipo_documentos = TipoDocumento::where('NombreTipoDocumento','like','%'.$request->NombreTipoDocumento.'%')->get();
        return \View::make('tipo_documento/list', compact('tipo_documentos'));
    }
}
