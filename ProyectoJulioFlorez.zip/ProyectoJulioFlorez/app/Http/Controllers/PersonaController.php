<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Persona as Persona;
use App\Models\Estado as Estado;
use App\Models\TipoDocumento as TipoDocumento;
use App\Models\TipoDeSangre as TipoDeSangre;
use App\User as User;
use App\Models\Genero as Genero;

use App\Http\Requests;

class PersonaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $personas = Persona::select('personas.*','users.name','estados.NombreEstado','tipo_documentos.NombreTipoDocumento','tipo_de_sangres.TipoDeSangre','generos.NombreGenero')
                  ->join('estados','estados.id','=','personas.fk_Estado')
                  ->join('tipo_documentos','tipo_documentos.id','=','personas.fk_TipoDocumento')
                  ->join('tipo_de_sangres','tipo_de_sangres.id','=','personas.fk_TipoSangre')
                  ->join('users','users.id','=','personas.fk_Usuario')
                  ->join('generos','generos.id','=','personas.fk_Genero')
                  ->paginate(5);       

        return \View::make('persona/list',compact('personas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $users = User::lists('name','id');
        $estados = Estado::lists('NombreEstado','id');
        $tipo_documentos = TipoDocumento::lists('NombreTipoDocumento','id');
        $tipo_de_sangres = TipoDeSangre::lists('TipoDeSangre','id');
        $generos = Genero::lists('NombreGenero','id');
        return \View::make('persona/new',compact('users','estados','tipo_documentos','tipo_de_sangres','generos'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Manejar peticiones
        $persona = new Persona;
        $persona->CorreoPersona = $request->CorreoPersona;
        $persona->DireccionPersona = $request->DireccionPersona;
        $persona->fk_Genero = $request->NombreGenero;
        $persona->fk_Estado = $request->NombreEstado;
        $persona->fk_Usuario = $request->name;
        $persona->fk_TipoDocumento = $request->NombreTipoDocumento;
        $persona->fk_TipoSangre = $request->TipoDeSangre;
        $persona->IdentificacionPersona = $request->IdentificacionPersona;
        $persona->NombrePersona = $request->NombrePersona;
        $persona->TelefonoCelularPersona = $request->TelefonoCelularPersona;
        $persona->TelefonoFijoPersona = $request->TelefonoFijoPersona;
        $persona->save();
        return redirect('persona');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $persona = Persona::find($id);
        $users = User::lists('name','id'); 
        $estados = Estado::lists('NombreEstado','id');
        $tipo_documentos = TipoDocumento::lists('NombreTipoDocumento','id');
        $tipo_de_sangres = TipoDeSangre::lists('TipoDeSangre','id');
        $generos = Genero::lists('NombreGenero','id');
        return \View::make('persona/update',compact('users','estados','tipo_documentos','tipo_de_sangres','generos','persona'));
    }
    

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $persona = Persona::find($request->id);
        $persona->CorreoPersona = $request->CorreoPersona;
        $persona->DireccionPersona = $request->DireccionPersona;
        $persona->IdentificacionPersona = $request->IdentificacionPersona;
        $persona->NombrePersona = $request->NombrePersona;
        $persona->TelefonoCelularPersona = $request->TelefonoCelularPersona;
        $persona->TelefonoFijoPersona = $request->TelefonoFijoPersona;
        $persona->fk_Genero = $request->NombreGenero;
        $persona->fk_Estado = $request->NombreEstado;
        $persona->fk_Usuario = $request->name;
        $persona->fk_TipoDocumento = $request->NombreTipoDocumento;
        $persona->fk_TipoSangre = $request->TipoDeSangre;
        $persona->save();
        return redirect('persona');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function search(Request $request)
    {
        $personas = Persona::select('personas.*','users.name','estados.NombreEstado','tipo_documentos.NombreTipoDocumento','tipo_de_sangres.TipoDeSangre','generos.NombreGenero')
                  ->join('estados','estados.id','=','personas.fk_Estado')
                  ->join('tipo_documentos','tipo_documentos.id','=','personas.fk_TipoDocumento')
                  ->join('tipo_de_sangres','tipo_de_sangres.id','=','personas.fk_TipoSangre')
                  ->join('users','users.id','=','personas.fk_Usuario')
                  ->join('generos','generos.id','=','personas.fk_Genero')
                  ->where('NombrePersona','like','%'.$request->NombrePersona.'%')
                  ->paginate(5);       

        return \View::make('persona/list',compact('personas'));
    }
}
