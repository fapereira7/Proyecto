<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Estado as Estado;
use App\Models\TipoEstado as TipoEstado;

class EstadoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $estados = Estado::select('estados.*','tipo_estados.NombreTipoEstado')
                  ->join('tipo_estados','tipo_estados.id','=','estados.fk_TipoEstado')
                  ->get();        
        return \View::make('estado/list',compact('estados'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tipo_estados = TipoEstado::lists('NombreTipoEstado','id');
        return \View::make('estado/new',compact('tipo_estados'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $estado = new Estado;
        $estado->NombreEstado = $request->NombreEstado;
        $estado->fk_TipoEstado = $request->NombreTipoEstado;
        $estado->save();
        return redirect('estado');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // Recibe el parametro id del registro a modificar
        $estado = Estado::find($id);
        $tipo_estados = TipoEstado::lists('NombreTipoEstado','id');
        return \View::make('estado/update', compact('estado','tipo_estados'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Almacenar los cambios modificados en el registro
        $estado = Estado::find($request->id);
        $estado->NombreEstado = $request->NombreEstado;
        $estado->fk_TipoEstado = $request->NombreTipoEstado;
        $estado->save();
        return redirect('estado');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $estado = Estado::find($id);
        $estado->delete();
        return redirect()->back();
    }

    public function search(Request $request)
    {
        $estados = Estado::select('estados.*','tipo_estados.NombreTipoEstado')
                  ->join('tipo_estados','tipo_estados.id','=','estados.fk_TipoEstado')
                  ->where('NombreEstado','like','%'.$request->NombreEstado.'%')
                  ->get();   
        return \View::make('estado/list', compact('estados'));
    }
}
