<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Estado as Estado;
use App\Models\TipoDocumento as TipoDocumento;
use App\Models\TipoDeSangre as TipoDeSangre;
use App\Models\TipoDocente as TipoDocente;
use App\Models\Docente as Docente;

class DocenteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $docentes = Docente::select('docentes.*','estados.NombreEstado','tipo_documentos.NombreTipoDocumento','tipo_de_sangres.TipoDeSangre','tipo_docentes.NombreTipoDocente')
                  ->join('estados','estados.id','=','docentes.fk_Estado')
                  ->join('tipo_documentos','tipo_documentos.id','=','docentes.fk_TipoDocumento')
                  ->join('tipo_de_sangres','tipo_de_sangres.id','=','docentes.fk_TipoDeSangre')
                  ->join('tipo_docentes','tipo_docentes.id','=','docentes.fk_TipoDocente')
                  ->paginate(5);        
        return \View::make('docente/list',compact('docentes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $estados = Estado::lists('NombreEstado','id');
        $tipo_documentos = TipoDocumento::lists('NombreTipoDocumento','id');
        $tipo_de_sangres = TipoDeSangre::lists('TipoDeSangre','id');
        $tipo_docentes = TipoDocente::lists('NombreTipoDocente','id');
        return \View::make('docente/new',compact('estados','tipo_documentos','tipo_de_sangres','tipo_docentes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
  public function store(Request $request)
    {
        $docente = new Docente;
        $docente->IdentificacionDocente = $request->IdentificacionDocente;
        $docente->NombreDocente = $request->NombreDocente;
        $docente->DireccionDocente = $request->DireccionDocente;
        $docente->TelefonoFijoDocente = $request->TelefonoFijoDocente;
        $docente->TelefonoCelularDocente = $request->TelefonoCelularDocente;
        $docente->CorreoDocente = $request->CorreoDocente;
        $docente->fk_TipoDeSangre = $request->TipoDeSangre;
        $docente->fk_Estado = $request->NombreEstado;
        $docente->fk_TipoDocente = $request->NombreTipoDocente;
        $docente->fk_TipoDocumento = $request->NombreTipoDocumento;
        $docente->save();
        return redirect('docente');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // Recibe el parametro id del registro a modificar
        $docente = Docente::find($id);
        $estados = Estado::lists('NombreEstado','id');
        $tipo_documentos = TipoDocumento::lists('NombreTipoDocumento','id');
        $tipo_de_sangres = TipoDeSangre::lists('TipoDeSangre','id');
        $tipo_docentes = TipoDocente::lists('NombreTipoDocente','id');
        return \View::make('docente/update', compact('estados','tipo_documentos','tipo_de_sangres','tipo_docentes','docente'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Almacenar los cambios modificados en el registro
        $docente = Docente::find($request->id);
        $docente->IdentificacionDocente = $request->IdentificacionDocente;
        $docente->NombreDocente = $request->NombreDocente;
        $docente->DireccionDocente = $request->DireccionDocente;
        $docente->TelefonoFijoDocente = $request->TelefonoFijoDocente;
        $docente->TelefonoCelularDocente = $request->TelefonoCelularDocente;
        $docente->CorreoDocente = $request->CorreoDocente;
        $docente->fk_TipoDeSangre = $request->TipoDeSangre;
        $docente->fk_Estado = $request->NombreEstado;
        $docente->fk_TipoDocente = $request->NombreTipoDocente;
        $docente->fk_TipoDocumento = $request->NombreTipoDocumento;
        $docente->save();
        return redirect('docente');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $docente = Docente::find($id);
        $docente->delete();
        return redirect()->back();
    }

    public function search(Request $request)
    {
        // funcion buscar
        $docentes = Docente::where('NombreDocente','like','%'.$request->NombreDocente.'%')->get();
        return \View::make('docente/list', compact('docentes'));
    }
}
