<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Models\TipoUsuario as TipoUsuario;

class TipoUsuarioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tipo_usuarios = TipoUsuario::all();
        return \View::make('tipo_usuario/list',compact('tipo_usuarios'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tipo_usuario.new');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $tipo_usuario = new TipoUsuario;
        $tipo_usuario ->create($request->all());
        return redirect('tipo_usuario');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tipo_usuario = TipoUsuario::find($id);
        return \View::make('tipo_usuario/update',compact('tipo_usuario'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $tipo_usuario = TipoUsuario::find($request->id);
        $tipo_usuario->NombreTipoUsuario = $request->NombreTipoUsuario;
        $tipo_usuario->save();
        return redirect('tipo_usuario');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $tipo_usuario = TipoUsuario::find($id);
        $tipo_usuario->delete();
        return redirect()->back();
    }

    //Buscar registros
     public function search(Request $request)
    {
        // funcion buscar
        $tipo_usuarios = TipoUsuario::where('NombreTipoUsuario','like','%'.$request->NombreTipoUsuario.'%')->get();
        return \View::make('tipo_usuario/list', compact('tipo_usuarios'));
    }
}
