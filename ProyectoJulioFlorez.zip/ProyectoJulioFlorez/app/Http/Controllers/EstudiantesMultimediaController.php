<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Estudiante as Estudiante;
use App\Models\Estado as Estado;
use App\Models\TipoDocumento as TipoDocumento;
use App\Models\TipoDeSangre as TipoDeSangre;
use App\Models\Ficha as Ficha;
use App\Models\Genero as Genero;

class EstudiantesMultimediaController extends Controller
{
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $estudiantes = Estudiante::select('estudiantes.*','fichas.NumeroFicha','estados.NombreEstado','tipo_documentos.NombreTipoDocumento','tipo_de_sangres.TipoDeSangre','generos.NombreGenero')
                  ->join('estados','estados.id','=','estudiantes.fk_Estado')
                  ->join('tipo_documentos','tipo_documentos.id','=','estudiantes.fk_TipoDocumento')
                  ->join('tipo_de_sangres','tipo_de_sangres.id','=','estudiantes.fk_TipoSangre')
                  ->join('fichas','fichas.id','=','estudiantes.fk_Ficha')
                  ->join('generos','generos.id','=','estudiantes.fk_Genero')
                  ->join('especialidads','fichas.fk_especialidad','=','especialidads.id')
                  ->where('especialidads.nombreespecialidad','=','Diseño integral multimedia')
                  ->paginate(5);       

        return \View::make('Multimedia/list',compact('estudiantes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $fichas = Ficha::lists('NumeroFicha','id');
        $estados = Estado::lists('NombreEstado','id');
        $tipo_documentos = TipoDocumento::lists('NombreTipoDocumento','id');
        $tipo_de_sangres = TipoDeSangre::lists('TipoDeSangre','id');
        $generos = Genero::lists('NombreGenero','id');
        return \View::make('Multimedia/new',compact('fichas','estados','tipo_documentos','tipo_de_sangres','generos'));   
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
  public function store(Request $request)
    {
        //Manejar peticiones
        $estudiante = new Estudiante;
        $estudiante->CorreoEstudiante = $request->CorreoEstudiante;
        $estudiante->DireccionEstudiante = $request->DireccionEstudiante;
        $estudiante->fk_Genero = $request->NombreGenero;
        $estudiante->fk_Estado = $request->NombreEstado;
        $estudiante->fk_Ficha = $request->NumeroFicha;
        $estudiante->fk_TipoDocumento = $request->NombreTipoDocumento;
        $estudiante->fk_TipoSangre = $request->TipoDeSangre;
        $estudiante->IdentificacionEstudiante = $request->IdentificacionEstudiante;
        $estudiante->NombreEstudiante = $request->NombreEstudiante;
        $estudiante->TelefonoCelularEstudiante = $request->TelefonoCelularEstudiante;
        $estudiante->TelefonoFijoEstudiante = $request->TelefonoFijoEstudiante;
        $estudiante->save();
        return redirect('estudiante');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $estudiante = Estudiante::find($id);  
        // Recibe el parametro id del registro a modificar
        $fichas = Ficha::lists('NumeroFicha','id');
        $estados = Estado::lists('NombreEstado','id');
        $tipo_documentos = TipoDocumento::lists('NombreTipoDocumento','id');
        $tipo_de_sangres = TipoDeSangre::lists('TipoDeSangre','id');
        $generos = Genero::lists('NombreGenero','id');
        return \View::make('Multimedia/update',compact('fichas','estados','asistencias','tipo_documentos','tipo_de_sangres','generos','estudiante'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function update(Request $request)
     {
         // Almacenar los cambios modificados en el registro
         $estudiante = Estudiante::find($request->id);
         $estudiante->IdentificacionEstudiante = $request->IdentificacionEstudiante;
         $estudiante->NombreEstudiante = $request->NombreEstudiante;
         $estudiante->DireccionEstudiante = $request->DireccionEstudiante;
         $estudiante->TelefonoFijoEstudiante = $request->TelefonoFijoEstudiante;
         $estudiante->TelefonoCelularEstudiante = $request->TelefonoCelularEstudiante;
         $estudiante->CorreoEstudiante = $request->CorreoEstudiante;
         $estudiante->fk_TipoDocumento = $request->NombreTipoDocumento;
         $estudiante->fk_TipoSangre = $request->TipoDeSangre;
         $estudiante->fk_Ficha = $request->NumeroFicha;
         $estudiante->fk_Genero = $request->NombreGenero;
         $estudiante->fk_Estado = $request->NombreEstado;
         $estudiante->save();
         return redirect('estudiante');
     }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $estudiante = Estudiante::find($id);
        $estudiante->delete();
        return redirect()->back();
    }


    public function search(Request $request)
    {
        // funcion buscar
        $estudiantes = Estudiante::select('estudiantes.*','fichas.NumeroFicha','estados.NombreEstado','tipo_documentos.NombreTipoDocumento','tipo_de_sangres.TipoDeSangre','generos.NombreGenero')
                  ->join('estados','estados.id','=','estudiantes.fk_Estado')
                  ->join('tipo_documentos','tipo_documentos.id','=','estudiantes.fk_TipoDocumento')
                  ->join('tipo_de_sangres','tipo_de_sangres.id','=','estudiantes.fk_TipoSangre')
                  ->join('fichas','fichas.id','=','estudiantes.fk_Ficha')
                  ->join('generos','generos.id','=','estudiantes.fk_Genero')
                  ->where('NombreEstudiante','like','%'.$request->NombreEstudiante.'%')
                  ->paginate(5);       

        return \View::make('Multimedia/list',compact('estudiantes')); 
    }
}