<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\DetalleAsistenteAsistencia as DetalleAsistenteAsistencia;
use App\Models\Asistente as Asistente;
use App\Models\Asistencia as Asistencia;

class DetalleAsistenteAsistenciaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $detalle_asistente_asistencias = DetalleAsistenteAsistencia::select('detalle_asistente_asistencias.*','asistentes.NombreAsistente','asistencias.FechaAsistencia')
                  ->join('asistentes','asistentes.id','=','detalle_asistente_asistencias.fk_Asistente')
                  ->join('asistencias','asistencias.id','=','detalle_asistente_asistencias.fk_Asistencia')
                  ->get();        
        return \View::make('detalle_asistente_asistencia/list',compact('detalle_asistente_asistencias'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $asistentes = Asistente::lists('NombreAsistente','id');
        $asistencias = Asistencia::lists('FechaAsistencia','id');
        return \View::make('detalle_asistente_asistencia/new',compact('asistentes','asistencias'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $detalle_asistente_asistencia = new DetalleAsistenteAsistencia;
        $detalle_asistente_asistencia->fk_Asistente = $request->NombreAsistente;
        $detalle_asistente_asistencia->fk_Asistencia = $request->FechaAsistencia;
        $detalle_asistente_asistencia->save();
        return redirect('detalle_asistente_asistencia');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // Recibe el parametro id del registro a modificar
        $detalle_asistente_asistencia = DetalleAsistenteAsistencia::find($id);
        $asistentes = Asistente::lists('NombreAsistente','id');
        $asistencias = Asistencia::lists('FechaAsistencia','id');
        return \View::make('detalle_asistente_asistencia/update', compact('detalle_asistente_asistencia','asistentes','asistencias'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Almacenar los cambios modificados en el registro
        $detalle_asistente_asistencia = DetalleAsistenteAsistencia::find($request->id);
        $detalle_asistente_asistencia->fk_Asistente = $request->NombreAsistente;
        $detalle_asistente_asistencia->fk_Asistencia = $request->FechaAsistencia;
        $detalle_asistente_asistencia->save();
        return redirect('detalle_asistente_asistencia');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $detalle_asistente_asistencia = DetalleAsistenteAsistencia::find($id);
        $detalle_asistente_asistencia->delete();
        return redirect()->back();
    }

    public function search(Request $request)
    {
    
    }
}
