<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Especialidad as Especialidad;
use App\Models\TipoEspecialidad as TipoEspecialidad;
use App\Models\Estado as Estado;

use Illuminate\Support\Collection as Collection;

class EspecialidadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $especialidads = Especialidad::select('especialidads.*','tipo_especialidads.NombreTipoEspecialidad','estados.NombreEstado')
                  ->join('tipo_especialidads','tipo_especialidads.id','=','especialidads.fk_TipoEspecialidad')
                  ->join('estados','estados.id','=','especialidads.fk_Estado')
                  ->paginate(5);         
        return \View::make('especialidad/list',compact('especialidads'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tipo_especialidads = TipoEspecialidad::lists('NombreTipoEspecialidad','id');
        $estados = Estado::lists('NombreEstado','id');
        return \View::make('especialidad/new',compact('tipo_especialidads','estados'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Manejar peticiones
        $especialidad = new Especialidad;
        $especialidad->NombreEspecialidad = $request->NombreEspecialidad;
        $especialidad->fk_TipoEspecialidad = $request->NombreTipoEspecialidad;
        $especialidad->fk_Estado = $request->NombreEstado;
        $especialidad->save();
        return redirect('especialidad');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $especialidad = Especialidad::find($id);  
        // Recibe el parametro id del registro a modificar
        $tipo_especialidads = TipoEspecialidad::lists('NombreTipoEspecialidad','id');
        $estados = Estado::lists('NombreEstado','id');
        return \View::make('especialidad/update',compact('tipo_especialidads','estados','especialidad'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function update(Request $request)
     {
         // Almacenar los cambios modificados en el registro
         $especialidad = Especialidad::find($request->id);
         $especialidad->NombreEspecialidad = $request->NombreEspecialidad;
         $especialidad->fk_TipoEspecialidad = $request->NombreTipoEspecialidad;
         $especialidad->fk_Estado = $request->NombreEstado;
         $especialidad->save();
         return redirect('especialidad');
     }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $especialidad = Especialidad::find($id);
        $especialidad->delete();
        return redirect()->back();
    }


    public function search(Request $request)
    {
        $especialidads = Especialidad::select('especialidads.*','tipo_especialidads.NombreTipoEspecialidad','estados.NombreEstado')
                  ->join('tipo_especialidads','tipo_especialidads.id','=','especialidads.fk_TipoEspecialidad')
                  ->join('estados','estados.id','=','especialidads.fk_Estado')
                  ->where('NombreEspecialidad','like','%'.$request->NombreEspecialidad.'%')->paginate(5); 
        return \View::make('especialidad/list', compact('especialidads'));
    }

    public function invoice(Request $request) 
    {
        $array = \DB::select(\DB::raw('select * from espinasistencia'));
        $especialidads = Collection::make($array);

        $array1 = \DB::select(\DB::raw('select * from estespecialidad'));
        $especialidads1 = Collection::make($array1);

        $array2 = \DB::select(\DB::raw('select * from docentefichas'));
        $especialidads2 = Collection::make($array2);

        $date = date('Y-m-d');
   
        $view =  \View::make('reportes/ReporteR2', compact('especialidads','especialidads1','especialidads2', 'date'))->render();
        $pdf = \App::make('dompdf.wrapper');        
        $pdf->loadHTML($view);
        return $pdf->stream('reportes/ReporteR2.pdf'); 
    }
}
