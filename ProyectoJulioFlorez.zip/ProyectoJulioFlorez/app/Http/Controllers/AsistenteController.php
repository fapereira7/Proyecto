<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Asistente as Asistente;

use App\Models\TipoDocumento as TipoDocumento;
use App\Models\TipoDeSangre as TipoDeSangre;
use App\Models\Estado as Estado;

class AsistenteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $asistentes = Asistente::select('asistentes.*','tipo_documentos.NombreTipoDocumento','tipo_de_sangres.TipoDeSangre','estados.NombreEstado')
                  ->join('tipo_documentos','tipo_documentos.id','=','asistentes.fk_TipoDocumento')
                  ->join('tipo_de_sangres','tipo_de_sangres.id','=','asistentes.fk_TipoSangre')
                  ->join('estados','estados.id','=','asistentes.fk_Estado')
                  ->get();        
        return \View::make('asistente/list',compact('asistentes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tipo_documentos = TipoDocumento::lists('NombreTipoDocumento','id');
        $tipo_de_sangres = TipoDeSangre::lists('TipoDeSangre','id');
        $estados = Estado::lists('NombreEstado','id');
        return \View::make('asistente/new',compact('tipo_documentos','tipo_de_sangres','estados'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Manejar peticiones
        $asistente = new Asistente;
        $asistente->IdentificacionAsistente = $request->IdentificacionAsistente;
        $asistente->NombreAsistente = $request->NombreAsistente;
        $asistente->DireccionAsistente = $request->DireccionAsistente;
        $asistente->TelefonoFijoAsistente = $request->TelefonoFijoAsistente;
        $asistente->TelefonoCelularAsistente = $request->TelefonoCelularAsistente;
        $asistente->CorreoAsistente = $request->CorreoAsistente;
        $asistente->fk_TipoDocumento = $request->NombreTipoDocumento;
        $asistente->fk_TipoSangre = $request->TipoDeSangre;
        $asistente->fk_Estado = $request->NombreEstado;
        $asistente->save();
        return redirect('asistente');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $asistente = Asistente::find($id);  
        // Recibe el parametro id del registro a modificar
        $tipo_documentos = TipoDocumento::lists('NombreTipoDocumento','id');
        $estados = Estado::lists('NombreEstado','id');
        $tipo_de_sangres = TipoDeSangre::lists('TipoDeSangre','id');
        return \View::make('asistente/update',compact('tipo_documentos','estados','asistente','tipo_de_sangres'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Almacenar los cambios modificados en el registro
        $asistente = Asistente::find($request->id);
        $asistente->IdentificacionAsistente = $request->IdentificacionAsistente;
        $asistente->NombreAsistente = $request->NombreAsistente;
        $asistente->DireccionAsistente = $request->DireccionAsistente;
        $asistente->TelefonoFijoAsistente = $request->TelefonoFijoAsistente;
        $asistente->TelefonoCelularAsistente = $request->TelefonoCelularAsistente;
        $asistente->CorreoAsistente = $request->CorreoAsistente;
        $asistente->fk_TipoDocumento = $request->NombreTipoDocumento;
        $asistente->fk_TipoSangre = $request->TipoDeSangre;
        $asistente->fk_Estado = $request->NombreEstado;
        $asistente->save();
        return redirect('asistente');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $asistente = Asistente::find($id);
        $asistente->delete();
        return redirect()->back();
    }


    public function search(Request $request)
    {
        // funcion buscar
        $tipo_documentos = TipoDocumento::lists('NombreTipoDocumento','id');
        $estados = Estado::lists('NombreEstado','id');
        $tipo_de_sangres = TipoDeSangre::lists('TipoDeSangre','id');
        $asistentes = Asistente::where('NombreAsistente','like','%'.$request->NombreAsistente.'%')->get();
        return \View::make('asistente/list', compact('tipo_documentos','estados','asistentes','tipo_de_sangres'));
    }
}
