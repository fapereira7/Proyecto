<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Controller;

use App\Http\Requests;

use App\Models\Formato as Formato;
use App\Models\TipoFormato as TipoFormato;
use App\Models\Estado as Estado;
use App\Models\estudiante as Estudiante;

class FormatoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function index()
    {
        //index del controlador
        $formatos = Formato::select('formatos.*','tipo_formatos.NombreTipoFormato','estados.NombreEstado','estudiantes.NombreEstudiante')
                  ->join('tipo_formatos','tipo_formatos.id','=','formatos.fk_TipoFormato')
                  ->join('estudiantes','estudiantes.id','=','formatos.fk_Estudiante')
                  ->join('estados','estados.id','=','formatos.fk_Estado')
                  ->paginate(5);        
        return \View::make('formato/list',compact('formatos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tipo_formatos = TipoFormato::lists('NombreTipoFormato','id');
        $estados = Estado::lists('NombreEstado','id');
        $estudiantes = Estudiante::lists('NombreEstudiante','id');
        return \View::make('formato/new',compact('tipo_formatos','estados','estudiantes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $data)
    {
        $validation = Validator::make($data->all(), array(
            'IdentificacionFormato' => '',
            'FechaFormato' => '',
            'Descripcion' => '',
            'UrlFormato' => '',
            'fk_TipoFormato' => '',
            'fk_Estado' => '',  
            'fk_Estudiante' => '',           
            ));
             if ($validation->fails())
            {
                return Redirect::to('formato/create')->WithErrors($validation);            
            }else
            {
                $Archivos = $data->file('UrlFormato');
                $upload = 'uploads/formatos';
                $filename = $Archivos->getClientOriginalName();
                $success = $Archivos->move($upload, $filename);

                if ($success)
                {
                    //Manejar peticiones
                    $formato = new Formato;
                    $formato->NumeroFormato = $data->Input('NumeroFormato');
                    $formato->DescripcionFormato = $data->Input('DescripcionFormato');
                    $formato->UrlFormato = $filename;
                    $formato->fk_TipoFormato = $data->Input('NombreTipoFormato');
                    $formato->fk_Estado = $data->Input('NombreEstado');
                    $formato->fk_Estudiante = $data->Input('NombreEstudiante');
                    $formato->save();
                    //print_r($table);exit();
                    return Redirect::to('formato')->with('success', 'Datos Subidos');
                }
            }
    }
    public function download($id)
    {
            $formatos = Formato::select('formatos.*')
                ->where('formatos.id','=',$id)
                ->get();
            foreach ($formatos as $formato) {
                $NombreArchivo = $formato->UrlFormato;
            }
            //dd($NombreArchivo);
            $public_path = public_path();
            $url = $public_path.'/uploads/formatos/'.$NombreArchivo;
            //verificamos si el archivo existe y lo retornamos
            //if (Storage::exists($NombreArchivo))
            //{
                return response()->download($url);
            //} else
            //{//si no se encuentra lanzamos un error 404.
                abort(404);
                //echo "Error 404:El archivo no se encuentra, intentelo nuevamente";
            //}
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $formato = Formato::find($id);  
        // Recibe el parametro id del registro a modificar
        $tipo_formatos = TipoFormato::lists('NombreTipoFormato','id');
        $estudiantes = Estudiante::lists('NombreEstudiante','id');
        $estados = Estado::lists('NombreEstado','id');
        return \View::make('formato/update',compact('tipo_formatos','formato','estados','estudiantes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function update(Request $request)
     {
         // Almacenar los cambios modificados en el registro
         $formato = Formato::find($request->id);
         $formato->NumeroFormato = $request->NumeroFormato;
         $formato->DescripcionFormato = $request->DescripcionFormato;
         $formato->UrlFormato = $request->UrlFormato;
         $formato->fk_TipoFormato = $request->NombreTipoFormato;
         $formato->fk_Estado = $request->NombreEstado;
         $formato->fk_Estudiante = $request->NombreEstudiante;
         $formato->save();
         return redirect('formato');
     }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
    }


    public function search(Request $request)
    {
        $formatos = Formato::select('formatos.*','tipo_formatos.NombreTipoFormato','estados.NombreEstado','estudiantes.NombreEstudiantes')
                  ->join('tipo_formatos','tipo_formatos.id','=','formatos.fk_TipoFormato')
                  ->join('estados','estados.id','=','formatos.fk_Estado')
                  ->join('estudiantes','estudiantes.id','=','formatos.fk_Estudiante')
                  ->where('IdentificacionFormato','like','%'.$request->IdentificacionFormato.'%')
                  ->paginate(5);   
        return \View::make('formato/list', compact('formatos'));
    }
}
