<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Models\TipoEstado as TipoEstado;
use App\Models\Estado as Estado;

class TipoEstadoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tipo_estados = TipoEstado::all();
        return \View::make('tipo_estado/list',compact('tipo_estados'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tipo_estado.new');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $tipo_estado = new TipoEstado;
        $tipo_estado ->create($request->all());
        return redirect('tipo_estado');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tipo_estado = TipoEstado::find($id);
        return \View::make('tipo_estado/update',compact('tipo_estado'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $tipo_estado = TipoEstado::find($request->id);
        $tipo_estado->NombreTipoEstado = $request->NombreTipoEstado;
        $tipo_estado->save();
        return redirect('tipo_estado');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $tipo_estado = TipoEstado::find($id);
        $tipo_estado->delete();
        return redirect()->back();
    }

    //Buscar registros
     public function search(Request $request)
    {
        // funcion buscar
        $tipo_estados = TipoEstado::where('NombreTipoEstado','like','%'.$request->NombreTipoEstado.'%')->get();
        return \View::make('tipo_estado/list', compact('tipo_estados'));
    }


    public function combo(Request $request) 
    {
        try
        {
        //dd($request->fk_TipoEstado);
        $estados = Estado::select('estados.id','estados.NombreEstado')
        ->join('tipo_estados', 'tipo_estados.id', '=', 'estados.fk_TipoEstado')
        ->where('tipo_estados.id','=', $request->Id_Tipo_Estado)
        ->get();
        $tipo_estados = TipoEstado::select('tipo_estados.id','tipo_estados.NombreTipoEstado')->get();
        if ($request->ajax()) {
            return response()->json(\View::make('tipo_estado/combo', compact('tipo_estados', 'estados'))->render());
        }
            return \View::make('tipo_estado/combo', compact('tipo_estados', 'estados'));  
        } catch (Exception $e) {
            Session::flash('message', 'Error'.$e->getMesssage());
        }
    }
}
