<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Estudiante as Estudiante;
use App\Models\TipoFormato as TipoFormato;
use App\Models\Estado as Estado;
use App\Models\Asistencia as Asistencia;
use App\Models\Ficha as Ficha;
use App\Models\Genero as Genero;


class HistorialEstudianteController extends Controller
{
  public function search(Request $request)
    {
    	$estudiantes = Estudiante::select ('estudiantes.NombreEstudiante','formatos.DescripcionFormato','tipo_formatos.NombreTipoFormato', 'estados.NombreEstado')->count('asistencias.FechaAsistencia')
    		->join('fichas','on','fichas.id','=','estudiantes.fk_Ficha') 
    		->join('especialidads','on','especialidads.id','=','fichas.fk_Ficha')
    	    ->join('asistencias','on','asistencia.fk_Estudiante','=','estudiantes.id')
    	    ->join('estados','on','estado.id','=','asistencia.fk_idestado') 
    	    ->join('detalle_formato_estudiantes','on','detalle_formato_estudiantes.fk_Estudiante','=','estudiantes.id')
    	    ->join('formatos','on','detalle_formato_estudiantes.fk_idformato','=','formatos.id')
    	    ->join('tipoformatos','on','tipoformato.id','=','formatos.fk_id') 
    	    ->where('estudiantes.identificacionestudiante','like','%'.$request->IdentificacionEstudiante.'%')
    	    ->and('estados.idestado','=','4')
    	    ->get();  

        return \View::make('reportes/HistorialEstudiante',compact('estudiantes')); 
    }
}
