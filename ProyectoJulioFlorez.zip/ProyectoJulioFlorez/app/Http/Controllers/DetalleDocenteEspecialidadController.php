<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\DetalleDocenteEspecialidad as DetalleDocenteEspecialidad;
use App\Models\Docente as Docente;
use App\Models\Especialidad as Especialidad;

class DetalleDocenteEspecialidadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index del controlador
        $detalle_docente_especialidads = DetalleDocenteEspecialidad::select('detalle_docente_especialidads.*','docentes.NombreDocente','especialidads.NombreEspecialidad')
                  ->join('docentes','docentes.id','=','detalle_docente_especialidads.fk_Docente')
                  ->join('especialidads','especialidads.id','=','detalle_docente_especialidads.fk_Especialidad')
                  ->get();        
        return \View::make('detalle_docente_especialidad/list',compact('detalle_docente_especialidads'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $docentes = Docente::lists('NombreDocente','id');
        $especialidads = Especialidad::lists('NombreEspecialidad','id');
        return \View::make('detalle_docente_especialidad/new',compact('docentes','especialidads'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $detalle_docente_especialidad = new DetalleDocenteEspecialidad;
        $detalle_docente_especialidad->DescripcionDetalleDE = $request->DescripcionDetalleDE;
        $detalle_docente_especialidad->fk_Docente = $request->NombreDocente;
        $detalle_docente_especialidad->fk_Especialidad = $request->NombreEspecialidad;
        $detalle_docente_especialidad->save();
        return redirect('detalle_docente_especialidad');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // Recibe el parametro id del registro a modificar
        $detalle_docente_especialidad = DetalleDocenteEspecialidad::find($id);
        $docentes = Docente::lists('NombreDocente','id');
        $especialidads = Especialidad::lists('NombreEspecialidad','id');
        return \View::make('detalle_docente_especialidad/update', compact('docentes','especialidads','detalle_docente_especialidad'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Almacenar los cambios modificados en el registro
        $detalle_docente_especialidad = DetalleDocenteEspecialidad::find($request->id);
        $detalle_docente_especialidad->DescripcionDetalleDE = $request->DescripcionDetalleDE;
        $detalle_docente_especialidad->fk_Docente = $request->NombreDocente;
        $detalle_docente_especialidad->fk_Especialidad = $request->NombreEspecialidad;
        $detalle_docente_especialidad->save();
        return redirect('detalle_docente_especialidad');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $detalle_docente_especialidad = DetalleDocenteEspecialidad::find($id);
        $detalle_docente_especialidad->delete();
        return redirect()->back();
    }

    public function search(Request $request)
    {
        // funcion buscar
        $detalle_docente_especialidads = DetalleDocenteEspecialidad::where('DescripcionDetalleDE','like','%'.$request->DescripcionDetalleDE.'%')->get();
        return \View::make('detalle_docente_especialidad/list', compact('detalle_docente_especialidads'));
    }
}
