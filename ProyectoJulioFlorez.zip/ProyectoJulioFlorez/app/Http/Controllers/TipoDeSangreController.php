<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\TipoDeSangre as TipoDeSangre;

class TipoDeSangreController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tipo_de_sangres = TipoDeSangre::all();
        return \View::make('tipo_de_sangre/list',compact('tipo_de_sangres'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tipo_de_sangre.new');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $tipo_de_sangre = new TipoDeSangre;
        $tipo_de_sangre ->create($request->all());
        return redirect('tipo_de_sangre');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tipo_de_sangre = TipoDeSangre::find($id);
        return \View::make('tipo_de_sangre/update',compact('tipo_de_sangre'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $tipo_de_sangre = TipoDeSangre::find($request->id);
        $tipo_de_sangre->TipoDeSangre = $request->TipoDeSangre;
        $tipo_de_sangre->save();
        return redirect('tipo_de_sangre');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Eliminar registros
        $tipo_de_sangre = TipoDeSangre::find($id);
        $tipo_de_sangre->delete();
        return redirect()->back();
    }

    //Buscar registros
     public function search(Request $request)
    {
        // funcion buscar
        $tipo_de_sangres = TipoDeSangre::where('TipoDeSangre','like','%'.$request->TipoDeSangre.'%')->get();
        return \View::make('tipo_de_sangre/list', compact('tipo_de_sangres'));
    }
}
