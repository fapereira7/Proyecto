<?php nemespace Subir archvos;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
class Movie extends Model 
{
	protected $table = "acta";

	protected $formatos= array('.jpg','png','doc','pdf','docx');
	public function setpdfAttribute($path)
	{
		$this->attributes['path'] = Carbon::now()->second.$path->getClientOriginalname();
		$name = Carbon::now()->second.$path->getClientOriginalname();
		\Storage::disk('local')->put($name, \File::get($path));
	}
}