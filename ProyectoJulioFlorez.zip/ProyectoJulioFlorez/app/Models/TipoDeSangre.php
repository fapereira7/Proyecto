<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TipoDeSangre extends Model
{
    protected $table = 'tipo_de_sangres';
    protected $fillable = ['TipoDeSangre'];
    protected $guarded = ['id'];
}
