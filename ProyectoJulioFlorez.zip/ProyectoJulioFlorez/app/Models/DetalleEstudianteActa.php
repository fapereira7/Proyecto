<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DetalleEstudianteActa extends Model
{
    protected $table = 'detalle_estudiante_actas';
    protected $fillable = ['DescripcionDetalleEA','fk_Acta','fk_Estudiante'];
    protected $guarded = ['id'];
}
