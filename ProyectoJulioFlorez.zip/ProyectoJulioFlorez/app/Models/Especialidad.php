<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Especialidad extends Model
{
    protected $table = 'especialidads';
    protected $fillable = ['NombreEspecialidad','fk_TipoEspecialidad','fk_Estado'];
    protected $guarded = ['id'];
}
