<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DetallePersonaFicha extends Model
{
    protected $table = 'detalle_persona_fichas';
    protected $fillable = ['fk_Persona','fk_Ficha'];
    protected $guarded = ['id'];
}
