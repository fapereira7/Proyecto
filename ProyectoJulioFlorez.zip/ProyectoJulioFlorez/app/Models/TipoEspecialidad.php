<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TipoEspecialidad extends Model
{
    protected $table = 'tipo_especialidads';
    protected $fillable = ['NombreTipoEspecialidad'];
    protected $guarded = ['id'];
}
