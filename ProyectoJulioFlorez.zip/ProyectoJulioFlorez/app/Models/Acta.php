<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Acta extends Model
{
    protected $table = 'actas';
    protected $fillable = ['IdentificacionActa','FechaHoraActa','Descripcion','UrlActa','fk_TipoActa','fk_Estado'];
    protected $guarded = ['id'];

}
