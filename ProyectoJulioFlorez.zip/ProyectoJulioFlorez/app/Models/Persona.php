<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Persona extends Model
{
    protected $table = 'personas';
    protected $fillable = ['IdentificacionPersona','NombrePersona','DireccionPersona','TelefonoFijoPersona','TelefonoCelularPersona','CorreoPersona','fk_Estado','fk_TipoDocumento','fk_TipoSangre','fk_Usuario','fk_Genero'];
    protected $guarded = ['id'];
}
