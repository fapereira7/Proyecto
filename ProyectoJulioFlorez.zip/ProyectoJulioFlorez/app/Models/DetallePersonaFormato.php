<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DetallePersonaFormato extends Model
{
    protected $table = 'detalle_persona_formatos';
    protected $fillable = ['fk_Persona','fk_Formato'];
    protected $guarded = ['id'];
}
