<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DetalleEstudianteAcudiente extends Model
{
    protected $table = 'detalle_estudiante_acudientes';
    protected $fillable = ['parentesco','fk_Estudiante','fk_Acudiente'];
    protected $guarded = ['id'];
}
