<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EstudiantesProgramacion extends Model
{
    protected $table = 'VistaEstudianteProgramacion';
    protected $fillable = ['IdentificacionEstudiante','NombreEstudiante','DireccionEstudiante','TelefonoFijoEstudiante','TelefonoCelularEstudiante','CorreoEstudiante','fk_Estado','fk_TipoDocumento','fk_TipoSangre','fk_Ficha','fk_Genero'];
    protected $guarded = ['id'];
}
