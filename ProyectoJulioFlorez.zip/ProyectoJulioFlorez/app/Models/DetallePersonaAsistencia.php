<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DetallePersonaAsistencia extends Model
{
    protected $table = 'detalle_persona_asistencias';
    protected $fillable = ['fk_Persona','fk_Asistencia'];
    protected $guarded = ['id'];
}
