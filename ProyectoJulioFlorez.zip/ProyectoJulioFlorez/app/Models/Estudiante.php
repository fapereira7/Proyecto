<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Estudiante extends Model
{
    protected $table = 'estudiantes';
    protected $fillable = ['IdentificacionEstudiante','NombreEstudiante','DireccionEstudiante','TelefonoFijoEstudiante','TelefonoCelularEstudiante','CorreoEstudiante','fk_Estado','fk_TipoDocumento','fk_TipoSangre','fk_Ficha','fk_Genero'];
    protected $guarded = ['id'];
}
