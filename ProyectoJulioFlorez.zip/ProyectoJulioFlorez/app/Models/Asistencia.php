<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Asistencia extends Model
{
    protected $table = 'asistencias';
    protected $fillable = ['FechaAsistencia','fk_Estado','fk_Estudiante','fk_Ficha'];
    protected $guarded = ['id'];
}
