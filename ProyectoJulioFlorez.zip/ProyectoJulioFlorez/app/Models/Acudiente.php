<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Acudiente extends Model
{
    protected $table = 'acudientes';
    protected $fillable = ['IdentificacionAcudiente','NombreAcudiente','DireccionAcudiente','TelefonoFijoAcudiente','TelefonoCelularAcudiente','CorreoAcudiente','fk_Estado','fk_TipoDocumento','fk_TipoSangre','fk_Genero'];
    protected $guarded = ['id'];
}
