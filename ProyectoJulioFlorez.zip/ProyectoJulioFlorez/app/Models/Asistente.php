<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Asistente extends Model
{
    protected $table = 'asistentes';
    protected $fillable = ['IdentificacionAsistente','NombreAsistente','DireccionAsistente','TelefonoFijoAsistente','TelefonoCelularAsistente','CorreoAsistente','fk_TipoDocumento','fk_TipoSangre','fk_Estado'];
    protected $guarded = ['id'];
}
