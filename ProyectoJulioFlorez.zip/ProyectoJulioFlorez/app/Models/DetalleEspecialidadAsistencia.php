<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DetalleEspecialidadAsistencia extends Model
{
    protected $table = 'detalle_especialidad_asistencias';
    protected $fillable = ['DescripcionEA','fk_Especialidad','fk_Asistencia'];
    protected $guarded = ['id'];
}
