<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DetalleEstudianteFormato extends Model
{
    protected $table = 'detalle_estudiante_formatos';
    protected $fillable = ['fk_Estudiante','fk_Formato'];
    protected $guarded = ['id'];
}
