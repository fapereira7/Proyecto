<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DetallePersonaActa extends Model
{
    protected $table = 'detalle_persona_actas';
    protected $fillable = ['fk_Persona','fk_Acta'];
    protected $guarded = ['id'];
}
