<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Formato extends Model
{
    protected $table = 'formatos';
    protected $fillable = ['NumeroFormato','UrlFormato','fk_TipoFormato','fk_Estado','fk_Estudiante'];
    protected $guarded = ['id'];
}
