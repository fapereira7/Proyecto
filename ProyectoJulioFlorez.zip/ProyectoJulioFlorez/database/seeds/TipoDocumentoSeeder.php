<?php

use Illuminate\Database\Seeder;

class TipoDocumentoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         \DB::table('tipo_documentos')->insert(array (

        	'NombreTipoDocumento' => 'Tarjeta de identidad'
        	));

         \DB::table('tipo_documentos')->insert(array (

        	'NombreTipoDocumento' => 'Cedula de Ciudadania'
        	));

         \DB::table('tipo_documentos')->insert(array (

        	'NombreTipoDocumento' => 'Cédula de Extranjería'
        	));

         \DB::table('tipo_documentos')->insert(array (

        	'NombreTipoDocumento' => 'Registro Civil'
        	));
    }
}
