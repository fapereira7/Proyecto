<?php

use Illuminate\Database\Seeder;

class TipoFormatoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('tipo_formatos')->insert(array (

        	'NombreTipoFormato' => 'Observador'
        	));

        \DB::table('tipo_formatos')->insert(array (

        	'NombreTipoFormato' => 'Rectoria'
        	));

        \DB::table('tipo_formatos')->insert(array (

        	'NombreTipoFormato' => 'Reporte llamada'
        	));

        \DB::table('tipo_formatos')->insert(array (

        	'NombreTipoFormato' => 'Asistencia'
        	));

        \DB::table('tipo_formatos')->insert(array (

        	'NombreTipoFormato' => 'Excusa'
        	));

        \DB::table('tipo_formatos')->insert(array (

        	'NombreTipoFormato' => 'Cancelacion'
        	));

        \DB::table('tipo_formatos')->insert(array (

        	'NombreTipoFormato' => 'Llamado de atención escrito'
        	));
    }
}
