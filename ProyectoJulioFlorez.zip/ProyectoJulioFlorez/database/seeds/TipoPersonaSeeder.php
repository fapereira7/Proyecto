<?php

use Illuminate\Database\Seeder;

class TipoPersonaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('tipo_personas')->insert(array (

        	'NombreTipoPersona' => 'Docente SENA'
        	));

         \DB::table('tipo_personas')->insert(array (

        	'NombreTipoPersona' => 'Docente Colegio'
        	));

         \DB::table('tipo_personas')->insert(array (

        	'NombreTipoPersona' => 'Asistente'
        	));

         \DB::table('tipo_personas')->insert(array (

        	'NombreTipoPersona' => 'Coordinador'
        	));
    }
}
