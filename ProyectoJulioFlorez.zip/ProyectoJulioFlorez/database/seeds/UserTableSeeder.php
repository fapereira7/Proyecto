<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        for($i=0;$i<1;$i++)
        {
           $users=\DB::table('users')->insert(array (

        	'name'           => 'Sara',
            'email'          => 'sara@gmail.com',
            'password'       => bcrypt('123456'),
            'fk_TipoPersona' => '4',
            'remember_token'  => bcrypt('123456'),
            'created_at'     => $faker-> dateTimeThisYear($max = 'now'), 
            'updated_at'     => $faker-> dateTimeThisYear($max = 'now')

        ));

        }
    }
}
