<?php

use Illuminate\Database\Seeder;

class GradoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       \DB::table('grados')->insert(array (

        	'NombreGrado' => 'Décimo A',
        	'fk_Estado' => '1'
        ));

       \DB::table('grados')->insert(array (

        	'NombreGrado' => 'Décimo B',
        	'fk_Estado' => '1'
        ));

       \DB::table('grados')->insert(array (

        	'NombreGrado' => 'Décimo C',
        	'fk_Estado' => '1'
        ));

       \DB::table('grados')->insert(array (

        	'NombreGrado' => 'Once A',
        	'fk_Estado' => '1'
        ));

       \DB::table('grados')->insert(array (

        	'NombreGrado' => 'Once B',
        	'fk_Estado' => '1'
        ));
    }
}
