<?php

use Illuminate\Database\Seeder;

class TipoActaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('tipo_actas')->insert(array (

        	'NombreTipoActa' => 'SENA'
        	));

        \DB::table('tipo_actas')->insert(array (

        	'NombreTipoActa' => 'Colegio'
        	));
    }
}
