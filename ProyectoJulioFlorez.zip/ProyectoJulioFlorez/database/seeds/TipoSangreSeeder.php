<?php

use Illuminate\Database\Seeder;

class TipoSangreSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('tipo_de_sangres')->insert(array (

        	'TipoDeSangre' => 'O+'
        	));

         \DB::table('tipo_de_sangres')->insert(array (

        	'TipoDeSangre' => 'O-'
        	));

         \DB::table('tipo_de_sangres')->insert(array (

        	'TipoDeSangre' => 'A+'
        	));

         \DB::table('tipo_de_sangres')->insert(array (

        	'TipoDeSangre' => 'A-'
        	));

         \DB::table('tipo_de_sangres')->insert(array (

        	'TipoDeSangre' => 'B+'
        	));

         \DB::table('tipo_de_sangres')->insert(array (

        	'TipoDeSangre' => 'B-'
        	));

         \DB::table('tipo_de_sangres')->insert(array (

        	'TipoDeSangre' => 'AB+'
        	));

         \DB::table('tipo_de_sangres')->insert(array (

        	'TipoDeSangre' => 'AB-'
        	));
    }
}
