<?php

use Illuminate\Database\Seeder;

class TipoEstadoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('tipo_estados')->insert(array (

        	'NombreTipoEstado' => 'General'
        	));

        \DB::table('tipo_estados')->insert(array (

        	'NombreTipoEstado' => 'Asistencia'
        	));
    }
}
