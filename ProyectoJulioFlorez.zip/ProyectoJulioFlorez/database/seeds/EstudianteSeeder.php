<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class EstudianteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        for($i=0;$i<10;$i++)
        {
        	$estudiantes=\DB::table('estudiantes')->insertGetId(array(
        	'IdentificacionEstudiante'  => $faker->unique()->randomNumber($nbDigits = NULL),
			'NombreEstudiante'  		=> $faker->name,
			'DireccionEstudiante'       => $faker->address,  
			'TelefonoFijoEstudiante'    => $faker->numberBetween($min = 1000000, $max = 9000000),
			'TelefonoCelularEstudiante' => $faker->numberBetween($min = 3000000, $max = 3900000),
			'CorreoEstudiante'          => $faker-> unique()->email, 
			'fk_Estado'					=> '1',
			'fk_TipoDocumento'			=> $faker-> numberBetween($min = 1, $max = 4),
			'fk_TipoSangre'				=> $faker-> numberBetween($min = 1, $max = 8),
			'fk_Ficha'					=> $faker-> numberBetween($min = 1, $max = 10),
			'fk_Genero'					=> $faker-> numberBetween($min = 1, $max = 2),
			'created_at'                => $faker-> dateTimeThisYear($max = 'now'), 
			'updated_at'                => $faker-> dateTimeThisYear($max = 'now')
        	));

        }
    }
}
