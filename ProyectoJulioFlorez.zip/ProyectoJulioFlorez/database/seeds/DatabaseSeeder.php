pf<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->call(TipoEstadoSeeder::class);
        $this->call(TipoFormatoSeeder::class);
        $this->call(TipoActaSeeder::class);
        $this->call(EstadoSeeder::class);
    	$this->call(GeneroSeeder::class);
        $this->call(TipoPersonaSeeder::class);
        $this->call(TipoSangreSeeder::class);
        $this->call(TipoEspecialidadSeeder::class);
        $this->call(EspecialidadSeeder::class);
        $this->call(TipoDocumentoSeeder::class);
        $this->call(GradoSeeder::class);
        $this->call(FichaSeeder::class);
        $this->call(EstudianteSeeder::class);
        $this->call(FormatoSeeder::class);
        $this->call(UserTableSeeder::class);
    }
}
