<?php

use Illuminate\Database\Seeder;

class EstadoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('estados')->insert(array (

        	'NombreEstado' => 'Activo',
        	'fk_TipoEstado' => '1'
        	));

        \DB::table('estados')->insert(array (

        	'NombreEstado' => 'Inactivo',
        	'fk_TipoEstado' => '1'
        	));

        \DB::table('estados')->insert(array (

        	'NombreEstado' => 'Asistió',
        	'fk_TipoEstado' => '2'
        	));

        \DB::table('estados')->insert(array (

        	'NombreEstado' => 'No asistió',
        	'fk_TipoEstado' => '2'
        	));

        \DB::table('estados')->insert(array (

        	'NombreEstado' => 'Excusa',
        	'fk_TipoEstado' => '2'
        	));
    }
}
