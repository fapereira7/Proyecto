<?php

use Illuminate\Database\Seeder;

class FichaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('fichas')->insert(array (

        	'NumeroFicha' => '1124806',
        	'fk_Especialidad' => '1',
        	'fk_Grado' => '1',
        	'fk_Estado' => '1'
        ));

        \DB::table('fichas')->insert(array (

        	'NumeroFicha' => '1124808',
        	'fk_Especialidad' => '3',
        	'fk_Grado' => '1',
        	'fk_Estado' => '1'
        ));

        \DB::table('fichas')->insert(array (

        	'NumeroFicha' => '1145808',
        	'fk_Especialidad' => '2',
        	'fk_Grado' => '2',
        	'fk_Estado' => '1'
        ));

        \DB::table('fichas')->insert(array (

        	'NumeroFicha' => '1045809',
        	'fk_Especialidad' => '5',
        	'fk_Grado' => '2',
        	'fk_Estado' => '1'
        ));

        \DB::table('fichas')->insert(array (

        	'NumeroFicha' => '1145698',
        	'fk_Especialidad' => '4',
        	'fk_Grado' => '3',
        	'fk_Estado' => '1'
        ));

        \DB::table('fichas')->insert(array (

        	'NumeroFicha' => '1045887',
        	'fk_Especialidad' => '5',
        	'fk_Grado' => '3',
        	'fk_Estado' => '1'
        ));

         \DB::table('fichas')->insert(array (

        	'NumeroFicha' => '1120808',
        	'fk_Especialidad' => '3',
        	'fk_Grado' => '4',
        	'fk_Estado' => '1'
        ));

        \DB::table('fichas')->insert(array (

        	'NumeroFicha' => '1045875',
        	'fk_Especialidad' => '4',
        	'fk_Grado' => '4',
        	'fk_Estado' => '1'
        ));

        \DB::table('fichas')->insert(array (

        	'NumeroFicha' => '1111808',
        	'fk_Especialidad' => '1',
        	'fk_Grado' => '5',
        	'fk_Estado' => '1'
        ));

        \DB::table('fichas')->insert(array (

        	'NumeroFicha' => '1045509',
        	'fk_Especialidad' => '2',
        	'fk_Grado' => '5',
        	'fk_Estado' => '1'
        ));
    }
}
