<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class FormatoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        for($i=0;$i<10;$i++)
        {
        	$formatos=\DB::table('formatos')->insertGetId(array(
		    	'NumeroFormato'         => $faker->unique()->randomNumber($nbDigits = NULL),
				'DescripcionFormato'  	=> $faker->text($maxNbChars = 150),
				'UrlFormato'            => $faker->url,   
				'fk_Estado'				=> '1',
                'fk_Estudiante'         => $faker-> numberBetween($min = 1, $max = 10),
				'fk_TipoFormato'		=> $faker-> numberBetween($min = 1, $max = 7),
				'created_at'            => $faker-> dateTimeThisYear($max = 'now'), 
				'updated_at'            => $faker-> dateTimeThisYear($max = 'now')
        	));

        }
    }
}

