<?php

use Illuminate\Database\Seeder;

class EspecialidadSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('especialidads')->insert(array (

        	'NombreEspecialidad' => 'Programación de software',
        	'fk_Estado' => '1',
        	'fk_TipoEspecialidad' => '1'
        	));

         \DB::table('especialidads')->insert(array (

        	'NombreEspecialidad' => 'Diseño integral multimedia',
        	'fk_Estado' => '1',
        	'fk_TipoEspecialidad' => '1'
        	));

         \DB::table('especialidads')->insert(array (

        	'NombreEspecialidad' => 'Manejo ambiental',
        	'fk_Estado' => '1',
        	'fk_TipoEspecialidad' => '1'
        	));

         \DB::table('especialidads')->insert(array (

        	'NombreEspecialidad' => 'Administración de empresas',
        	'fk_Estado' => '1',
        	'fk_TipoEspecialidad' => '2'
        	));

         \DB::table('especialidads')->insert(array (

        	'NombreEspecialidad' => 'Administración turística y hotelera',
        	'fk_Estado' => '1',
        	'fk_TipoEspecialidad' => '2'
        	));
    }
}
