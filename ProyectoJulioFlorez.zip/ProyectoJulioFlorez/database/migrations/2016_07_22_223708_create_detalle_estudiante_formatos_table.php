<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDetalleEstudianteFormatosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('detalle_estudiante_formatos', function (Blueprint $table) {
            $table->increments('id');

            $table->integer('fk_Estudiante')->unsigned();
            $table->integer('fk_Formato')->unsigned();

            $table->foreign('fk_Estudiante')->references('id')->on('estudiantes')->onUpdate('cascade');
            $table->foreign('fk_Formato')->references('id')->on('formatos')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('detalle_estudiante_formatos');
    }
}
