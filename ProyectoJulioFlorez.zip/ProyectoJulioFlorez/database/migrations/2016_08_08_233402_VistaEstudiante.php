<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class VistaEstudiante extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared('create VIEW estudiante as select estudiantes.id,tipo_documentos.NombreTipoDocumento,estudiantes.IdentificacionEstudiante,generos.NombreGenero,estudiantes.NombreEstudiante,estudiantes.DireccionEstudiante,estudiantes.TelefonoFijoEstudiante,estudiantes.TelefonoCelularEstudiante,estudiantes.CorreoEstudiante,tipo_de_sangres.TipoDeSangre,fichas.NumeroFicha,especialidads.NombreEspecialidad,tipo_especialidads.NombreTipoEspecialidad,grados.NombreGrado,estados.NombreEstado from estudiantes join tipo_documentos on estudiantes.fk_TipoDocumento = tipo_documentos.id join generos on estudiantes.fk_Genero = generos.id join tipo_de_sangres on estudiantes.fk_TipoSangre = tipo_de_sangres.id join fichas on estudiantes.fk_Ficha = fichas.id join especialidads on fichas.fk_Especialidad = especialidads.id join tipo_especialidads on especialidads.fk_TipoEspecialidad = tipo_especialidads.id join grados on fichas.fk_Grado = grados.id join estados on estudiantes.fk_Estado = estados.id order by estudiantes.id;');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('Drop View estudiante;');
    }
}
