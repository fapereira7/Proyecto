<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAcudientesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('acudientes', function (Blueprint $table) {
            $table->increments('id');
            $table->bigInteger('IdentificacionAcudiente')->unique();
            $table->string('NombreAcudiente',500);
            $table->string('DireccionAcudiente',500);
            $table->bigInteger('TelefonoFijoAcudiente');
            $table->bigInteger('TelefonoCelularAcudiente');
            $table->string('CorreoAcudiente',500);

            $table->integer('fk_Estado')->unsigned();
            $table->integer('fk_TipoDocumento')->unsigned();
            $table->integer('fk_TipoSangre')->unsigned();
            $table->integer('fk_Genero')->unsigned();

            $table->foreign('fk_Estado')->references('id')->on('estados')->onUpdate('cascade');
            $table->foreign('fk_TipoDocumento')->references('id')->on('tipo_documentos')->onUpdate('cascade');
            $table->foreign('fk_TipoSangre')->references('id')->on('tipo_de_sangres')->onUpdate('cascade');
            $table->foreign('fk_Genero')->references('id')->on('generos')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('acudientes');
    }
}
