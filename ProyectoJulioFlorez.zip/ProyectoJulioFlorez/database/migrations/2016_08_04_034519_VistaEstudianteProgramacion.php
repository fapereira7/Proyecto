<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class VistaEstudianteProgramacion extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared(
'create view VistaEstudianteProgramacion as select estudiantes.* from estudiantes INNER JOIN fichas ON estudiantes.fk_ficha = fichas.id INNER join especialidads ON fichas.fk_especialidad = especialidads.id   WHERE especialidads.nombreespecialidad = \'Programacion de software\';');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('Drop View VistaEstudianteProgramacion;');
    }
}
