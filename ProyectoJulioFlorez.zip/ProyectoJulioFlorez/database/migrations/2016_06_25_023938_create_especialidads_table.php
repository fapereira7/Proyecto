<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEspecialidadsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('especialidads', function (Blueprint $table) {
            $table->increments('id');
            $table->string('NombreEspecialidad',100);

            $table->integer('fk_TipoEspecialidad')->unsigned();
            $table->integer('fk_Estado')->unsigned();
            
            $table->foreign('fk_TipoEspecialidad')->references('id')->on('tipo_especialidads')->onUpdate('cascade');
            $table->foreign('fk_Estado')->references('id')->on('estados')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('especialidads');
    }
}
