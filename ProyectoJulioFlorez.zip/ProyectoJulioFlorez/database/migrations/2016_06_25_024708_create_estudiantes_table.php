<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEstudiantesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('estudiantes', function (Blueprint $table) {
            $table->increments('id');
            $table->bigInteger('IdentificacionEstudiante')->unique();
            $table->string('NombreEstudiante',500);
            $table->string('DireccionEstudiante',500);
            $table->bigInteger('TelefonoFijoEstudiante');
            $table->bigInteger('TelefonoCelularEstudiante');
            $table->string('CorreoEstudiante',500);

            $table->integer('fk_Estado')->unsigned();
            $table->integer('fk_TipoDocumento')->unsigned();
            $table->integer('fk_TipoSangre')->unsigned();
            $table->integer('fk_Ficha')->unsigned();
            $table->integer('fk_Genero')->unsigned();

            $table->foreign('fk_Estado')->references('id')->on('estados')->onUpdate('cascade');
            $table->foreign('fk_TipoDocumento')->references('id')->on('tipo_documentos')->onUpdate('cascade');
            $table->foreign('fk_TipoSangre')->references('id')->on('tipo_de_sangres')->onUpdate('cascade');
            $table->foreign('fk_Ficha')->references('id')->on('fichas')->onUpdate('cascade');
            $table->foreign('fk_Genero')->references('id')->on('generos')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('estudiantes');
    }
}
