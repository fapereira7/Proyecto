<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAsistenciasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('asistencias', function (Blueprint $table) {
            $table->increments('id');
            $table->date('FechaAsistencia');

            $table->integer('fk_Estado')->unsigned();
            $table->integer('fk_Estudiante')->unsigned();
            
            $table->foreign('fk_Estado')->references('id')->on('estados')->onUpdate('cascade');
            $table->foreign('fk_Estudiante')->references('id')->on('estudiantes')->onUpdate('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('asistencias');
    }
}
