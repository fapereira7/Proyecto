<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDetallePersonaFormatosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('detalle_persona_formatos', function (Blueprint $table) {
            $table->increments('id');

            $table->integer('fk_Persona')->unsigned();
            $table->integer('fk_Formato')->unsigned();

            $table->foreign('fk_Persona')->references('id')->on('personas')->onUpdate('cascade');
            $table->foreign('fk_Formato')->references('id')->on('formatos')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('detalle_persona_formatos');
    }
}
