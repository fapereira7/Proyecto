<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePersonasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('personas', function (Blueprint $table) {
            $table->increments('id');
            $table->bigInteger('IdentificacionPersona')->unique();
            $table->string('NombrePersona',500);
            $table->string('DireccionPersona',500);
            $table->bigInteger('TelefonoFijoPersona');
            $table->bigInteger('TelefonoCelularPersona');
            $table->string('CorreoPersona',500);

            $table->integer('fk_Estado')->unsigned();
            $table->integer('fk_TipoDocumento')->unsigned();
            $table->integer('fk_TipoSangre')->unsigned();
            $table->integer('fk_Usuario')->unsigned()->unique();
            $table->integer('fk_Genero')->unsigned();

            $table->foreign('fk_Estado')->references('id')->on('estados')->onUpdate('cascade');
            $table->foreign('fk_TipoDocumento')->references('id')->on('tipo_documentos')->onUpdate('cascade');
            $table->foreign('fk_TipoSangre')->references('id')->on('tipo_de_sangres')->onUpdate('cascade');
            $table->foreign('fk_Usuario')->references('id')->on('users')->onUpdate('cascade');
            $table->foreign('fk_Genero')->references('id')->on('generos')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('personas');
    }
}
