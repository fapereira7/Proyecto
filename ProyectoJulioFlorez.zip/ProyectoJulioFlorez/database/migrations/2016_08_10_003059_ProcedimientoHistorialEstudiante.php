<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ProcedimientoHistorialEstudiante extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared('create procedure ProcedimientoHistorialEstudiante(in IdEstudiante bigint) begin

select estudiantes.IdentificacionEstudiante as \'Identificación del estudiante\', estudiantes.NombreEstudiante as \'Nombre completo\', especialidads.NombreEspecialidad as \'Especialidad\', fichas.NumeroFicha as \'Ficha\',count(formatos.fk_TipoFormato) as \'Observaciones\' from estudiantes
          inner join fichas on estudiantes.fk_Ficha = fichas.id 
          inner join especialidads on especialidads.id = fichas.fk_Especialidad 
          inner join formatos on formatos.fk_Estudiante = estudiantes.id 
          inner join tipo_formatos on tipo_formatos.id = formatos.fk_TipoFormato 
          where estudiantes.IdentificacionEstudiante = IdEstudiante and formatos.fk_TipoFormato = 1;
          
select count(formatos.fk_TipoFormato) as \'llamadosAtencion\' from estudiantes
           inner join formatos on formatos.fk_Estudiante = estudiantes.id 
           inner join tipo_formatos on tipo_formatos.id = formatos.fk_TipoFormato 
           where estudiantes.IdentificacionEstudiante = IdEstudiante and formatos.fk_TipoFormato = 7;
 
select count(asistencias.fk_Estado) as \'Inasistencias\' from estudiantes
           inner join asistencias on asistencias.fk_Estudiante = estudiantes.id 
           inner join estados on estados.id = asistencias.fk_Estado 
           where estudiantes.IdentificacionEstudiante = IdEstudiante and asistencias.fk_Estado = 4 or asistencias.fk_Estado = 5;
           
select count(asistencias.fk_Estado) as \'Excusas\' from estudiantes
           inner join asistencias on asistencias.fk_Estudiante = estudiantes.id 
           inner join estados on estados.id = asistencias.fk_Estado 
           where estudiantes.IdentificacionEstudiante = IdEstudiante and asistencias.fk_Estado = 5;
           
select asistencias.FechaAsistencia as \'Fechas Inasistencias\' from estudiantes
           inner join asistencias on asistencias.fk_Estudiante = estudiantes.id 
           inner join estados on estados.id = asistencias.fk_Estado 
           where estudiantes.IdentificacionEstudiante = IdEstudiante and asistencias.fk_Estado = 4 or asistencias.fk_Estado = 5
           group by asistencias.FechaAsistencia; 

end'
);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('Drop Procedure ProcedimientoHistorialEstudiante;');
    }
}
