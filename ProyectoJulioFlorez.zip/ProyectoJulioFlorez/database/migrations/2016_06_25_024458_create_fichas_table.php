<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFichasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fichas', function (Blueprint $table) {
            $table->increments('id');
            $table->bigInteger('NumeroFicha')->unique();

            $table->integer('fk_Especialidad')->unsigned();
            $table->integer('fk_Estado')->unsigned();
            $table->integer('fk_Grado')->unsigned();

            $table->foreign('fk_Grado')->references('id')->on('grados')->onUpdate('cascade');
            $table->foreign('fk_Especialidad')->references('id')->on('especialidads')->onUpdate('cascade');
            $table->foreign('fk_Estado')->references('id')->on('estados')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('fichas');
    }
}
