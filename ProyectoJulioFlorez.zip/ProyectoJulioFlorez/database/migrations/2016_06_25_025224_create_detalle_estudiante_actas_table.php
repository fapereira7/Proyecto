<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDetalleEstudianteActasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('detalle_estudiante_actas', function (Blueprint $table) {
            $table->increments('id');
             $table->string('DescripcionDetalleEA',500);

            $table->integer('fk_Acta')->unsigned();
            $table->integer('fk_Estudiante')->unsigned();
            $table->foreign('fk_Acta')->references('id')->on('actas')->onUpdate('cascade');
            $table->foreign('fk_Estudiante')->references('id')->on('estudiantes')->onUpdate('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('detalle_estudiante_actas');
    }
}
