<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDetalleEstudianteAcudientesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('detalle_estudiante_acudientes', function (Blueprint $table) {
            $table->increments('id');
            $table->string('parentesco',100);

            $table->integer('fk_Estudiante')->unsigned();
            $table->integer('fk_Acudiente')->unsigned();

            $table->foreign('fk_Acudiente')->references('id')->on('acudientes')->onUpdate('cascade');
            $table->foreign('fk_Estudiante')->references('id')->on('estudiantes')->onUpdate('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('detalle_estudiante_acudientes');
    }
}
