	<?php $__env->startSection('content'); ?>
	<div id="page-content-wrapper">
            <div class="container-fluid">
            <p class="navbar-brand titulista">ESTUDIANTES</p>
            <?php echo Form::open(['route' => 'HistorialEstudiante/search', 'method' => 'post', 'novalidate', 'class' => 'navbar-form navbar-right']); ?>

						  <article class="form-group ">
							<label for="exampleInputName2" style="font-family: 'Raleway', sans-serif;">Nombre</label>
							<input type="text" class="form-control inputlista" name="IdentificacionEstudiante">
							<button type="submit" class="btn botonlistabuscar">Buscar</button>
				          </article>
						<?php echo Form::close(); ?>

                <div class="row">
                    <div class="col-lg-12 col-md-12 col-xs-12">
						<article class="form-group tabla">
							<table class="table table-condensed table-striped table-bordered">
								<tr>
									<th>Tipo de documento</th>
									<th>Identificación</th>
									<th>Nombre completo</th>
									<th>Direccion</th>
									<th>Telefono fijo</th>
									<th>Celular</th>
									<th>Correo</th>
									<th>Tipo de sangre</th>
									<th>Ficha</th>
									<th>Genero</th>
									<th>Estado</th>
									<th>Action</th>
								</tr>
								<tbody>
									<?php foreach($estudiantes as $estudiante): ?>
										<tr>
											<td><?php echo e($estudiante->NombreTipoDocumento); ?></td>
											<td><?php echo e($estudiante->IdentificacionEstudiante); ?></td>
											<td><?php echo e($estudiante->NombreEstudiante); ?></td>
											<td><?php echo e($estudiante->DireccionEstudiante); ?></td>
											<td><?php echo e($estudiante->TelefonoFijoEstudiante); ?></td>
											<td><?php echo e($estudiante->TelefonoCelularEstudiante); ?></td>
											<td><?php echo e($estudiante->CorreoEstudiante); ?></td>
											<td><?php echo e($estudiante->TipoDeSangre); ?></td>
											<td><?php echo e($estudiante->NumeroFicha); ?></td>
											<td><?php echo e($estudiante->NombreGenero); ?></td>
											<td><?php echo e($estudiante->NombreEstado); ?></td>

											<td>
												<a class="btn btn-primary btn-xs botonlista" href="<?php echo e(route('estudiante.edit', ['id' => $estudiante->id] )); ?>">Editar</a>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
							<?php echo $estudiantes->render(); ?>

						</article>
                    </div>
                </div>
            </div>
	</div>
	</div>
	<?php $__env->stopSection(); ?>

	<!--<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>