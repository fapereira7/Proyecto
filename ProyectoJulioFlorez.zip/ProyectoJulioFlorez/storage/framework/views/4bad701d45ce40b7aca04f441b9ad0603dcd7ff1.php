<?php $__env->startSection('content'); ?>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			<?php echo Form::model($tipo_docente,['route' => 'tipo_docente/update', 'method' => 'put', 'novalidate']); ?>

				<?php echo Form::hidden('id', $tipo_docente->id); ?>

					<article class="form-group">
						<?php echo Form::label('NombreTipoDocente', 'Nombre del tipo de docente'); ?>

						<?php echo Form::text('NombreTipoDocente', null, ['class' => 'form-control','required' => 'required']); ?>

					</article>
					<article class="form-group">
						<?php echo Form::submit('Enviar', ['class' => 'btn btn-success']); ?>

					</article>
			<?php echo Form::close(); ?>

		</section>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>