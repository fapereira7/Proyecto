<?php $__env->startSection('content'); ?>
<h1>Asistencias</h1>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			<?php echo Form::open(['route' => 'asistencia/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']); ?>

				<article class="form-group">
					<label for="exampleInputName2">Name</label>
					<input type="date" class="form-control" name="FechaAsistencia">
					<button type="submit" class="btn btn-default">Search</button>
					<a href="<?php echo e(route('asistencia.index')); ?>" class="btn btn-primary">All</a>
					<a href="<?php echo e(route('asistencia.create')); ?>" class="btn btn-primary">Create</a>
				</article>
			<?php echo Form::close(); ?>

			<article class="form-group">
				<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Fecha asistencia</th>
						<th>Estado</th>
						<th>Action</th>
					</tr>
					<tbody>
						<?php foreach($asistencias as $asistencia): ?>
							<tr>
								<td><?php echo e($asistencia->FechaAsistencia); ?></td>
								<td><?php echo e($asistencia->NombreEstado); ?></td>
								<td>
									<a class="btn btn-primary btn-xs" href="<?php echo e(route('asistencia.edit', ['id' => $asistencia->id] )); ?>">Edit</a>
									<a class="btn btn-danger btn-xs" href="<?php echo e(route('asistencia/destroy', ['id' => $asistencia->id] )); ?>">Delete</a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</article>
		</section>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>