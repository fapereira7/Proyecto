<?php $__env->startSection('content'); ?>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			<?php echo Form::model($tipo_documento,['route' => 'tipo_documento/update', 'method' => 'put', 'novalidate']); ?>

				<?php echo Form::hidden('id', $tipo_documento->id); ?>

					<article class="form-group">
						<?php echo Form::label('NombreTipoDocumento', 'Nombre del tipo de documento'); ?>

						<?php echo Form::text('NombreTipoDocumento', null, ['class' => 'form-control','required' => 'required']); ?>

					</article>
					<article class="form-group">
						<?php echo Form::submit('Enviar', ['class' => 'btn btn-success']); ?>

					</article>
			<?php echo Form::close(); ?>

		</section>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>