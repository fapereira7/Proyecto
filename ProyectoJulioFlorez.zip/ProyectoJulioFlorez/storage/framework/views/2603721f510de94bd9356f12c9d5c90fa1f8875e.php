<?php $__env->startSection('content'); ?>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
            <div class="container-fluid">
            <p class="navbar-brand titulista">ACUDIENTES</p>
			<?php echo Form::open(['route' => 'acudiente/search', 'method' => 'post', 'novalidate', 'class' => 'navbar-form navbar-right']); ?>

				<article class="form-group">
					<label for="exampleInputName2" style="font-family: 'Raleway', sans-serif;">Nombre</label>
					<input type="text" class="form-control inputlista" name="NombreAcudiente">
					<button type="submit" class="btn botonlistabuscar">Search</button>
					<a href="<?php echo e(route('acudiente.index')); ?>" class="btn botonlista">Todos</a>
					<a href="<?php echo e(route('acudiente.create')); ?>" class="btn botonlista">Registrar nuevo acudiente</a>
				</article>
			<?php echo Form::close(); ?>

			<div class="row">
                    <div class="col-lg-12">
			<article class="form-group tabla">
				<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Tipo de documento</th>
						<th>Identificación del acudiente</th>
						<th>Nombre del acudiente</th>
						<th>Dirección</th>
						<th>Telefono</th>
						<th>Celular</th>
						<th>Correo</th>
						<th>Tipo de sangre</th>
						<th>Estado del acudiente</th>
						<th>Action</th>
					</tr>
					<tbody>
						<?php foreach($acudientes as $acudiente): ?>
							<tr>
								<td><?php echo e($acudiente->NombreTipoDocumento); ?></td>
								<td><?php echo e($acudiente->IdentificacionAcudiente); ?></td>
								<td><?php echo e($acudiente->NombreAcudiente); ?></td>
								<td><?php echo e($acudiente->DireccionAcudiente); ?></td>
								<td><?php echo e($acudiente->TelefonoFijoAcudiente); ?></td>
								<td><?php echo e($acudiente->TelefonoCelularAcudiente); ?></td>
								<td><?php echo e($acudiente->CorreoAcudiente); ?></td>
								<td><?php echo e($acudiente->TipoDeSangre); ?></td>
								<td><?php echo e($acudiente->NombreEstado); ?></td>
								<td>
									<a class="btn btn-primary btn-xs botonlista" href="<?php echo e(route('acudiente.edit', ['id' => $acudiente->id] )); ?>">Editar</a>
								</td>
							</tr>
						<?php endforeach; ?>
							   </tbody>
							</table>
							<?php echo $acudientes->render(); ?>

						</article>
                    </div>
                </div>
            </div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>