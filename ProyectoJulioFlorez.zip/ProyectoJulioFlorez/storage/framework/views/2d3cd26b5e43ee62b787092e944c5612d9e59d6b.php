<?php $__env->startSection('content'); ?>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
            <div class="container-fluid">
            <p class="navbar-brand titulista">ACTAS</p>
			<?php echo Form::open(['route' => 'acta/search', 'method' => 'post', 'novalidate', 'class' => 'navbar-form navbar-right']); ?>

				<article class="form-group">
					<label for="exampleInputName2" style="font-family: 'Raleway', sans-serif;">Nombre</label>
					<input type="text" class="form-control inputlista" name="NombreAcudiente">
					<button type="submit" class="btn botonlistabuscar">Search</button>
					<a href="<?php echo e(route('acta.index')); ?>" class="btn botonlista">Todos</a>
					<a href="<?php echo e(route('acta.create')); ?>" class="btn botonlista">Registrar nueva acta</a>
				</article>
			<?php echo Form::close(); ?>

			<div class="row">
                    <div class="col-lg-12">
			<article class="form-group tabla">
				<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Número de acta</th>
						<th>Fecha</th>
						<th>Descripción</th>
						<th>URL</th>
						<th>Tipo de acta</th>
						<th>Estado del acta</th>
						<th>Action</th>
					</tr>
					<tbody>
						<?php foreach($actas as $acta): ?>
							<tr>
								<td><?php echo e($acta->IdentificacionActa); ?></td>
								<td><?php echo e($acta->FechaActa); ?></td>
								<td><?php echo e($acta->Descripcion); ?></td>
								<td><?php echo e($acta->UrlActa); ?></td>
								<td><?php echo e($acta->NombreTipoActa); ?></td>
								<td><?php echo e($acta->NombreEstado); ?></td>
								<td>
									<a class="btn btn-primary btn-xs botonlista" href="<?php echo e(route('acta.edit', ['id' => $acta->id] )); ?>">Editar</a>
								</td>
							</tr>
						<?php endforeach; ?>
							   </tbody>
							</table>
							<?php echo $actas->render(); ?>					
						</article>
                    </div>
                </div>
            </div>
            <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script>
    
        <?php echo $__env->yieldContent('scripts'); ?>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>