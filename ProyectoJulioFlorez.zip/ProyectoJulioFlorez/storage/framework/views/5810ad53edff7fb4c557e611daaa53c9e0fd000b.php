<?php $__env->startSection('content'); ?>
<h1>Registros detalle especialidad asistencia</h1>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			<?php echo Form::open(['route' => 'detalle_especialidad_asistencia/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']); ?>

				<article class="form-group">
					<label for="exampleInputName2">Name</label>
					<input type="text" class="form-control" name="NombreEstado">
					<button type="submit" class="btn btn-default">Search</button>
					<a href="<?php echo e(route('detalle_especialidad_asistencia.index')); ?>" class="btn btn-primary">All</a>
					<a href="<?php echo e(route('detalle_especialidad_asistencia.create')); ?>" class="btn btn-primary">Create</a>
				</article>
			<?php echo Form::close(); ?>

			<article class="form-group">
				<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Descripción</th>
						<th>Especialidad</th>
						<th>Asistencia</th>
						<th>Acción</th>
					</tr>
					<tbody>
						<?php foreach($detalle_especialidad_asistencias as $detalle_especialidad_asistencia): ?>
							<tr>
								<td><?php echo e($detalle_especialidad_asistencia->DescripcionEA); ?></td>
								<td><?php echo e($detalle_especialidad_asistencia->NombreEspecialidad); ?></td>
								<td><?php echo e($detalle_especialidad_asistencia->FechaAsistencia); ?></td>
								<td>
									<a class="btn btn-primary btn-xs" href="<?php echo e(route('detalle_especialidad_asistencia.edit', ['id' => $detalle_especialidad_asistencia->id] )); ?>">Edit</a>
									<a class="btn btn-danger btn-xs" href="<?php echo e(route('detalle_especialidad_asistencia/destroy', ['id' => $detalle_especialidad_asistencia->id] )); ?>">Delete</a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</article>
		</section>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>