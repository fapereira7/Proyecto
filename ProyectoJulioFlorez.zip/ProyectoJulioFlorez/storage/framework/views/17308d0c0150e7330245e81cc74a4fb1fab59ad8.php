	
<?php $__env->startSection('content'); ?> 
  <div class="col-xs-12 col-md-12 center">
    <a href="<?php echo e(route('ficha.create')); ?>">Agregar nueva ficha</a>
    <div class="container col-md-12">
      <h1 class="especialidad">ESPECIALIDADES MEDIA FORTALECIDA</h1>
                <section class="main">
                <ul class="ch-grid">
                    <li>
                        <a href="<?php echo e(route('estudiante.index')); ?>">
                        <div class="ch-item">
                            <div class="ch-info-wrap">
                                <div class="ch-info">
                                    <div class="ch-info-front">
                                    <img class="img-responsive" src="http://localhost:8000/images/prog.png">
                                    </div>
                                    <div class="ch-info-back" style="background-color: #82D0D8;">
                                        <p>Programación de software</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                        <div class="ch-item">
                            <div class="ch-info-wrap">
                                <div class="ch-info">
                                    <div class="ch-info-front">
                                        <img class="img-responsive" src="http://localhost:8000/images/multi.png">
                                    </div>
                                    <div class="ch-info-back" style="background-color: #FC6E51;">
                                        <p>Diseño integral multimedia</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                        <div class="ch-item">
                            <div class="ch-info-wrap">
                                <div class="ch-info">
                                    <div class="ch-info-front">
                                        <img class="img-responsive" src="http://localhost:8000/images/ambiente.png">
                                    </div>
                                    <div class="ch-info-back" style="background-color:#39C082;">
                                        <p>Gestión ambiental</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                        <div class="ch-item">
                            <div class="ch-info-wrap">
                                <div class="ch-info">
                                    <div class="ch-info-front">
                                        <img class="img-responsive" src="http://localhost:8000/images/admin.png">
                                    </div>
                                    <div class="ch-info-back" style="background-color:#159BE9;">
                                        <p>Administración de empresas</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                        <div class="ch-item">
                            <div class="ch-info-wrap">
                                <div class="ch-info">
                                    <div class="ch-info-front">
                                        <img class="img-responsive" src="http://localhost:8000/images/turismo.png">
                                    </div>
                                    <div class="ch-info-back" style="background-color:#1ABC9C;">
                                        <p>Administración turística y hotelera</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a>
                    </li>
                </ul>
            </section>

            </div><!-- container -->
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>