<?php $__env->startSection('content'); ?>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
  <span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<h1>Tipos de actas</h1>
  <section class="row">
    <section class="col-md-10 col-md-offset-1">
      <?php echo Form::open(['route' => 'tipo_acta/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']); ?>

        <article class="form-group">
          <label for="exampleInputName2">Name</label>
          <input type="text" class="form-control" name="NombreTipoActa">
          <button type="submit" class="btn btn-default">Search</button>
          <a href="<?php echo e(route('tipo_acta.index')); ?>" class="btn btn-primary">All</a>
          <a href="<?php echo e(route('tipo_acta.create')); ?>" class="btn btn-primary">Create</a>
        </article>
      <?php echo Form::close(); ?>

      <article class="form-group">
        <table class="table table-condensed table-striped table-bordered">
          <tr>
            <th>Tipo de acta</th>
            <th>Action</th>
          </tr>
          <tbody>
            <?php foreach($tipo_actas as $tipo_acta): ?>
              <tr>
                <td><?php echo e($tipo_acta->NombreTipoActa); ?></td>
                <td>
                  <a class="btn btn-primary btn-xs" href="<?php echo e(route('tipo_acta.edit', ['id' => $tipo_acta->id] )); ?>">Edit</a>
                  <a class="btn btn-danger btn-xs" href="<?php echo e(route('tipo_acta/destroy', ['id' => $tipo_acta->id] )); ?>">Delete</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </article>
    </section>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>