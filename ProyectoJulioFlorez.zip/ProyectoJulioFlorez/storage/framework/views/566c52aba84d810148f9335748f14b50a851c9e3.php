<?php $__env->startSection('content'); ?>
<section class="container">
	<section class="row">
		<article class="col-md-10 col-md-offset-1">
			<?php echo Form::open(['route' => 'detalle_asistencia_estudiante.store', 'method' => 'post', 'novalidate']); ?>

				<section class="form-group">
					<?php echo Form::label('FechaAsistencia', 'Asistencia'); ?>

					<?php echo Form::select('FechaAsistencia',$asistencias, null, ['class' => 'form-control', 'required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::label('NombreEstudiante', 'Estudiante'); ?>

					<?php echo Form::select('NombreEstudiante',$estudiantes, null, ['class' => 'form-control', 'required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::submit('Enviar', ['class' => 'btn btn-success']); ?>

				</section>
			<?php echo Form::close(); ?>

		</article>
	</section>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>