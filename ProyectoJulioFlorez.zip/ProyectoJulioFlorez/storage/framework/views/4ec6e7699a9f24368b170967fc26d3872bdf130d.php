<?php $__env->startSection('content'); ?>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			<?php echo Form::model($ficha,['route' => 'ficha/update', 'method' => 'put', 'novalidate']); ?>

				<?php echo Form::hidden('id', $ficha->id); ?>

					<section class="form-group">
					<?php echo Form::label('NumeroFicha', 'Número de ficha'); ?>

					<?php echo Form::text('NumeroFicha', null, ['class' => 'form-control','required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::label('NombreGrado', 'Grado'); ?>

					<?php echo Form::select('NombreGrado',$grados, null, ['class' => 'form-control', 'required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::label('NombreEspecialidad', 'Especialidad'); ?>

					<?php echo Form::select('NombreEspecialidad',$especialidads, null, ['class' => 'form-control', 'required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::label('NombreEstado', 'Estado'); ?>

					<?php echo Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::submit('Enviar', ['class' => 'btn btn-success']); ?>

				</section>
			<?php echo Form::close(); ?>		
		</section>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>