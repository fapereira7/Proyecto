

<?php $__env->startSection('content'); ?>
<div class="col-xs-12 center">
        <h1 class="titulo white bigger-400">Bienvenido</h1>
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4 col-lg-offset-2 ">
                <div class="login">
                  <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <div class="col-sm-10 col-sm-offset-1">
                                <h4 class="text-left white">Ingreso al sistema</h4>
                                <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" placeholder="Nombre de usuario">
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <div class="col-sm-10 col-sm-offset-1">
                                <input type="password" class="form-control" name="password" placeholder="Contraseña">
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label class="pull-right olvi">
                                        <input type="checkbox" name="remember"> Recordarme
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-10 col-sm-offset-1">
                                <button type="submit" class="btn btn-large btn-block">
                                    <span class="glyphicon glyphicon-log-in"></span> Ingresar
                                </button>
                            </div>
                        </div>
                        <div class="form-group">
                        <div class="col-sm-11 forget_password no-padding">
                            <a class="pull-right olvi" href="<?php echo e(url('/password/reset')); ?>">¿Olvidó su contraseña?</a>
                        </div>
                        </div>
                    </form>
                </div>
            </div>
      <div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
        <div class="col-xs-12 text-center well  escudo">
          <div class="row">
            <div class="col-xs-3 visible-xs"></div>
            <div class="col-xs-6 col-sm-4 col-sm-offset-4">
              <img class="img-responsive" src="images/julio.png">
            </div>
          </div>
          <div >
            <h5 class="jf" >Institución técnico Distrital Colegio Julio Florez</h5>
          </div>
          </div>
        </div>
      </div>
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>