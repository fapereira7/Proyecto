 <?php echo $__env->make('layouts.MenuRegistros', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-xs-12 text-center">
				<div class="conRegistro  form-group">
	            	<p class="Registros registro">NUEVO FICHA</p>
	           	</div>
				<?php echo Form::open(['route' => 'ficha.store', 'method' => 'post', 'novalidate','class' => 'FormularioEst']); ?>

				<section class="form-group">
					<span class="input input--kaede">
						<?php echo Form::text('NumeroFicha', null, ['id' => 'input1', 'class' => 'input__field input__field--kaede','required' => 'required']); ?>

						<label class="input__label input__label--kaede" for="input1">
							<span class="input__label-content input__label-content--kaede">Número de ficha</span>
						</label>
					</span>
				</section>
				<section class="form-group">
					<?php echo Form::select('NombreGrado',$grados, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Seleccione un grado...']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::select('NombreEspecialidad',$especialidads, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Seleccione una especialidad...']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Seleccione un estado...']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::submit('Registrar', ['class' => 'btn-2 btn-2d']); ?>

				</section>
			<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	  $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>
<script type="text/javascript" src="<?php echo e(asset('js/classie.js')); ?>"></script>
<script>
	(function() {
		// trim polyfill : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/Trim
		if (!String.prototype.trim) {
			(function() {
				// Make sure we trim BOM and NBSP
				var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
				String.prototype.trim = function() {
					return this.replace(rtrim, '');
				};
			})();
		}

		[].slice.call( document.querySelectorAll( 'input.input__field' ) ).forEach( function( inputEl ) {
			// in case the input is already filled..
			if( inputEl.value.trim() !== '' ) {
				classie.add( inputEl.parentNode, 'input--filled' );
			}

			// events:
			inputEl.addEventListener( 'focus', onInputFocus );
			inputEl.addEventListener( 'blur', onInputBlur );
		} );

		function onInputFocus( ev ) {
			classie.add( ev.target.parentNode, 'input--filled' );
		}

		function onInputBlur( ev ) {
			if( ev.target.value.trim() === '' ) {
				classie.remove( ev.target.parentNode, 'input--filled' );
			}
		}
	})();
</script>

