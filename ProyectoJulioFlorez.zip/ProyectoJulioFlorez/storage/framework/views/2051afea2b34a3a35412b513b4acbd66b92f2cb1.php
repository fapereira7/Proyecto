<?php $__env->startSection('content'); ?>
<h1>Tipos de sangre</h1>
  <section class="row">
    <section class="col-md-10 col-md-offset-1">
      <?php echo Form::open(['route' => 'tipo_de_sangre/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']); ?>

        <article class="form-group">
          <label for="exampleInputName2">Name</label>
          <input type="text" class="form-control" name="TipoDeSangre">
          <button type="submit" class="btn btn-default">Search</button>
          <a href="<?php echo e(route('tipo_de_sangre.index')); ?>" class="btn btn-primary">All</a>
          <a href="<?php echo e(route('tipo_de_sangre.create')); ?>" class="btn btn-primary">Create</a>
        </article>
      <?php echo Form::close(); ?>

      <article class="form-group">
        <table class="table table-condensed table-striped table-bordered">
          <tr>
            <th>Tipo de sangre</th>
            <th>Action</th>
          </tr>
          <tbody>
            <?php foreach($tipo_de_sangres as $tipo_de_sangre): ?>
              <tr>
                <td><?php echo e($tipo_de_sangre->TipoDeSangre); ?></td>
                <td>
                  <a class="btn btn-primary btn-xs" href="<?php echo e(route('tipo_de_sangre.edit', ['id' => $tipo_de_sangre->id] )); ?>">Edit</a>
                  <a class="btn btn-danger btn-xs" href="<?php echo e(route('tipo_de_sangre/destroy', ['id' => $tipo_de_sangre->id] )); ?>">Delete</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </article>
    </section>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>