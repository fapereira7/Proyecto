<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Colegio Julio Florez</title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css" integrity="sha384-XdYbMnZ/QjLh6iI4ogqCTaIjrFk87ip+ekIjefZch0Y+PvJ8CDYtEs1ipDmPorQ+" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700">
    <link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Titillium+Web' rel='stylesheet' type='text/css'>

    <!-- Styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

    <link href="<?php echo e(asset('css/simple-sidebar.css')); ?>" rel="stylesheet">

     <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">
        <?php echo $__env->yieldContent('css'); ?>

    <link href="<?php echo e(asset('css/Style.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/footer.css')); ?>" rel="stylesheet">
    
    <link href="http://localhost:8000/images/julio1.png" rel="shortcut icon" type="image/x-icon"/>
    <?php /* <link href="<?php echo e(elixir('css/app.css')); ?>" rel="stylesheet"> */ ?>

</head>
<body id="app-layout" class="cuerpo">
      <div class="media banner">
        <div class="media-left media-middle">
          <a href="#">
            <img class="media-object" src="http://localhost:8000/images/julio1.png" width="120" height="120" alt="Escudo Colegio Julio Florez">
          </a>
        </div>
        <div class="media-body"">
          <h1 class="media-heading letraheader white" style="margin-left:2%;">Institución Técnico Distrital Colegio Julio Florez</h1>
        </div>
        
     </div>
     <ul class="nav navbar-nav navbar-right">
        <!-- Authentication Links -->
        <?php if(Auth::guest()): ?>
        <?php else: ?>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                </a>

                <ul class="dropdown-menu" role="menu">
                    <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
                </ul>
            </li>
        <?php endif; ?>
     </ul>

    <div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        Programación de software
                    </a>
                </li>
              <li>
                <a href="#" data-toggle="collapse" data-target="#toggleDemo" data-parent="#sidenav01" class="collapsed">
                  <span class="glyphicon glyphicon-user" aria-hidden="true"></span>Estudiante<b class="caret"></b>
                </a>
                <div class="collapse" id="toggleDemo" style="height: 0px;">
                  <ul class="nav nav-list">
                    <li><a href="<?php echo e(route('estudiante.create')); ?>"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Registrar nuevo estudiante</a></li>
                    <li><a href="<?php echo e(route('estudiante.index')); ?>"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Ver estudiantes</a></li>
                  </ul>
                </div>
              </li>
                <li>
          <a href="#" data-toggle="collapse" data-target="#toggleDemo2" data-parent="#sidenav01" class="collapsed">
          <span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>Docente<b class="caret"></b>
          </a>
          <div class="collapse" id="toggleDemo2" style="height: 0px;">
            <ul class="nav nav-list">
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Registrar nuevo docente</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Ver docentes</a></li>
            </ul>
          </div>
        </li>
        <li>
          <a href="#" data-toggle="collapse" data-target="#Asistencia" data-parent="#sidenav01" class="collapsed">
          <span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span>Asistencia<b class="caret"></b>
          </a>
          <div class="collapse" id="Asistencia" style="height: 0px;">
            <ul class="nav nav-list">
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Registrar asistencias</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Actualizar registro de asistencias</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Ver asistencias</a></li>
            </ul>
          </div>
        </li>
        <li>
          <a href="#" data-toggle="collapse" data-target="#Estadistica" data-parent="#sidenav01" class="collapsed">
          <span class="glyphicon glyphicon-signal" aria-hidden="true"></span>Estadisticas<b class="caret"></b>
          </a>
          <div class="collapse" id="Estadistica" style="height: 0px;">
            <ul class="nav nav-list">
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Ver estadisticas</a></li>
            </ul>
          </div>
        </li>
        <li>
          <a href="#" data-toggle="collapse" data-target="#Actas" data-parent="#sidenav01" class="collapsed">
          <span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span>Actas<b class="caret"></b>
          </a>
          <div class="collapse" id="Actas" style="height: 0px;">
            <ul class="nav nav-list">
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Excusas</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Observadores</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Cancelaciones</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Rectoria</a></li>
            </ul>
          </div>
        </li>        
        <li><a href="<?php echo e(URL::previous()); ?>"><span class="glyphicon glyphicon-menu-left" aria-hidden="true"></span>Volver</a></li>
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

  <?php echo $__env->yieldContent('content'); ?>
   <!-- JavaScripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js" integrity="sha384-I6F5OKECLVtK/BL+8iSLDEHowSAfUo76ZL9+kGAgTRdiByINKJaqTPH/QVNS1VDb" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>

    <script type="text/javascript" src="../../public/js/dropzone.js"></script>
    <?php /* <script src="<?php echo e(elixir('js/app.js')); ?>"></script> */ ?>


       <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

    <?php /* <script src="<?php echo e(elixir('js/app.js')); ?>"></script> */ ?>
        </body>
</html>

    


