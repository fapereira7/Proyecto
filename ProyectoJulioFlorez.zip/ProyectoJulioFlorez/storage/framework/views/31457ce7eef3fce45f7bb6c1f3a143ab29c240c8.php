<?php echo $__env->make('layouts.MenuRegistros', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript" src="<?php echo e(asset('/js/jquery-3.1.0.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/ajax/ajaxEstudiante.js')); ?>"></script>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="conRegistro  form-group">
            		<p class="Registros registro">REGISTRO ESTUDIANTE</p>
           		</div>
				<?php echo Form::open(['route' => 'estudiante.store', 'method' => 'post', 'novalidate' , 'id' => 'formEst', 'class' => 'FormularioEst']); ?>

				    <input type="hidden" name="_token" id="tokenEst" value="<?php echo e(csrf_token()); ?>">
				
					<section class="form-group">
						<?php echo Form::select('NombreTipoDocumento',$tipo_documentos, null, ['id' => 'NombreTipoDocumento', 'class' => 'form-control', 'required' => 'required', 'placeholder' => 'Tipo de documento']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::number('IdentificacionEstudiante', null, ['id' => 'IdentificacionEstudiante', 'class' => 'form-control','required' => 'required', 'placeholder' => 'Identificación']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::text('NombreEstudiante', null, ['id' => 'NombreEstudiante', 'class' => 'form-control','required' => 'required' , 'placeholder' => 'Nombres y apellidos']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::text('DireccionEstudiante', null, ['id' => 'DireccionEstudiante', 'class' => 'form-control','required' => 'required', 'placeholder' => 'Dirección']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::number('TelefonoFijoEstudiante', null, ['id' => 'TelefonoFijoEstudiante', 'class' => 'form-control','required' => 'required', 'placeholder' => 'Telefono fijo']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::number('TelefonoCelularEstudiante', null, ['id' => 'TelefonoCelularEstudiante', 'class' => 'form-control','required' => 'required', 'placeholder' => 'Celular']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::email('CorreoEstudiante', null, ['id' => 'CorreoEstudiante', 'class' => 'form-control','required' => 'required', 'placeholder' => 'Correo']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::select('TipoDeSangre',$tipo_de_sangres, null, ['id' => 'TipoDeSangre', 'class' => 'form-control', 'required' => 'required', 'placeholder' => 'Tipo de sangre']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::select('NumeroFicha',$fichas, null, ['id' => 'NumeroFicha', 'class' => 'form-control', 'required' => 'required', 'placeholder' => 'Ficha']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::select('NombreGenero',$generos, null, ['id' => 'NombreGenero', 'class' => 'form-control', 'required' => 'required', 'placeholder' => 'Genero']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::select('NombreEstado',$estados, null, ['id' => 'NombreEstado', 'class' => 'form-control', 'required' => 'required', 'placeholder' => 'Estado']); ?>

					</section>
					<section id="formAcu" class="form-group">
					    <section class="form-group">
					        <center><h1>Registrar Acudiente</h1></center>
					    </section>
						<section class="form-group">
							<?php echo Form::select('NombreTipoDocumento',$tipo_documentos, null, ['id' => 'NombreTipoDocumento', 'class' => 'form-control', 'required' => 'required', 'placeholder'=>'Tipo de documento']); ?>

						</section>
						<section class="form-group">
							<?php echo Form::number('IdentificacionAcudiente', null, ['id' => 'IdentificacionAcudiente', 'class' => 'form-control','required' => 'required', 'placeholder'=>'Identificación']); ?>

						</section>
						<section class="form-group">
							<?php echo Form::text('NombreAcudiente', null, ['id' => 'NombreAcudiente', 'class' => 'form-control','required' => 'required', 'placeholder'=>'Nombre completo']); ?>

						</section>
						<section class="form-group">
							<?php echo Form::text('DireccionAcudiente', null, ['id' => 'DireccionAcudiente', 'class' => 'form-control','required' => 'required', 'placeholder'=>'Dirección']); ?>

						</section>
						<section class="form-group">
							<?php echo Form::number('TelefonoFijoAcudiente', null, ['id' => 'TelefonoFijoAcudiente', 'class' => 'form-control','required' => 'required', 'placeholder'=>'Telefono fijo']); ?>

						</section>
						<section class="form-group">
							<?php echo Form::number('TelefonoCelularAcudiente', null, ['id' => 'TelefonoCelularAcudiente', 'class' => 'form-control','required' => 'required', 'placeholder'=>'Celular']); ?>

						</section>
						<section class="form-group">
							<?php echo Form::email('CorreoAcudiente', null, ['id' => 'CorreoAcudiente', 'class' => 'form-control','required' => 'required', 'placeholder'=>'Correo']); ?>

						</section>
						<section class="form-group">
							<?php echo Form::select('NombreGenero',$generos, null, ['id' => 'NombreGenero', 'class' => 'form-control', 'required' => 'required', 'placeholder'=>'Genero']); ?>

						</section>
						<section class="form-group">
							<?php echo Form::select('TipoDeSangre',$tipo_de_sangres, null, ['id' => 'TipoDeSangre', 'class' => 'form-control', 'required' => 'required', 'placeholder'=>'Tipo de sangre']); ?>

						</section>
						<section class="form-group">
							<?php echo Form::select('NombreEstado',$estados, null, ['id' => 'NombreEstado', 'class' => 'form-control', 'required' => 'required', 'placeholder'=>'Estado']); ?>

						</section>
						<section class="form-group" id="parentesco">
							<select class="form-control">
							    <option value="">Por favor seleccione un parentesco</option>
								<option value="Madre">Madre</option>
								<option value="Padre">Padre</option>
								<option value="Tío">Tío</option>
							</select>
						</section>
					</section>
					<section class="form-group">
					    <?php echo Form::button('Registar Acudiente', ['id' => 'btnAcudiente', 'class' => 'btn btn-primary']); ?>

					    <?php echo Form::button('Agregar Acudiente', ['id' => 'agregarAcu', 'class' => 'btn btn-primary']); ?>

						<?php echo Form::submit('Registrar', ['id' => 'btnregistrar']); ?>

					</section>
					<section class="form-group">
					    <table class="table table-condensed table-striped table-bordered">
					    	<thead>
					    		<tr>
					    			<th>Nombre Acudiente</th>
					    			<th>Documento</th>
					    		    <th>Parentesto</th>
					    		</tr>
					    	<tbody id="fila">
					    		<tr>
					    			<td></td>
					    			<td></td>
					    			<td></td>
					    		</tr>
					    	</tbody>
					    	</thead>
					    </table>
					</section>
					<?php echo e(Form::hidden('cantidadAcudiente', 0, ['id' => 'cantidadAcudiente'])); ?>

				<?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
<script type="text/javascript">
	  $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>
