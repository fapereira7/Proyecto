<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Reporte historial estudiante</title>
    
  </head>
  <body>
    <table class="table table-condensed table-striped table-bordered">
        <tr>
          <th>Nombre completo</th>
          <th>Especialidad</th>
          <th>Ficha</th>
          <th>Total de observaciones</th>
          <th>Total de llamados de atención</th>
        <tbody>
        

          <!--<?php foreach($estudiantes as $estudiante): ?>-->
            <tr>
              <td><?php echo e($estudiante->NombreEstudiante); ?></td>
              <td><?php echo e($estudiante->NombreEspecialidad); ?></td>
              <td><?php echo e($estudiante->NumeroFicha); ?></td>
              <td><?php echo e($estudiante->NombreTipoFormato); ?></td>
          <?php endforeach; ?>
        </tbody>
      </table>
  </body>
</html>