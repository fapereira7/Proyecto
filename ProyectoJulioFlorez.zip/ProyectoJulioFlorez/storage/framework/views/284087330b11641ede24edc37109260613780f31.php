<?php $__env->startSection('content'); ?>
<h1>Tipos de estado</h1>
  <section class="row">
    <section class="col-md-10 col-md-offset-1">
      <?php echo Form::open(['route' => 'tipo_estado/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']); ?>

        <article class="form-group">
          <label for="exampleInputName2">Name</label>
          <input type="text" class="form-control" name="NombreTipoEstado">
          <button type="submit" class="btn btn-default">Search</button>
          <a href="<?php echo e(route('tipo_estado.index')); ?>" class="btn btn-primary">All</a>
          <a href="<?php echo e(route('tipo_estado.create')); ?>" class="btn btn-primary">Create</a>
        </article>
      <?php echo Form::close(); ?>

      <article class="form-group">
        <table class="table table-condensed table-striped table-bordered">
          <tr>
            <th>Tipo de estado</th>
            <th>Action</th>
          </tr>
          <tbody>
            <?php foreach($tipo_estados as $tipo_estado): ?>
              <tr>
                <td><?php echo e($tipo_estado->NombreTipoEstado); ?></td>
                <td>
                  <a class="btn btn-primary btn-xs" href="<?php echo e(route('tipo_estado.edit', ['id' => $tipo_estado->id] )); ?>">Edit</a>
                  <a class="btn btn-danger btn-xs" href="<?php echo e(route('tipo_estado/destroy', ['id' => $tipo_estado->id] )); ?>">Delete</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </article>
    </section>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>