<?php $__env->startSection('content'); ?>
<div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand disabled" style="border-bottom: 1px solid #fff">
                    <a href="#" style="color: white;" class="listaMenu"> Manejo ambiental </a>
                </li>
                <li style="margin-top: 15px; margin-bottom: 1px;"><a href="<?php echo e(url('/principal')); ?>" class="listaMenu"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Página principal</a></li>
              <li>
              <li><a href="<?php echo e(route('Ambiente.index')); ?>" class="listaMenu"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>Estudiantes</a></li>
                <li><a href="#" class="listaMenu"><span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>Docentes</a></li>
              <li><a href="#" class="listaMenu"><span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span>Asistencia</a></li>
        <li>
          <a href="#" data-toggle="collapse" data-target="#Estadistica" data-parent="#sidenav01" class="collapsed listaMenu">
          <span class="glyphicon glyphicon-signal" aria-hidden="true"></span>Acciones generales<b class="caret"></b>
          </a>
          <div class="collapse" id="Estadistica" style="height: 0px;">
            <ul class="nav nav-list">
              <li style="margin-bottom: 1px;"><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Registrar estudiante</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Registrar docente</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Nueva acta</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Nuevo formato</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Gestionar fichas</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Gestionar grados</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Generar reporte</a></li>
            </ul>
          </div>
        </li>
        <li>
          <a href="#" data-toggle="collapse" data-target="#Actas" data-parent="#sidenav01" class="collapsed listaMenu">
          <span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span>Formatos<b class="caret"></b>
          </a>
          <div class="collapse" id="Actas" style="height: 0px;">
            <ul class="nav nav-list">
              <li style="margin-bottom: 1px;"><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Excusas</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Observadores</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Cancelaciones</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Rectoria</a></li>
            </ul>
          </div>
        </li>        
        <li><a href="<?php echo e(route('acta.create')); ?>" class="listaMenu"><span class="glyphicon glyphicon-file" aria-hidden="true"></span>Actas</a></li> 
        <li><a href="<?php echo e(URL::previous()); ?>" class="listaMenu"><span class="glyphicon glyphicon-menu-left" aria-hidden="true"></span>Volver</a></li>
            </ul>
        </div>

         <!-- Menu Toggle Script -->

    <?php /* <script src="<?php echo e(elixir('js/app.js')); ?>"></script> */ ?>
        <!-- /#sidebar-wrapper -->
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>