<?php $__env->startSection('content'); ?>
<div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        Administración de empresas
                    </a>
                </li>
              <li>
                <a href="#" data-toggle="collapse" data-target="#toggleDemo" data-parent="#sidenav01" class="collapsed">
                  <span class="glyphicon glyphicon-user" aria-hidden="true"></span>Estudiante<b class="caret"></b>
                </a>
                <div class="collapse" id="toggleDemo" style="height: 0px;">
                  <ul class="nav nav-list">
                    <li><a href="<?php echo e(route('estudiante.create')); ?>"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Registrar nuevo estudiante</a></li>
                    <li><a href="<?php echo e(route('estudiante.index')); ?>"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Ver estudiantes</a></li>
                  </ul>
                </div>
              </li>
                <li>
          <a href="#" data-toggle="collapse" data-target="#toggleDemo2" data-parent="#sidenav01" class="collapsed">
          <span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>Docente<b class="caret"></b>
          </a>
          <div class="collapse" id="toggleDemo2" style="height: 0px;">
            <ul class="nav nav-list">
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Registrar nuevo docente</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Ver docentes</a></li>
            </ul>
          </div>
        </li>
        <li>
          <a href="#" data-toggle="collapse" data-target="#Asistencia" data-parent="#sidenav01" class="collapsed">
          <span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span>Asistencia<b class="caret"></b>
          </a>
          <div class="collapse" id="Asistencia" style="height: 0px;">
            <ul class="nav nav-list">
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Registrar asistencias</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Actualizar registro de asistencias</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Ver asistencias</a></li>
            </ul>
          </div>
        </li>
        <li>
          <a href="#" data-toggle="collapse" data-target="#Estadistica" data-parent="#sidenav01" class="collapsed">
          <span class="glyphicon glyphicon-signal" aria-hidden="true"></span>Estadisticas<b class="caret"></b>
          </a>
          <div class="collapse" id="Estadistica" style="height: 0px;">
            <ul class="nav nav-list">
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Ver estadisticas</a></li>
            </ul>
          </div>
        </li>
        <li>
          <a href="#" data-toggle="collapse" data-target="#Actas" data-parent="#sidenav01" class="collapsed">
          <span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span>Actas<b class="caret"></b>
          </a>
          <div class="collapse" id="Actas" style="height: 0px;">
            <ul class="nav nav-list">
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Excusas</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Observadores</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Cancelaciones</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>Rectoria</a></li>
            </ul>
          </div>
        </li>        
        <li><a href="<?php echo e(URL::previous()); ?>"><span class="glyphicon glyphicon-menu-left" aria-hidden="true"></span>Volver</a></li>
            </ul>
        </div>

         <!-- Menu Toggle Script -->

    <?php /* <script src="<?php echo e(elixir('js/app.js')); ?>"></script> */ ?>
        <!-- /#sidebar-wrapper -->

   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>