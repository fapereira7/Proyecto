 <?php echo $__env->make('layouts.MenuRegistros', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <script type="text/javascript" src="<?php echo e(asset('js/tooltips.js')); ?>"></script>
 <script type="text/javascript" src="<?php echo e(asset('/js/jquery-3.1.0.min.js')); ?>"></script>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
    <div class="container-fluid">
    	<p class="navbar-brand titulista">GRADOS</p>
    	<?php echo Form::open(['route' => 'grado/search', 'method' => 'post', 'novalidate', 'class' => 'navbar-form navbar-right']); ?>

			<article class="form-group">
				<label for="exampleInputName2" style="font-family: 'Raleway', sans-serif;">Grado</label>
				<input type="text" class="form-control inputlista" name="NombreGrado">
				<button type="submit" class="btn botonlistabuscar">Buscar</button>
				<a href="<?php echo e(route('grado.index')); ?>" class="btn btn-primary botonlista" title="Todos los registros" rel="tooltip"><span class="glyphicon glyphicon-list-alt" aria-hidden="true" style="padding: 5px;"></span></a>
			<a href="<?php echo e(route('grado.create')); ?>" class="btn btn-primary botonlista" title="Nuevo grado" rel="tooltip"><span class="glyphicon glyphicon-pencil" aria-hidden="true" style="padding: 5px;"></span></a>
			</article>
		<?php echo Form::close(); ?>

		<div class="row">
            <div class="col-lg-12 col-md-12 col-xs-12">
				<article class="form-group tabla">
					<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Grado</th>
						<th>Estado</th>
						<th>Editar</th>
					</tr>
					<tbody>
						<?php foreach($grados as $grado): ?>
							<tr>
								<td><?php echo e($grado->NombreGrado); ?></td>
								<td><?php echo e($grado->NombreEstado); ?></td>
								<td style="text-align: center;">
									<a class="btn btn-primary btn-xs botonlista" href="<?php echo e(route('grado.edit', ['id' => $grado->id] )); ?>" style="border-radius: 20%;"><span class="glyphicon glyphicon-edit" aria-hidden="true" style="padding: 5px;"></span>
									</a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<center><?php echo $grados->render(); ?></center>
			</div>
		</div>
    </div>
</div>
<script type="text/javascript">
	  $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>