<?php $__env->startSection('content'); ?>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<section class="container">
	<section class="row">
		<article class="col-md-10 col-md-offset-1">
			<?php echo Form::open(['route' => 'asistencia.store', 'method' => 'post', 'novalidate']); ?>

			<input type="hidden" name="_token" id="tokencombo" value="<?php echo e(csrf_token()); ?>">
			    <section class="form-group">
					<?php echo Form::label('Fichas', 'Fichas'); ?>

					<select name="Fichas" id="Fichas" class="form-control">
					<option value="" selected="true">Por favor seleccione una ficha</option>
						<?php foreach($fichas as $ficha): ?>
							<option value="<?php echo e($ficha->id); ?>"><?php echo e($ficha->NumeroFicha); ?></option>
						<?php endforeach; ?>
					</select>
				</section>
				<div id="combo">
					<section class="form-group">
					    <?php echo Form::label('Estudiantes', 'Estudiantes'); ?>

						<select name="NombreEstudiante" id="Estudiantes" class="form-control">
						<option value="" >Por favor seleccione un estudiante</option>
							
						</select>
				    </section>
				</div>
				<section class="form-group">
					<?php echo Form::label('FechaAsistencia', 'Fecha'); ?>

					<?php echo Form::date('FechaAsistencia', null, ['class' => 'form-control','required' => 'required']); ?>

				</section>
				<section class="form-group">
				        <?php foreach($options as $option): ?>	
				            <input type="radio" name="optradio" value="<?php echo e($option->id); ?>"><label><?php echo e($option->NombreEstado); ?></label>
					    <?php endforeach; ?>
				</section>
				<section class="form-group">
					<?php echo Form::submit('Enviar', ['class' => 'btn btn-success']); ?>

				</section>
			<?php echo Form::close(); ?>

		</article>
	</section>
</section>
<script type="text/javascript" src="<?php echo e(asset('/js/jquery-3.1.0.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/ajaxcombofichas.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>