<?php $__env->startSection('content'); ?>
<div class="iconomenu">
<script type="text/javascript" src="<?php echo e(asset('js/jquery-3.1.0.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/agregarfichas.js')); ?>"></script>
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<section class="container">
	<section class="row">
		<article class="col-md-10 col-md-offset-1">
			<?php echo Form::open(['route' => 'grado.store', 'method' => 'post', 'novalidate']); ?>

				<section class="form-group">
					<?php echo Form::label('NombreGrado', 'Grado'); ?>

					<?php echo Form::text('NombreGrado', null, ['id' => 'NombreGrado', 'class' => 'form-control','required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::label('NombreEstado', 'Estado'); ?>

					<?php echo Form::select('NombreEstado',$estados, null, ['id' => 'NombreEstadoGrado', 'class' => 'form-control', 'required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::label('Numeroficha', 'Número de ficha'); ?>

					<?php echo Form::text('NumeroFicha', null, ['id'=>'NumeroFicha', 'class' => 'form-control','required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::label('NombreEspecialidad', 'Especialidad'); ?>

					<?php echo Form::select('NombreEspecialidad',$especialidads, null, ['id' => 'NombreEspecialidad', 'class' => 'form-control', 'required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::label('NombreEstado', 'Estado'); ?>

					<?php echo Form::select('NombreEstado',$estados, null, ['id'=>'NombreEstadoFicha', 'class' => 'form-control', 'required' => 'required']); ?>

				</section>
				<section>
					<button id="agregar" class="btn btn-primary">Agregar</button>
				</section>
				<?php echo Form::hidden('cantidad',0,['id' => 'cantidadFichas']); ?>

				<table class="table table-hover">
				<thead>
					<tr>
						<th>NumeroFicha</th>
						<th>NombreEspecialidad</th>
						<th>NombreEstadoFicha</th>
					</tr>
				</thead>
				<tbody id="fichas">
					<tr class="form-group">
						<td></td>
						<td></td>
						<td></td>
					</tr>
				</tbody>
					
				</table>
				<section class="form-group">
					<button id="enviarGrado" class="btn btn-success">Enviar</button>
				</section>
			<?php echo Form::close(); ?>

		</article>
	</section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>