<?php echo e(Form::open(array(
     'url'=>'upload/', 
     'method' => 'post',
     'enctype'=>'multipart/form-data'
) )); ?>


<?php echo e(Form::file('archivo')); ?>

<?php echo e(Form::submit('subir')); ?>


<?php echo e(Form::close()); ?>