 
<?php $__env->startSection('content'); ?> 
  <div class="col-xs-12 center">
  <div class="container">
    <h1 class="especialidad">ESPECIALIDADES MEDIA FORTALECIDA</h1>
      <div class="row espacio">
      <a href="ProgSoft.php" class="panel">
          <div class="col-md-4">
            <div class="col-xs-12 text-center well panel">
              <div class="row ">
                <div class="col-xs-3 visible-xs"></div>
                <div class="col-xs-6 col-sm-4 col-sm-offset-3">
                  <img class="img-responsive img-circle" src="http://localhost:8000/images/prog.png">
                </div>
                </div>
          <div class="letras">
            <h5 class="jf">PROGRAMACIÓN DE SOFTWARE</h5>
          </div>
          </div>
          </div>
          </a>
          <a href="<?php echo e(('/index.estudiantes')); ?>" class="panel">
        <div class="col-md-4">
          <div class="col-xs-12 text-center well panel">
          <div class="row">
            <div class="col-xs-3 visible-xs"></div>
            <div class="col-xs-6 col-sm-4 col-sm-offset-3">
              <img class="img-responsive img-circle" src="http://localhost:8000/images/multi.png">
            </div>
          </div>
          <div >
            <h5 class="jf" >DISEÑO INTEGRAL MULTIMEDIA</h5>
          </div>
          </div>
        </div>
        </a>
        <a href="#" class="panel">
        <div class="col-md-4">
          <div class="col-xs-12 text-center well panel">
          <div class="row">
            <div class="col-xs-3 visible-xs"></div>
            <div class="col-xs-6 col-sm-offset-2">
              <img class="img-responsive img-circle" src="http://localhost:8000/images/ambiente.png">
            </div>
          </div>
          <div >
            <h5 class="jf" >MANEJO AMBIENTAL</h5>
          </div>
          </div>
        </div>
      </div>
      </a>
      <div class="row">
      <a href="#" class="panel">
          <div class="col-xs-12  col-md-6 col-lg-4 col-lg-offset-2 ">
            <div class="col-xs-12 text-center well panel">
          <div class="row">
            <div class="col-xs-3 visible-xs"></div>
            <div class="col-xs-6 col-sm-4 col-sm-offset-3">
              <img class="img-responsive img-circle" src="http://localhost:8000/images/admin.png">
            </div>
          </div>
          <div>
            <h5 class="jf" >ADMINISTRACIÓN DE EMPRESAS</h5>
          </div>
          </div>
          </div>
          </a>
          <a href="#" class="panel">
        <div class="col-xs-12  col-md-6 col-lg-4">
            <div class="col-xs-12 text-center well panel">
          <div class="row ">
            <div class="col-xs-3 visible-xs"></div>
            <div class="col-xs-6 col-sm-4 col-sm-offset-3">
              <img class="img-responsive img-circle" src="http://localhost:8000/images/turismo.png">
            </div>
          </div>
          <div>
            <h5 class="jf" >ADMINISTRACIÓN TURISTICA Y HOTELERA</h5>
          </div>
          </div>
          </div>
          </a>
        </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>