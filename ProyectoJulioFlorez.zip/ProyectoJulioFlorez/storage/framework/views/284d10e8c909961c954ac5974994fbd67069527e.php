<?php $__env->startSection('content'); ?>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<section class="container">
	<section class="row">
		<article class="col-md-10 col-md-offset-1">
			<?php echo Form::open(['route' => 'acta.store', 'method' => 'post', 'novalidate']); ?>

				<section class="form-group">
					<?php echo Form::label('IdentificacionActa', 'Número de acta'); ?>

					<?php echo Form::text('IdentificacionActa', null, ['class' => 'form-control','required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::label('FechaActa', 'Fecha del acta'); ?>

					<?php echo Form::date('FechaActa', null, ['class' => 'form-control','required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::label('Descripcion', 'Descripción'); ?>

					<?php echo Form::textarea('Descripcion', null, ['class' => 'form-control','required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::label('UrlActa', 'Url del acta'); ?>

					<?php echo Form::text('UrlActa', null, ['class' => 'form-control','required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::label('NombreTipoActa', 'Tipo del acta'); ?>

					<?php echo Form::select('NombreTipoActa',$tipo_actas, null, ['class' => 'form-control', 'required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::label('NombreEstado', 'Estado'); ?>

					<?php echo Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required']); ?>

				</section>
				<section class="form-group">
					<?php echo Form::submit('Enviar', ['class' => 'btn btn-success']); ?>

				</section>
				<section class="form-group">
					<div class="caja">
								     <?php echo e(Form::open(array(
								     'url'=>'upload/',
								     'route'=>'Archivo.php', 
								     'method' => 'post',
								     'enctype'=>'multipart/form-data',
								     'files' => true
								) )); ?>

								<h1>Subiendo Archivos</h1>
								<?php echo Form::file('Archivo', null, ['class' => 'form-control']); ?>

								<?php echo Form::submit('Subir', ['route'=>'Archivo.php','class' => 'btn btn-success']); ?>

								<?php echo e(Form::close()); ?>

						</form>
					</div>
				</section>
			<?php echo Form::close(); ?>

		</article>
	</section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>