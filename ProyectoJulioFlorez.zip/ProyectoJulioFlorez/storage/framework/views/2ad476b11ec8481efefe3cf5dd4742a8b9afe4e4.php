 <?php echo $__env->make('layouts.MenuRegistros', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-xs-12 text-center">
				<div class="conRegistro  form-group">
	            	<p class="Registros registro">NUEVA ACTA</p>
	           	</div>
			<?php if(Session::has('success')): ?>

			<?php echo Session::get('Success'); ?>


			<?php endif; ?>

				<?php echo Form::open(array('url' =>'acta/post','files' =>true, 'method' => 'post', 'novalidate', 'class' => 'FormularioEst')); ?>

					<section class="form-group">
						<span class="input input--kaede">
				        	<?php echo Form::text('IdentificacionActa', null, ['id' => 'input1','class' => 'input__field input__field--kaede','required' => 'required']); ?>

							<label class="input__label input__label--kaede" for="input1">
							<span class="input__label-content input__label-content--kaede">Número del acta</span>
							</label>
						</span>
					</section>
					<section class="form-group">
						<?php echo Form::date('FechaActa', null, ['class' => 'form-control','required' => 'required', 'style' => 'background-color: #2E2E2E; border-radius: 0px 0px 0px 0px; border: none;']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::textarea('Descripcion', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Descripción']); ?>

					</section>					
					<section class="form-group">
						<?php echo Form::select('NombreTipoActa',$tipo_actas, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Seleccione tipo del acta...']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Seleccione el estado...']); ?>

					</section>	
					<section class="form-group">
						<input type="file" name="UrlActa" id="file-7" class="inputfile inputfile-6" data-multiple-caption="{count} files selected" multiple />
						<?php if($errors->has('UrlActa')): ?>
						<?php echo $errors->first('UrlActa'); ?>

						<?php endif; ?>
						<label for="file-7"><span></span> <strong><svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/></svg>Seleccione el archivo</strong></label>
					</section>		
					<section class="form-group">					
						<?php echo Form::submit('Registrar', ['class' => 'btn-2 btn-2d']); ?>

					</section>
				<?php echo Form::close(); ?>

			</div>
		</div>
    </div>
</div>
<script src="<?php echo e(asset('js/custom-file-input.js')); ?>"></script>
<script type="text/javascript">
	  $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>
<script type="text/javascript" src="<?php echo e(asset('js/classie.js')); ?>"></script>
<script>
	(function() {
		// trim polyfill : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/Trim
		if (!String.prototype.trim) {
			(function() {
				// Make sure we trim BOM and NBSP
				var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
				String.prototype.trim = function() {
					return this.replace(rtrim, '');
				};
			})();
		}

		[].slice.call( document.querySelectorAll( 'input.input__field' ) ).forEach( function( inputEl ) {
			// in case the input is already filled..
			if( inputEl.value.trim() !== '' ) {
				classie.add( inputEl.parentNode, 'input--filled' );
			}

			// events:
			inputEl.addEventListener( 'focus', onInputFocus );
			inputEl.addEventListener( 'blur', onInputBlur );
		} );

		function onInputFocus( ev ) {
			classie.add( ev.target.parentNode, 'input--filled' );
		}

		function onInputBlur( ev ) {
			if( ev.target.value.trim() === '' ) {
				classie.remove( ev.target.parentNode, 'input--filled' );
			}
		}
	})();
</script>
