<?php $__env->startSection('content'); ?>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="conRegistro  form-group">
            		<p class="Registros registro">ACTUALIZAR ESTUDIANTE</p>
           		</div>
			<?php echo Form::model($estudiante,['route' => 'estudiante/update', 'method' => 'put', 'novalidate', 'class'=>'FormularioEst']); ?>

				<?php echo Form::hidden('id', $estudiante->id); ?>

					<section class="form-group">
						<?php echo Form::select('NombreTipoDocumento',$tipo_documentos, null, ['class' => 'form-control', 'required' => 'required']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::number('IdentificacionEstudiante', null, ['class' => 'form-control','required' => 'required']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::text('NombreEstudiante', null, ['class' => 'form-control','required' => 'required']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::text('DireccionEstudiante', null, ['class' => 'form-control','required' => 'required']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::number('TelefonoFijoEstudiante', null, ['class' => 'form-control','required' => 'required']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::number('TelefonoCelularEstudiante', null, ['class' => 'form-control','required' => 'required']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::email('CorreoEstudiante', null, ['class' => 'form-control','required' => 'required']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::select('TipoDeSangre',$tipo_de_sangres, null, ['class' => 'form-control', 'required' => 'required']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::select('NumeroFicha',$fichas, null, ['class' => 'form-control', 'required' => 'required']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::select('NombreGenero',$generos, null, ['class' => 'form-control', 'required' => 'required']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::submit('Actualizar', ['id' => 'btnregistrar']); ?>

					</section>
				<?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>