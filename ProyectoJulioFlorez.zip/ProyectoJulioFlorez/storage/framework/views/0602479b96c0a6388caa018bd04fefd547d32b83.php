<?php $__env->startSection('css'); ?>
	<link href="<?php echo e(asset('/css/dropzone.css')); ?>" rel="stylesheet">
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('content'); ?>
		    <div class="container">
		        <div class="row">
		            <div class="panel panel-default">
		                <div class="panel-heading">Archivos</div>
			                <div class="panel-body">
										 <?php echo Form::open([
										 'url'=> 'uploads.php',
										 'method' => 'POST',
										 'files'=>'true',
										 'id' => 'my-dropzone' ,
										 'class' => 'dropzone']); ?>


										 <?php echo $__env->make('Load_File.button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			                    <?php echo Form::close(); ?>

			                </div>
		            </div>
		        </div>
		    </div>
	<?php $__env->stopSection(); ?>
<section class="form-group">
		<?php $__env->startSection('scripts'); ?>
	    <?php echo Html::script('js/dropzone.js');; ?>

		<script>
		{	
				Dropzone.options.myDropzone =
				{
				autoProcessQueue: false,
        		addRemoveLinks: true,
				oploadMultiple: true,
				maxFileSize: 100, //MB
				maxFiles: 1,
				init: function() 
				{
						var submitButton = document.querySelector("#submit-all") myDropzone = this;
						submitButton.addEventListener("click", function(e)
						{//alert("Precionaste el boton de submit");
							e.prevetDefault();
							e.stopPropagation();
							myDropzone.processQueue();//decirle a la zona de saltos para procesar todos los archivos de la cola
						});
						//es posible que desee mostrar el botton enviar archivos sólo cuando se dejan caer aquí
						this.on("addedfile", function(file)
						{// Mostrar botón de enviar aquí y / o informar a su uso para hacer clic.
							alert("Se agrego un archivo");
						});
						this.on("complete", function(file) {// Si estan en estado de completo los quitamos
		                    myDropzone.removeFile(file);
		                });
		                this.on("removedfile", handleFileRemoved);
					}
					/* EL EVENTO ACCEPT NOS PERMITE CAMBIAR LA IMAGEN DE VISTA PREVIA QUE SE MUESTRA */
	    	accept: function(file, done) {
		    var thumbnail = $('.dropzone .dz-preview.dz-file-preview .dz-images:last');

		    switch (file.type) 
		    {
		      case 'application/pdf':
		        thumbnail.css('background', 'url(images/pdf.png');
		        break;
		      case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
		        thumbnail.css('background', 'url(images/doc.png');
		        break;
		      case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
		        thumbnail.css('background', 'url(images/excel.png');
		        break;
		       case 'application/vnd.ms-excel':
		       	thumbnail.css('background', 'url(images/excel.png');
		        break;
		       case 'application/zip, application/x-compressed-zip':
		       	thumbnail.css('background', 'url(images/zip.png');
		        break;
		       case 'application/vnd.ms-powerpointtd>':
		       	thumbnail.css('background', 'url(images/ppt.png');
		        break;
		       case 'application/vnd.openxmlformats-officedocument.presentationml.presentation':
		       	thumbnail.css('background', 'url(images/ppt.png');
		        break;
		       case 'image/jpeg':
		       	break;
		       case 'image/png':
		       	break;
		       default:
		       	thumbnail.css('background', 'url(images/nose.png');
		    }

		    done();
		  },
				};
				if (this.options.addRemoveLinks)
				{
					var elementoContenedor = document.createElement('div');
					elementoContenedor.id = "botonesAgrupados";
					elementoContenedor.style = "display:inline-block;text-align:center;";
					file._openLink = Dropzone.createElement("<a href=\"file_upload/docs/" + file.name + "\" style=\"float:left;color:#000;cursor:pointer;margin-right:15px;\" class=\"dz-open\" download>Descargar</a>");

					file._removeLink = Dropzone.createElement("<a style=\"float:left;text-decoration:underline;\" class=\"dz-remove\" data-dz-remove>" + this.options.dictRemoveFile + "</a>");
					elementoContenedor.appendChild(file._openLink);
					elementoContenedor.appendChild(file._removeLink);
					file.previewElement.appendChild(elementoContenedor);

				};
		}
		</script>
		<style>
			body
			{
				font-weight: normal;
			    font-family: 'Source Sans Pro',sans-serif;
			}
		</style>
	
		</body>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js">

		</script>
		<script src="dist/js/dropzone.js">

		</script>
		<script>
		$(document).ready(function ()
		{

	        /* INICIA CONFIGURACIÓN DE DROPZONE */
		Dropzone.options.myDropzone = 
		{
			dictDefaultMessage: "Arrastre aqui archivos para subir.",
			addRemoveLinks: true,
		    init: function()
		    {
		        thisDropzone = this;
	                /* ESTE CODIGO SIRVE PARA MOSTRAR LOS ARCHIVOS ACTUALES EN EL SERVIDOR*/
		        $.get('file_upload/index.php', function(data) 
		        {

		        $.each(data, function(key,value)
		        {  
		        var mockFile = { name: value.name, size: value.size};       
		        thisDropzone.options.addedfile.call(thisDropzone, mockFile);
		        thisDropzone.options.thumbnail.call(thisDropzone, mockFile, "file_upload/docs/"+value.name);
				thisDropzone.emit("complete", mockFile);
				var ext = mockFile.name.split(".")[1];
					    switch(ext)
					    {
					    	case "xls":
					    		thisDropzone.createThumbnailFromUrl(mockFile, 'dist/img/excel.png');
					    		break;
					    	case "xlsx":
					    		thisDropzone.createThumbnailFromUrl(mockFile, 'dist/img/excel.png');
					    		break;
					    	case "pdf":
					    		thisDropzone.createThumbnailFromUrl(mockFile, 'dist/img/pdf.png');
					    		break;
					    	case "doc":
					    		thisDropzone.createThumbnailFromUrl(mockFile, 'dist/img/doc.png');
					    	case "docx":
					    		thisDropzone.createThumbnailFromUrl(mockFile, 'dist/img/doc.png');
					    		break;
					    	case "zip":
					    		thisDropzone.createThumbnailFromUrl(mockFile, 'dist/img/zip.png');
					    		break;
					    	case "rar":
					    		thisDropzone.createThumbnailFromUrl(mockFile, 'dist/img/rar.png');
					    		break;
					    	case "ppt":
					    		thisDropzone.createThumbnailFromUrl(mockFile, 'dist/img/ppt.png');
					    		break;
					    	case "pptx":
					    		thisDropzone.createThumbnailFromUrl(mockFile, 'dist/img/ppt.png');
					    		break;
					    	case "png":
					    		break;
					    	case "jpg":
					    		break;
					    	case "jpeg":
					    		break;
					    	default:
					    		thisDropzone.createThumbnailFromUrl(mockFile, 'dist/img/nose.png');
					    		break;
					    }	
		            });
		        });
		    },            
            /* ESTE EVENTO NOS PERMITE ELIMINAR REALMENTE EL ARCHIVO DEL SERVIDOR */
	    removedfile: function(file) {
	    	$.get( "eliminarArchivo.php", { 
	    		nombre: file.name
	    	}).done(function( data ) {
			    var _ref;
		    	return (_ref = file.previewElement) != null ? _ref.parentNode.removeChild(file.previewElement) : void 0;
		    });
	    }
	};
	
});
</script>
</form>
</section>
<?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>