<?php $__env->startSection('content'); ?>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="conRegistro  form-group">
            		<p class="Registros registro">REGISTRO ESTUDIANTE</p>
           		</div>
				<?php echo Form::open(['route' => 'estudiante.store', 'method' => 'post', 'novalidate' , 'class' => 'FormularioEst']); ?>

				
					<section class="form-group">
						<?php echo Form::select('NombreTipoDocumento',$tipo_documentos, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Tipo de documento']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::number('IdentificacionEstudiante', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Identificación']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::text('NombreEstudiante', null, ['class' => 'form-control','required' => 'required' , 'placeholder' => 'Nombres y apellidos']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::text('DireccionEstudiante', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Dirección']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::number('TelefonoFijoEstudiante', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Telefono fijo']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::number('TelefonoCelularEstudiante', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Celular']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::email('CorreoEstudiante', null, ['class' => 'form-control','required' => 'required', 'placeholder' => 'Correo']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::select('TipoDeSangre',$tipo_de_sangres, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Tipo de sangre']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::select('NumeroFicha',$fichas, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Ficha']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::select('NombreGenero',$generos, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Genero']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::select('NombreEstado',$estados, null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Estado']); ?>

					</section>
					<section class="form-group">
						<?php echo Form::submit('Registrar', ['id' => 'btnregistrar']); ?>

					</section>
				<?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Programacion.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>