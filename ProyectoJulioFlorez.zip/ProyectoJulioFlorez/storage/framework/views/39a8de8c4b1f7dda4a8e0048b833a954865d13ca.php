 <?php echo $__env->make('Programacion.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
	<div id="page-content-wrapper">
            <div class="container-fluid">
            <p class="navbar-brand titulista">ESTUDIANTES</p>
            <?php echo Form::open(['route' => 'estudiante/search', 'method' => 'post', 'novalidate', 'class' => 'navbar-form navbar-right']); ?>

						  <article class="form-group">
						  	<span class="input input--makiko">
								<input class="input__field input__field--makiko" type="text" id="input-16" name="NombreEstudiante"/>
								<label class="input__label input__label--makiko" for="input-16">
									<span class="input__label-content input__label-content--makiko">Nombre</span>
								</label>
							</span>
							<span class="input input--makiko">
								<input class="input__field input__field--makiko" type="text" id="input-16" name="NombreEstudiante"/>
								<label class="input__label input__label--makiko" for="input-16">
									<span class="input__label-content input__label-content--makiko">Identificación</span>
								</label>
							</span>
								<?php echo Form::select('NumeroFicha',$fichas, null, ['class' => 'form-control', 'required' => 'required']); ?>

								<label for="input-16">Ficha</label>
							<button type="submit" class="btn botonlistabuscar">Buscar</button>
							<a href="<?php echo e(route('estudiante.index')); ?>" class="btn botonlista">Todos</a>
				          </article>
						<?php echo Form::close(); ?>

                <div class="row">
                    <div class="col-lg-12 col-md-12 col-xs-12">
						<article class="form-group tabla">
							<table class="table table-condensed table-striped table-bordered">
								<tr>
									<th>Tipo de documento</th>
									<th>Identificación</th>
									<th>Nombre completo</th>
									<th>Direccion</th>
									<th>Telefono fijo</th>
									<th>Celular</th>
									<th>Correo</th>
									<th>Tipo de sangre</th>
									<th>Ficha</th>
									<th>Genero</th>
									<th>Estado</th>
									<th>Editar</th>
								</tr>
								<tbody>
									<?php foreach($estudiantes as $estudiante): ?>
										<tr>
											<td><?php echo e($estudiante->NombreTipoDocumento); ?></td>
											<td><?php echo e($estudiante->IdentificacionEstudiante); ?></td>
											<td><?php echo e($estudiante->NombreEstudiante); ?></td>
											<td><?php echo e($estudiante->DireccionEstudiante); ?></td>
											<td><?php echo e($estudiante->TelefonoFijoEstudiante); ?></td>
											<td><?php echo e($estudiante->TelefonoCelularEstudiante); ?></td>
											<td><?php echo e($estudiante->CorreoEstudiante); ?></td>
											<td><?php echo e($estudiante->TipoDeSangre); ?></td>
											<td><?php echo e($estudiante->NumeroFicha); ?></td>
											<td><?php echo e($estudiante->NombreGenero); ?></td>
											<td><?php echo e($estudiante->NombreEstado); ?></td>

											<td>
												<a class="btn btn-primary btn-xs botonlista" href="<?php echo e(route('estudiante.edit', ['id' => $estudiante->id] )); ?>" style="border-radius: 20%;"><span class="glyphicon glyphicon-edit" aria-hidden="true" style="padding: 5px;"></span></a>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
							<?php echo $estudiantes->render(); ?>

						</article>
                    </div>
                </div>
            </div>
	</div>
	</div>
<script type="text/javascript">
	  $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>
<script type="text/javascript" src="<?php echo e(asset('js/classie.js')); ?>"></script>
<script>
	(function() {
		// trim polyfill : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/Trim
		if (!String.prototype.trim) {
			(function() {
				// Make sure we trim BOM and NBSP
				var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
				String.prototype.trim = function() {
					return this.replace(rtrim, '');
				};
			})();
		}

		[].slice.call( document.querySelectorAll( 'input.input__field' ) ).forEach( function( inputEl ) {
			// in case the input is already filled..
			if( inputEl.value.trim() !== '' ) {
				classie.add( inputEl.parentNode, 'input--filled' );
			}

			// events:
			inputEl.addEventListener( 'focus', onInputFocus );
			inputEl.addEventListener( 'blur', onInputBlur );
		} );

		function onInputFocus( ev ) {
			classie.add( ev.target.parentNode, 'input--filled' );
		}

		function onInputBlur( ev ) {
			if( ev.target.value.trim() === '' ) {
				classie.remove( ev.target.parentNode, 'input--filled' );
			}
		}
	})();
</script>
