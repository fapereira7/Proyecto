<?php $__env->startSection('css'); ?>
	<link href="<?php echo e(asset('/css/dropzone.css')); ?>" rel="stylesheet">
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('content'); ?>
		    <div class="container">
		        <div class="row">
		            <div class="panel panel-default">
		                <div class="panel-heading">Archivos</div>
			                <div class="panel-body">
										 <?php echo Form::open([
										 'url'=> 'Auth.files.store',
										 'method' => 'POST',
										 'files'=>'true',
										 'id' => 'my-dropzone' ,
										 'class' => 'dropzone']); ?>


								<?php echo $__env->make('Load_File.button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			                    <?php echo Form::close(); ?>

			                </div>
		            </div>
		        </div>
		    </div>
	<?php $__env->stopSection(); ?>
<section class="form-group">
		<?php $__env->startSection('scripts'); ?>
	    <?php echo Html::script('js/dropzone.js');; ?>

		<script>
		var accept = ".pdf,.doc,.docx,.odt";
		{	
				Dropzone.options.myDropzone =
				{
				autoProcessQueue: false,
        		addRemoveLinks: true,
				oploadMultiple: true,
				maxFileSize: 100, //MB
				maxFiles: 1,
				acceptedFiles: accept,
				init: function() 
				{
						var submitButton = document.querySelector("#submit-all") myDropzone = this;
						submitButton.addEventListener("click", function(e)
						{//alert("Precionaste el boton de submit");
							e.prevetDefault();
							e.stopPropagation();
							myDropzone.processQueue(true);//decirle a la zona de saltos para procesar todos los archivos de la cola
						});
						//es posible que desee mostrar el botton enviar archivos sólo cuando se dejan caer aquí
						this.on("addedfile", function(file)
						{// Mostrar botón de enviar aquí y / o informar a su uso para hacer clic.
							alert("Se agrego un archivo");
						});
						this.on("complete", function(file) {// Si estan en estado de completo los quitamos
		                    myDropzone.removeFile(file);
		                });
		                this.on("removedfile", handleFileRemoved);
					}
				};				
		</script>
</section>
<?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>