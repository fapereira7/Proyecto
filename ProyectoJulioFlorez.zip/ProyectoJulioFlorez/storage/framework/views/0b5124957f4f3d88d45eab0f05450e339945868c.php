<?php $__env->startSection('content'); ?>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			<?php echo Form::model($detalle_docente_especialidad,['route' => 'detalle_docente_especialidad/update', 'method' => 'put', 'novalidate']); ?>

				<?php echo Form::hidden('id', $detalle_docente_especialidad->id); ?>

					<article class="form-group">
						<?php echo Form::label('DescripcionDetalleDE', 'Descripción'); ?>

						<?php echo Form::textarea('DescripcionDetalleDE', null, ['class' => 'form-control','required' => 'required']); ?>	
					</article>
					<article class="form-group">
						<?php echo Form::label('NombreDocente', 'Docente'); ?>

						<?php echo Form::select('NombreDocente',$docentes, null, ['class' => 'form-control', 'required' => 'required']); ?>

					</article>
					<article class="form-group">
						<?php echo Form::label('NombreEspecialidad', 'Especialidad'); ?>

						<?php echo Form::select('NombreEspecialidad',$especialidads, null, ['class' => 'form-control', 'required' => 'required']); ?>

					</article>
					<article class="form-group">
						<?php echo Form::submit('Enviar', ['class' => 'btn btn-success']); ?> 				
					</article>
			<?php echo Form::close(); ?>		
		</section>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>