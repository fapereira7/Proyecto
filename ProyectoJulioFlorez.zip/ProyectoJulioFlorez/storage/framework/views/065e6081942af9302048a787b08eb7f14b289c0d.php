  <footer class="footer-basic-centered">

            <p class="footer-company-motto">Institución Técnico Distrital Colegio Julio Florez</p>
            <p class="footer-company-name">Técnologo en Analisis y Desarrollo de Sistemas de Información</p>

        </footer>