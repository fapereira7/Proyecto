	
<?php $__env->startSection('content'); ?> 
  <div class="col-xs-12 col-md-12 center">
  <div class="MenuR">
    <ul class="nav nav-pills cl-effect-6">
        <li><a href="<?php echo e(route('grado.index')); ?>">GESTIONAR GRADOS</a></li>
        <li><a href="<?php echo e(route('ficha.index')); ?>">GESTIONAR FICHAS</a></li>
        <li role="presentation" class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">REGISTROS<span class="caret"></span>
            </a>
            <ul class="dropdown-menu" style="background-color: transparent;">
                <li><a href="#">Docente</a></li>
                <li><a href="<?php echo e(route('estudiante.create')); ?>">Estudiante</a></li>
            </ul>
          </li>
          <li><a href="<?php echo e(route('acta.create')); ?>">INGRESAR ACTA</a></li>
          <li role="presentation" class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">NUEVO FORMATO</a></li>
        <li><a href="<?php echo e(url('/principal')); ?>" data-modal="modal-7" class="md-trigger">GENERAR REPORTE</a></li>
        <li>
            <!--<button class="md-trigger" data-modal="modal-7">GENERAR REPORTE</button>-->
            </li>
    </ul>
    </div>
    <div class="container col-md-12 ">
      <h1 class="especialidad">ESPECIALIDADES MEDIA FORTALECIDA</h1>
                <section class="main">
                <ul class="ch-grid">
                    <li>
                        <a href="<?php echo e(route('Programacion.index')); ?>">
                        <div class="ch-item">
                            <div class="ch-info-wrap">
                                <div class="ch-info">
                                    <div class="ch-info-front">
                                    <img class="img-responsive" src="http://localhost:8000/images/prog.png">
                                    </div>
                                    <div class="ch-info-back" style="background-color: #82D0D8;">
                                        <p>Programación de software</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('Multimedia.index')); ?>">
                        <div class="ch-item">
                            <div class="ch-info-wrap">
                                <div class="ch-info">
                                    <div class="ch-info-front">
                                        <img class="img-responsive" src="http://localhost:8000/images/multi.png">
                                    </div>
                                    <div class="ch-info-back" style="background-color: #FC6E51;">
                                        <p>Diseño integral multimedia</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('Ambiente.index')); ?>">
                        <div class="ch-item">
                            <div class="ch-info-wrap">
                                <div class="ch-info">
                                    <div class="ch-info-front">
                                        <img class="img-responsive" src="http://localhost:8000/images/ambiente.png">
                                    </div>
                                    <div class="ch-info-back" style="background-color:#39C082;">
                                        <p>Manejo ambiental</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('Empresas.index')); ?>">
                        <div class="ch-item">
                            <div class="ch-info-wrap">
                                <div class="ch-info">
                                    <div class="ch-info-front">
                                        <img class="img-responsive" src="http://localhost:8000/images/admin.png">
                                    </div>
                                    <div class="ch-info-back" style="background-color:#159BE9;">
                                        <p>Administración de empresas</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('Turismo.index')); ?>">
                        <div class="ch-item">
                            <div class="ch-info-wrap">
                                <div class="ch-info">
                                    <div class="ch-info-front">
                                        <img class="img-responsive" src="http://localhost:8000/images/turismo.png">
                                    </div>
                                    <div class="ch-info-back" style="background-color:#1ABC9C;">
                                        <p>Administración turística y hotelera</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a>
                    </li>
                </ul>
                </section>
            </div><!-- container -->
          </div>
        </div>
         <!--<div class="md-modal md-effect-7" id="modal-7">
            <div class="md-content">
                <h3>Modal Dialog</h3>
                <div>
                    <p>This is a modal window. You can do the following things with it:</p>
                    <ul>
                        <li><strong>Read:</strong> modal windows will probably tell you something important so don't forget to read what they say.</li>
                        <li><strong>Look:</strong> a modal window enjoys a certain kind of attention; just look at it and appreciate its presence.</li>
                        <li><strong>Close:</strong> click on the button below to close the modal.</li>
                    </ul>
                    <button class="md-close">Close me!</button>
                </div>
            </div>
         </div>
        <div class="md-overlay"></div>

       <script>
            // this is important for IEs
            var polyfilter_scriptpath = '/js/';
        </script>

        <script type="text/javascript" src="<?php echo e(asset('js/classie.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/modalEffects.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/cssParser.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/css-filters-polyfill.js')); ?>"></script>-->

          
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>