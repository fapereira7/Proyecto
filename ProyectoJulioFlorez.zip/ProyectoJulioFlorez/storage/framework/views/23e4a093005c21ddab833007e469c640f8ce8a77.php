<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Reporte historial estudiante</title>
    
  </head>
  <body>
    <table class="table table-condensed table-striped table-bordered">
        <tr>
          <th>Identificación</th>
          <th>Nombre completo</th>
          <th>Especialidad</th>
          <th>Ficha</th>
          <th>Total de observaciones</th>
          <th>Total de llamados de atención</th>
          <th>Inasistencias</th>
          <th>Excusas</th>
          <th>Fechas de inasistencias</th>
        <tbody>
          <?php foreach($estudiantes as $estudiante): ?>
            <tr>
              <td><?php echo e($estudiante->Doc_Estudiante); ?></td>
              <td><?php echo e($estudiante->Nombre_completo); ?></td>
              <td><?php echo e($estudiante->Especialidad); ?></td>
              <td><?php echo e($estudiante->Ficha); ?></td>
              <td><?php echo e($estudiante->Observaciones); ?></td>
          <?php endforeach; ?>

          <?php foreach($estudiantesA as $estudianteA): ?>
              <td><?php echo e($estudianteA->llamadosAtencion); ?></td>
          <?php endforeach; ?>

          <?php foreach($estudiantesB as $estudianteB): ?>
              <td><?php echo e($estudianteB->Inasistencias); ?></td>
          <?php endforeach; ?>

           <?php foreach($estudiantesC as $estudianteC): ?>
              <td><?php echo e($estudianteC->Excusas); ?></td>
              </tr>
          <?php endforeach; ?>

           <?php foreach($estudiantesD as $estudianteD): ?>
              <tr>
              <td><?php echo e($estudianteD->FechasIn); ?></td>
              </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
  </body>
</html>