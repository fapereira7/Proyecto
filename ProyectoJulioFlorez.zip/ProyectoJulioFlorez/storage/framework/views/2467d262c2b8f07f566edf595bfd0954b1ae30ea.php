<?php $__env->startSection('content'); ?>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
	<div id="page-content-wrapper">
            <div class="container-fluid">
            <p class="navbar-brand titulista">PERSONAS</p>
            <?php echo Form::open(['route' => 'persona/search', 'method' => 'post', 'novalidate', 'class' => 'navbar-form navbar-right']); ?>

						  <article class="form-group ">
							<label for="exampleInputName2" style="font-family: 'Raleway', sans-serif;">Nombre</label>
							<input type="text" class="form-control inputlista" name="NombreEstudiante">
							<button type="submit" class="btn botonlistabuscar">Buscar</button>
							<a href="<?php echo e(route('persona.index')); ?>" class="btn botonlista">Todos</a>
							<a href="<?php echo e(route('persona.create')); ?>" class="btn botonlista">Registrar nueva persona</a>
				          </article>
						<?php echo Form::close(); ?>

                <div class="row">
                    <div class="col-lg-12 col-md-12 col-xs-12">
						<article class="form-group tabla">
							<table class="table table-condensed table-striped table-bordered">
								<tr>
									<th>Tipo de documento</th>
									<th>Identificación</th>
									<th>Nombre completo</th>
									<th>Direccion</th>
									<th>Telefono fijo</th>
									<th>Celular</th>
									<th>Correo</th>
									<th>Tipo de sangre</th>
									<th>Usuario</th>
									<th>Genero</th>
									<th>Estado</th>
									<th>Action</th>
								</tr>
								<tbody>
									<?php foreach($personas as $persona): ?>
										<tr>
											<td><?php echo e($persona->NombreTipoDocumento); ?></td>
											<td><?php echo e($persona->IdentificacionPersona); ?></td>
											<td><?php echo e($persona->NombrePersona); ?></td>
											<td><?php echo e($persona->DireccionPersona); ?></td>
											<td><?php echo e($persona->TelefonoFijoPersona); ?></td>
											<td><?php echo e($persona->TelefonoCelularPersona); ?></td>
											<td><?php echo e($persona->CorreoPersona); ?></td>
											<td><?php echo e($persona->TipoDeSangre); ?></td>
											<td><?php echo e($persona->name); ?></td>
											<td><?php echo e($persona->NombreGenero); ?></td>
											<td><?php echo e($persona->NombreEstado); ?></td>

											<td>
												<a class="btn btn-primary btn-xs botonlista" href="<?php echo e(route('persona.edit', ['id' => $persona->id] )); ?>">Editar</a>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
							<?php echo $personas->render(); ?>

						</article>
                    </div>
                </div>
            </div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>