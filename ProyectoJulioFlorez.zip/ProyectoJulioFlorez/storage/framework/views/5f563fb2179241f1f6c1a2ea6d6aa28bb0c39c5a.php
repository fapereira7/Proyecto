<?php $__env->startSection('content'); ?>
<div class="iconomenu">
 <a href="#menu-toggle" id="menu-toggle" style="color:white;">
 	<span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"/>
 </a>
</div>
<h1>Especialidades</h1>
	<section class="row">
		<section class="col-md-10 col-md-offset-1">
			<?php echo Form::open(['route' => 'especialidad/search', 'method' => 'post', 'novalidate', 'class' => 'form-inline']); ?>

				<article class="form-group">
					<label for="exampleInputName2">Name</label>
					<input type="text" class="form-control" name="NombreEspecialidad">
					<button type="submit" class="btn btn-default">Search</button>
					<a href="<?php echo e(route('especialidad.index')); ?>" class="btn btn-primary">All</a>
					<a href="<?php echo e(route('especialidad.create')); ?>" class="btn btn-primary">Create</a>
				</article>
			<?php echo Form::close(); ?>

			<article class="form-group">
				<table class="table table-condensed table-striped table-bordered">
					<tr>
						<th>Especialidad</th>
						<th>Tipo de especialidad</th>
						<th>Estado</th>
						<th>Action</th>
					</tr>
					<tbody>
						<?php foreach($especialidads as $especialidad): ?>
							<tr>
								<td><?php echo e($especialidad->NombreEspecialidad); ?></td>
								<td><?php echo e($especialidad->NombreTipoEspecialidad); ?></td>
								<td><?php echo e($especialidad->NombreEstado); ?></td>
								<td>
									<a class="btn btn-primary btn-xs" href="<?php echo e(route('especialidad.edit', ['id' => $especialidad->id] )); ?>">Edit</a>
									<a class="btn btn-danger btn-xs" href="<?php echo e(route('especialidad/destroy', ['id' => $especialidad->id] )); ?>">Delete</a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</article>
		</section>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>